Ext.define('Dragon.view.CustomSearchBlock', 
{
    extend: 'Dragon.view.One_One_BlockItems',
    mixins: ['Dragon.view.BlocksMixin'],
  
 config: 
    {   
        blockObj: {},
    	oneShieldDesktop: {}
    },
    listeners: {
        boxready: function (a, eopts) {
            var searchIconCell = document.getElementsByClassName('x-btn-button-SearchIcon-small x-btn-text')
            var searchDropdownCell = document.getElementsByClassName('oscombobox x-form-item-DashboardSearchDropdown')
            var advancedSearchCell = document.getElementsByClassName('x-form-item-AdvancedSearch');
            var customSearchBlock = document.getElementById(this.id)
            searchDropdownCell[0].addEventListener('click', () => {
                this.showSearchBlock(searchDropdownCell, customSearchBlock, advancedSearchCell);
            })

            // this.hideSearchBlock(searchDropdownCell, customSearchBlock);
            
            if (customSearchBlock) {
              
                      
                        document.addEventListener('click', (e) => {
                            this.showSearchBlock(searchDropdownCell, customSearchBlock, advancedSearchCell)
                            if(!customSearchBlock.contains(e.target) ) {
                                var dropdownList = document.querySelectorAll('.x-boundlist-floating[id*="_1655848_"]')
                                
                                if (dropdownList.length > 0) {
                                    dropdownList[0].style.display == 'none' ? this.hideSearchBlock(searchDropdownCell, customSearchBlock ,advancedSearchCell) : this.showSearchBlock(searchDropdownCell, customSearchBlock ,advancedSearchCell)
                                }
                                else {
                                    this.hideSearchBlock(searchDropdownCell, customSearchBlock ,advancedSearchCell)  
                                }
                            }
                            else{
                                this.showSearchBlock(searchDropdownCell, customSearchBlock, advancedSearchCell)

                            }
                        })
                }
            if (searchIconCell) {
                searchIconCell[0].addEventListener('mouseover', () => {
                    setTimeout(() => {
                    this.showSearchBlock(searchDropdownCell, customSearchBlock, advancedSearchCell);
                    var focusInput = this.getSearchTextActiveCell();
                    var selectedInput= focusInput[0].childNodes[1].childNodes[0].childNodes[0].childNodes[0]
                    selectedInput.focus();
                    },100)
                })
                searchIconCell[0].addEventListener('click', (e) => {
                    this.showSearchBlock(searchDropdownCell, customSearchBlock, advancedSearchCell)
                    if(!customSearchBlock.contains(e.target) ) {
                        var dropdownList = document.getElementsByClassName('x-boundlist-floating')
                    
                        if (dropdownList.length > 0) {
                            dropdownList[0].style.display == 'none' ? this.hideSearchBlock(searchDropdownCell, customSearchBlock ,advancedSearchCell) : this.showSearchBlock(searchDropdownCell, customSearchBlock ,advancedSearchCell)
                        }
                        else {
                            this.hideSearchBlock(searchDropdownCell, customSearchBlock ,advancedSearchCell)  
                        }
                    }
                      else{
                                this.showSearchBlock(searchDropdownCell, customSearchBlock, advancedSearchCell)

                            }
                })
            }
        }
    },
    hideSearchBlock(searchDropdownCell, customSearchBlock ,advancedSearchCell) {
        var headerBlock = document.getElementsByClassName('x-panel-HeaderBlock')
        searchDropdownCell[0].style = "display: none";
        advancedSearchCell[0].style = "display: none";
        this.getSearchTextActiveCell()[0].style = "display: none !important";
        customSearchBlock.classList.add('dashboardSearchBlock');
        customSearchBlock.classList.remove('dashboardSearchBlock-highlight');
        // headerBlock[0].style = "min-width:82px !important";
    },
    showSearchBlock(searchDropdownCell, customSearchBlock, advancedSearchCell) {
        customSearchBlock.classList.add('dashboardSearchBlock-highlight') 
        if(searchDropdownCell[0]){
        searchDropdownCell[0].style = "display: block !important";
        }
        if(advancedSearchCell[0]){
            advancedSearchCell[0].style = "display: block !important";
        }
        this.getSearchTextActiveCell()[0].style = "display: block !important";
    },
    getSearchTextActiveCell() {
        var searchTextActiveCell = [...document.getElementsByClassName('textCls x-form-item-DashboardSearchText x-autocontainer-form-item')].filter(x => {
            return !x.classList.contains('x-hidden-offsets')
            })
        return searchTextActiveCell
    },
	/**
	 * @method initComponent
	 * Initializes a component.
	 */
    initComponent: function() 
    {
		g_OsLogger.info("Messages component is initialized",this,{methodName:"initComponent"});
		var me = this;
		me.callParent(arguments);
         
    },
});
