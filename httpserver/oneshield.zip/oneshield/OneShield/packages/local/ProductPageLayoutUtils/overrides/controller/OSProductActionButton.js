/**
 * $Author: asharma@ONESHIELD.COM $
 * Controller to fire and handle events of Action button
 * @extends Ext.app.Controller
 */
Ext.define('Dragon.controller.OSProductActionButton', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.osprodactionbuttonview',
    init: function () {
        // Start listening for events on views
        this.control({
            // 'osActionButton': {
            //     render: this.onButtonRender,
            //     click: this.onActionButtonClick
            // },
            // 'OsDiaryButton': {
            //     click: this.onDiaryButtonClick
            // },
            // '#UiLogBtn': {
            //     click: this.onUiLogButtonClick
            // },
            // '#SystemLogBtn': {
            //     click: this.onSystemLogButtonClick
            // },
            // 'oscoretitlebar > button': {
            //     click: this.onActionButtonClick
            // },
            // 'oscoretabbar > button': {
            //     click: this.onActionButtonClick
            // },
            'osproducttabbar > button': {
                click: this.onActionButtonClick
            }
        });
    },
    // /**
    //  * @event onSystemLogButtonClick
    //  * Function handles click event of System log btn
    //  * @param buttonRef
    //  */
    // onSystemLogButtonClick: function (buttonRef) {
    //     g_OsLogger.info('System log button clicked', this, { methodName: "onSystemLogButtonClick", id: buttonRef.id });
    //     this.getController('Diagnostics').fireEvent(Dragon.ViewConstants.EVT_START_DIAGNOSTICS, { btn: buttonRef });
    // },
    // /**
    //  * @event onUiLogButtonClick
    //  * Function handles click event of UI log btn
    //  * @param buttonRef
    //  */
    // onUiLogButtonClick: function (buttonRef) {
    //     g_OsLogger.info('UI log button clicked', this, { methodName: "onUiLogButtonClick", id: buttonRef.id });
    //     this.getController('Logger').fireEvent('openUiLogWindow', buttonRef);
    // },
    /**
     * @event onDiaryButtonClick
     * Function  handles click event of Diary btn
     * @param buttonRef
     */
    onDiaryButtonClick: function (buttonRef) {
        g_OsLogger.info("Diary button clicked", this, { methodName: 'onDiaryButtonClick', id: buttonRef.id });
        var diaryInput = Dragon.view.common.Functions.encodeSessionInfo();
        diaryInput = diaryInput + "&Diary_CallingCode=Diary_Load";

        if (GFlags.os_test_xml !== 'null' && !Ext.isEmpty(GFlags.os_test_xml)) {
            diaryInput = diaryInput + "&Diary_Mockup=true";
        }
        var box = Ext.Msg.show({
            title: '',
            msg: Localize.processLocalStr('Diary Initializing'), //'Diary Initializing'.lclize(),
            wait: {
                text: ''
            },
            cls: 'diaryProgressWindow'
        });
        box.alignTo(Ext.getBody(), "tr-tr", [-10, 120]);
        //box.alignTo(buttonRef.getEl());
        g_OsLogger.info("Initialising message is added", this, { methodName: 'onDiaryButtonClick', id: buttonRef.id, msg: box.msg.html });

        Ext.Ajax.request({
            url: 'DiaryServlet',
            method: 'POST',
            params: diaryInput,
            //waitMsg:'Initializing Diary...',
            success: function (response) {
                g_OsLogger.info("Ajax request to DiaryServlet is succesfull", this, { methodName: 'onDiaryButtonClick', id: buttonRef.id, params: diaryInput });
                box.hide();
                box.center();
                var responseJson = response.responseText;
                var responseObj = Ext.decode(responseJson);
                var isErrorPageResponse = false;
                
                if(!Ext.isEmpty(responseObj) && responseObj != undefined && responseObj.errorPage){
                	isErrorPageResponse = true;
                }
                
                if(!isErrorPageResponse){
	                var win = Ext.create('Dragon.view.DiaryWindow', {
	                    diaryInitialData: responseObj,
	                    diaryBtn: buttonRef
	                });
                }
            },
            failure: function (response) {
                g_OsLogger.error("Ajax request to DiaryServlet has failed", this, { methodName: 'onDiaryButtonClick', id: buttonRef.id });
                box.hide();
                box.center();
                Ext.MessageBox.alert('Message', Localize.processLocalStr('Diary Initialization Error')); //'Diary Initialization Error'.lclize());
            }
        });
    },
    /**
     * @event onButtonRender
     * Function will render the the tooltip component to the button
     * @param actBtn
     */
    onButtonRender: function (actBtn) {
        var mouseoverMesg = actBtn.mouseoverMesg;

        if (!Ext.isEmpty(mouseoverMesg) && !Ext.isEmpty(mouseoverMesg.content)) {
            g_OsLogger.info("Button is rendered ", this, { methodName: 'onButtonRender', id: actBtn.id, html: actBtn.mouseoverMesg.content });
            Ext.create('Ext.ToolTip', {
            	dismissDelay: VIEWCONSTANTS.TOOLTIP_DISMISS_DELAY,
                target: actBtn.id,
                title: '',
                html: Ext.String.htmlEncode(mouseoverMesg.content),
                trackMouse: true,
                anchor: 'top'
            });
        }
    },
    /**
     * @event onActionButtonClick
     * Function send the backend request and receives response
     * if the condition LOGOUT_ACTION_ID is satisfied else
     * it will redirect and submits.
     *@param actBtn
     */
    onActionButtonClick: function (actBtn) {
        g_OsLogger.info("Action button clicked", this, { methodName: 'onActionButtonClick', id: actBtn.id });
        var cellObj = actBtn.cellObj;
        var btnObj = actBtn.btnObj;
        var addlConfig = actBtn.addlConfig;
        var externalUrl = actBtn.externalUrl;
        var confirmMsg = null;
        var submitFormParams = {};

        // To fix error because menu is shown even after it gets destroyed 
        // ArialEl is not available when menu item is clicked after it is destroyed
        if (
            (actBtn.cls == 'tabAreaToolBtnCurrent' ||
                actBtn.cls == 'tabAreaToolBtn') &&
            Ext.isFunction(actBtn.up)
        ) {
            var headerAreaToolBar = actBtn.up(),
                headerAreaToolBarLayoutItem,
                headerAreaToolBarLayout;
            if (!Ext.isEmpty(headerAreaToolBar) &&
                Ext.isFunction(headerAreaToolBar.getLayout)) {
                headerAreaToolBarLayout = headerAreaToolBar.getLayout();
            }
            if (!Ext.isEmpty(headerAreaToolBarLayout) &&
                Ext.isFunction(headerAreaToolBarLayout.getOverflowHandler)) {
                headerAreaToolBarLayoutItem = headerAreaToolBarLayout.getOverflowHandler();
            }
            if (!Ext.isEmpty(headerAreaToolBarLayoutItem) &&
                !Ext.isEmpty(headerAreaToolBarLayoutItem.menu)
            ) {
                APPUTILS.hideHeaderToolBarMenu(headerAreaToolBarLayoutItem.menu);
                g_OsLogger.debug("Hidden the destroyed drop-down menu of toolbar after clicking menu item.",this,{
                    methodName:'onActionButtonClick',
                    id: actBtn.id,
                    text: actBtn.text
                });
            } else {
                g_OsLogger.debug("Drop-down menu is not available.",this,{
                    methodName:'onActionButtonClick',
                    id: actBtn.id,
                    text: actBtn.text
                });
            }
        }

        if (!Ext.isEmpty(btnObj)) {
            confirmMsg = btnObj.actionVerificationText;
        }

        var actionSpec = {}; // for submitting actions

        actionSpec.actionSourceId = actBtn.id;

        if (!Ext.isEmpty(btnObj) && !Ext.isEmpty(externalUrl)) {
            //Deal with URL redirection
            if (btnObj.actionId == Dragon.ViewConstants.LOGOUT_ACTION_ID) {
                if (!Ext.isEmpty(confirmMsg)) {
                    //Basic JS confirmation
                    var exit = confirm(confirmMsg);

                    if (exit) {
                        g_OsLogger.info("Confirm message is present, user want to exit then send Ajax request", this, { methodName: 'onActionButtonClick', id: actBtn.id, exit: exit });
                        Ext.Ajax.request({
                            // Handling at data connection stage
                            // useDefaultXhrHeader: false,
                            // cors: true,
                            url: 'GatewayServlet',
                            method: 'POST',
                            params: {
                                'op': 'get',
                                'TX_NAME': Dragon.ViewConstants.LOGOUT_ACTION,
                                'USER_SESSION_GUID': Dragon.config.Runtime.getUserSessionGUID(),
                                'transactionId': Dragon.config.Runtime.getTransactionId(),
                                'EXCHANGE_ID': GFlags.os_startup_exchange_id
                            }
                        });
                        window.location = externalUrl;
                        g_OsLogger.info("Ajax request is is sent to 'GatewayServlet'", this, { methodName: 'onActionButtonClick', id: actBtn.id, DRAGON_SESSION_ID: Dragon.config.Runtime.getUserSessionId(), transactionId: Dragon.config.Runtime.getTransactionId(), USER_SESSION_GUID: Dragon.config.Runtime.getUserSessionGUID() });
                    }
                } else {
                    g_OsLogger.info("No confirm message is present just Ajax request is sent to 'GatewayServlet' ", this, { methodName: 'onActionButtonClick', id: actBtn.id, DRAGON_SESSION_ID: Dragon.config.Runtime.getUserSessionId(), transactionId: Dragon.config.Runtime.getTransactionId(), USER_SESSION_GUID: Dragon.config.Runtime.getUserSessionGUID() });
                    Ext.Ajax.request({
                        url: 'GatewayServlet',
                        // useDefaultXhrHeader: false, // Handling at data connection stage
                        // cors: true,
                        method: 'POST',
                        params: {
                            'op': 'get',
                            'TX_NAME': Dragon.ViewConstants.LOGOUT_ACTION,
                            'USER_SESSION_GUID': Dragon.config.Runtime.getUserSessionGUID(),
                            'transactionId': Dragon.config.Runtime.getTransactionId(),
                            'EXCHANGE_ID': GFlags.os_startup_exchange_id
                        }
                    });

                    //No confirmation present. Just forward.
                    window.location = externalUrl;
                }

                return;
            } else {
                //It's not a logout. Just process redirection and submit
                window.location = externalUrl;

                g_OsLogger.info("It's not a logout. Just process redirection and submit", this, { methodName: 'onActionButtonClick', id: actBtn.id });
                return;
            }
        }

        if (!Ext.isEmpty(cellObj) && !Ext.isEmpty(cellObj.id)) {
            g_OsLogger.info("CellObj is not empty", this, { methodName: 'onActionButtonClick', id: cellObj.id });
            
            submitFormParams.isSaveAction = cellObj.action1SaveTf;
            submitFormParams.isShowPopupEnabled = cellObj.showUnsavedChangesPopup;
            submitFormParams.actionLoadMaskDefinition = cellObj.actionLoadMaskDefinition;

            if (cellObj.popup === true) {
                g_OsLogger.info("If cell object popup is true call initiatePopUpWindow() ", this, { methodName: 'onActionButtonClick', id: actBtn.id, popup: cellObj.popup });

                /* set the actionObjectId to page object id, ONLY IF it has not already set by the widget*/
                Ext.applyIf(cellObj, {
                    'actionObjectId': Dragon.view.common.Functions.getPageObjectId()
                });

                this.initiatePopupWindow(cellObj, true);
            } else {
            	if (cellObj.typeId) {
            		actionSpec.actionSourceTypeId = cellObj.typeId;
            	} else {
            		actionSpec.actionSourceTypeId = -1;
            	}

            	if (cellObj.actionVerificationText) {
            		actionSpec.confirmMsg = cellObj.actionVerificationText;
            	} else {
            		actionSpec.confirmMsg = '';
            	}
            	
                if (!Ext.isEmpty(addlConfig) && !Ext.isEmpty(addlConfig.objectId) && addlConfig.objectId != '0') {
                    actionSpec.objectId = addlConfig.objectId;
                } else {
                    actionSpec.objectId = '';
                }
                
                if (!Ext.isEmpty(cellObj.value)) {
                    actionSpec.objectId = cellObj.value;
                }
                
                if (cellObj.actionIdText) {
                	actionSpec.transactionName = cellObj.actionIdText;
                } else {
                	actionSpec.transactionName = cellObj.actionOne;
                }
                
                if (!Ext.isEmpty(cellObj.validationType)) {
                	actionSpec.validateFlag = cellObj.validationType;
                } else {
                	actionSpec.validateFlag = '';
                }
                
                g_OsLogger.info("Cell object popup is false ", this, { methodName: 'onActionButtonClick', id: actBtn.id, popup: cellObj.popup, actionSpec: actionSpec });
            }
        } else {
            if (btnObj) {
                g_OsLogger.info("Button is btnObj", this, { methodName: 'onActionButtonClick', id: btnObj.id });
                
                submitFormParams.isSaveAction = btnObj.actionButtonSaveTf;
                submitFormParams.isShowPopupEnabled = btnObj.showUnsavedChangesPopup;
                submitFormParams.actionLoadMaskDefinition = btnObj.actionLoadMaskDefinition;

                if (btnObj.popup === true) {
                    g_OsLogger.info("Button object popup is true, call initiatePopUpWindow() ", this, { methodName: 'onActionButtonClick', id: btnObj.id });

                    /* set the actionObjectId to page object id, ONLY IF it has not already set by the widget*/
                    Ext.applyIf(btnObj, {
                        'actionObjectId': Dragon.view.common.Functions.getPageObjectId()
                    });

                    this.initiatePopupWindow(btnObj, false);
                } else {
                    actionSpec.actionSourceTypeId = btnObj.typeId;
                    actionSpec.confirmMsg = btnObj.actionVerificationText;

                    if (!Ext.isEmpty(addlConfig) && !Ext.isEmpty(addlConfig.objectId)) {
                        actionSpec.objectId = addlConfig.objectId;

                        /* If there is a non null listElementObjectId, then this is a block row level action
                         * Set the list selections*/
                        if (!Ext.isEmpty(addlConfig.listElementObjectId)) {
                            var listElementObjectId = addlConfig.listElementObjectId;

                            var listSelectedListObjectBv = 'bv_' + actionSpec.objectId + '_32785808';

                            var listElementBvField = Dragon.util.OSFormUtils.getBvElement(listSelectedListObjectBv);

                            if (Ext.isEmpty(listElementBvField)) {
                                Dragon.util.OSFormUtils.addHiddenParam(listSelectedListObjectBv, listElementObjectId);
                            }
                            //if when user selects list elements (checkbox or radio button), this BV on this list should
                            // be already created and has a value. Leave it as is 
                            /*else {
                                listElementBvField.setValue(listElementObjectId);
                            }*/

                            Dragon.util.OSFormUtils.processCache(listSelectedListObjectBv, listElementObjectId); // make this candidate for post only

                            var totalListObjIdBVName = 'bv_' + actionSpec.objectId + '_31814434';

                            var totalListObjIdBVField = Dragon.util.OSFormUtils.getBvElement(totalListObjIdBVName);

                            if (Ext.isEmpty(totalListObjIdBVField)) {
                                Dragon.util.OSFormUtils.addHiddenParam(totalListObjIdBVName, listElementObjectId);
                            } 
                            //if when user selects list elements (checkbox or radio button), this BV on this list should
                            // be already created and has a value. Leave it as is 
                            /*else {
                            	totalListObjIdBVField.setValue(listElementObjectId);
                            }*/

                            Dragon.util.OSFormUtils.processCache(totalListObjIdBVName, listElementObjectId);
                            
                        }
                    } else {
                        actionSpec.objectId = 'null';
                    }

                    actionSpec.transactionName = btnObj.actionIdText;
                    actionSpec.validateFlag = btnObj.validationType;
                    g_OsLogger.info("Button object popup is false ", this, { methodName: 'onActionButtonClick', id: btnObj.id, popup: btnObj.popup, actionSpec: actionSpec });
                }
            }
        }

        submitFormParams.isCellOrActionBtn = true;
        
        if ((!Ext.isEmpty(cellObj) && cellObj.popup !== true) || (!Ext.isEmpty(btnObj) && btnObj.popup != undefined && btnObj.popup !== true)) {
            g_OsLogger.info("Cell or ButtonObject - popup is false, call submitForm( ) ", this, { methodName: 'onActionButtonClick', id: actionSpec.objectId, actionSpec: actionSpec });
            Dragon.util.OSFormUtils.submitForm(
                actionSpec.transactionName,
                actionSpec.validateFlag,
                actionSpec.objectId,
                actionSpec.confirmMsg,
                actionSpec.actionSourceId,
                actionSpec.actionSourceTypeId,
                false,
                false,
                submitFormParams
            );
        }
    },
    /**
     * @method initiatePopupWindow
     * Function makes a call inorder to intiate popup
     * by passing the required  objects.
     * @param obj
     * @param isCellObj
     */
    initiatePopupWindow: function (obj, isCellObj) {
        g_OsLogger.info("Initiates popup window by passing required parameters", this, { methodName: 'initiatePopupWindow', id: obj.id, popupWindowTitle: obj.popupWindowTitle, actionId: obj.actionId });

        Dragon.util.OsPopupHelper.openActionPopup(
            obj.popupWindowTitle,
            obj.popupWindowWidth,
            obj.popupWindowHeight,
            obj.popupActionId,
            obj.popupTxnTimeout,
            obj.actionId,
            obj.actionObjectId,
            Dragon.config.Runtime.getUserSessionId(),
            Dragon.config.Runtime.getUserSessionGUID(),
            Dragon.config.Runtime.getTransactionId(),
            '',
            false
        );
    }
});
