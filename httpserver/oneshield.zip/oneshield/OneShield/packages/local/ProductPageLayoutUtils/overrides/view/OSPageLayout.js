/**
 * This class representing the viewable application area (the browser viewport).
 *
 * This Viewport renders itself to the document body, and automatically sizes itself to the size of
 * the browser viewport and manages window resizing. There may only be one Viewport created
 * in a page.
 * @class Dragon.view.OSPageLayout
 * A Common layout used with Viewports is Fit,  *
 *
 * This Viewport does not provide scrolling, so child Panels within the Viewport should provide
 * for scrolling if needed using the {@link #scrollable} config.
 */
Ext.define('Dragon.overrides.view.OSPageLayout', {
    override: 'Dragon.view.OSPageLayout',
    initComponent: function () {
        this.callParent(arguments);
    },
   
    /**
     * @method repaintWaitPage
     * @param oneShieldDesktop Backend data object
     * @param gtwyController controller instance
     */
    repaintWaitPage: function (oneShieldDesktop, gtwyController) {
        g_OsLogger.info("Function will repaint the header,tree and footer.", this, {methodName: 'repaintWaitPage'});
        oneShieldDesktop.messageList = {};
        oneShieldDesktop.messageList.messages = [];
        var msg = {};

        msg.content = Localize.processLocalStr('Please wait while the following job is being processed.'); //Please wait while the following job is being processed.'.lclize();
        msg.mode = Dragon.ViewConstants.UI_MESSAGE_MODE_INFO;
        oneShieldDesktop.messageList.messages.push(msg);
    
        this.repaintLayout(oneShieldDesktop);

    }

   
});
