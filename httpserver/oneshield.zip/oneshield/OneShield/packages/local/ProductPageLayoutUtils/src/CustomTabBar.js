/**
 * @class Dragon.view.CustomTabBar
 * @extends Ext.toolbar.Toolbar {@link #Ext.toolbar.Toolbar}
 * This class is responsible for creating a tab area button
 */
 Ext.define('Dragon.view.CustomTabBar', {
	extend: 'Ext.toolbar.Toolbar',
	alias: 'widget.osproducttabbar',
	itemId: 'os-custom-tab-area-bar',
	enableOverflow:true,
	cls:'osproducttabbar',
	anchor:'100%',
	controller: 'osprodactionbuttonview',

	/**
	 * This function is used for creating the component.
	 */
	 initComponent: function() {
		var me = this;
			   // Ext.apply(me, {
			   //     items: me.buildViewPortItems()
			   // });
			   me.callParent(arguments);   
			   g_OsLogger.info("Tabbar",this);
			   me.repaint(me.oneShieldDesktop);

		me.on('afterlayout', () => {
			   var maxHeightFlutter=0;
			   var TabLevelActionButtons = document.getElementsByClassName("x-btn-TabLevelActionButtons-small");
			   if (TabLevelActionButtons.length) {	  
					   maxHeightFlutter = 36 * TabLevelActionButtons.length;
				var TabLevelActionCont = document.getElementById("tabActionButtonCont");
				TabLevelActionCont.style.height  = maxHeightFlutter + 'px';	   
			   }
			//    if(document.getElementById("staticActionButton")){
			//    var osproducttabbar = document.getElementsByClassName("osproducttabbar"); 
			//    var parent = document.getElementById("staticActionButton");
			//    var child = document.getElementById("tabActionButtonCont");
			//    osproducttabbar[0].parentElement.appendChild(parent);
			//    parent.appendChild(child); 
			// 	osproducttabbar[0].classList.add('hasPaddingRight');
			//    }

			   	   if(document.getElementById("staticActionButton")){
				var tabButtonContainer = document.createElement('div');
				tabButtonContainer.classList.add('tabButtonContainer');
			   var osproducttabbar = document.getElementsByClassName("osproducttabbar"); 
			   var parent = document.getElementById("staticActionButton");
			   var child = document.getElementById("tabActionButtonCont");
			   osproducttabbar[0].parentElement.appendChild(tabButtonContainer);
			   tabButtonContainer.appendChild(parent); 
			   tabButtonContainer.appendChild(child); 
				osproducttabbar[0].classList.add('hasPaddingRight');
			   }
			  
			//    if(document.getElementById("tabFloatingButtonCont")){
			// 	var osproducttabbar1 = document.getElementsByClassName("osproducttabbar"); 
			// 	var parent1 = document.getElementById("staticActionButton");  
			// 	osproducttabbar1[0].appendChild(parent1);
			//    }
			//    if(Ext.getCmp("tabFloatingButtonCont")){
			//    Ext.getCmp("tabFloatingButtonCont").remove();
			//    }
			   
			})
			   
		   },
		// 	 buildViewPortItems: function() {
		// 	   var me = this;
		// 	   return [
		// 		   {
		// 			   region: 'south',
		// 			   xtype: 'oscoretabbar'
		// 		   }
		// 	   ];
		//    },
	/**
	 * @method repaint
	 * This function is responsible for creating a tab area button only if the conditions are matched
	 * whenever the repaint function is called.
	 * @param localDesktop
	 */
	repaint: function(localDesktop){
		var tabBarRef = this;
		var osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
          (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]) + 
          VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.OBJECT_TYPE + VIEWCONSTANTS.UNDERSCORE + this.blockObj.objectTypeId + 
          VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.BLOCK_ID + VIEWCONSTANTS.UNDERSCORE + this.blockObj.id;
		 if(Ext.getCmp("tabFloatingButtonCont")){
			Ext.getCmp("tabFloatingButtonCont").destroy();
		 }
		var pageHasTabs =
			( !Ext.isEmpty(localDesktop.tabBarButtons) && localDesktop.tabBarButtons.length > 0) ||
			( !Ext.isEmpty(localDesktop.tabBarLevel2Buttons) && localDesktop.tabBarLevel2Buttons.length > 0) ||
			( !Ext.isEmpty(localDesktop.tabBarLevel3Buttons) && localDesktop.tabBarLevel3Buttons.length > 0);

		var isDiaryPresent =  localDesktop.miniDiaryPresent;

		// var tabActionButtonList = document.createElement('div');
		// tabActionButtonList.classList.add('tabActionButtonList');

		if( pageHasTabs === true || isDiaryPresent === true ){
			var tabAreaButtons = [];
			var tabArr = [];
			var tabArrActionButtons = [];
			var tabArrFloatingButtons = [];

			var tabArrTemp =  Ext.Array.merge( localDesktop.tabBarButtons, localDesktop.tabBarLevel2Buttons, localDesktop.tabBarLevel3Buttons );
			
			for(var i = 0, ln = tabArrTemp.length; i < ln; i++ ){
				if(!Ext.isEmpty(tabArrTemp[i])){
					if(!Ext.isEmpty(tabArrTemp[i].uiStyle)){
						var uiStyle=  Dragon.view.common.Functions.getUiMixin(tabArrTemp[i].uiStyle)
							if(uiStyle == "TabLevelActionButtons"){
								tabArrActionButtons.push(tabArrTemp[i]);
							}
							else if( uiStyle.includes("FloatingIcon") ){
								tabArrFloatingButtons.push(tabArrTemp[i]);
							}
							else{
								tabArr.push(tabArrTemp[i]);
								
							}
						
						}
					else{
							tabArr.push(tabArrTemp[i]);
						}
				}
			}
			for(var i = 0, ln = tabArr.length; i < ln; i++ ){
				var tabObj = tabArr[i];
				var uiStyle =  Dragon.view.common.Functions.getUiMixin(tabObj.uiStyle)
				if(!Ext.isEmpty(tabObj))
				{
					var tabAreaBtn = Dragon.view.ButtonFactory.createToken(tabObj);

					if( tabAreaBtn != null )
					{
						tabAreaButtons.push( tabAreaBtn );
						
					}
					else
					{
						tabAreaBtn = {};

						tabAreaBtn.toggleGroup = 'tabAreaBtnGrp';
						tabAreaBtn.text = tabObj.label;
						tabAreaBtn.allowDepress = false;
						tabAreaBtn.btnObj = tabObj;
						
						if( tabObj.id > 0 ){
							tabAreaBtn.id = 'osBtn' + tabObj.id;
						}
						tabAreaBtn.btnTypeId = tabObj.typeId;
						tabAreaBtn.actionId = tabObj.actionIdText;
						tabAreaBtn.isDefaultTf = tabObj.defaultButton;
						tabAreaBtn.actionButtonId = tabObj.id;
						tabAreaBtn.validationType = tabObj.validationType;
						tabAreaBtn.verificationText = tabObj.actionVerificationText;
						tabAreaBtn.immutableStaticId = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE + 
							(Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]) + 
							VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.ACTION_BUTTON + VIEWCONSTANTS.UNDERSCORE + tabObj.id;
						if(uiStyle){
							var currUiStyle = 'tabAreaToolBtnCurrent ' + uiStyle;
							var normalUiStyle = 'tabAreaToolBtn ' + uiStyle;	
						}
						else if(uiStyle=="ViewDocumentsFloatingIcon"){
							tabObj.buttonWidth = 0;
						}
						else{							
							var currUiStyle = 'tabAreaToolBtnCurrent ';
							var normalUiStyle = 'tabAreaToolBtn ';
						}
						if(tabObj.current === true){
							tabAreaBtn.pressed = true;
							tabAreaBtn.cls = currUiStyle;
						}
						else{
							tabAreaBtn.cls = normalUiStyle;
						}
						tabAreaBtn.overCls = 'tabAreaToolBtnHover';
						
						tabAreaBtn.listeners = {
							afterrender: function(button) {
								var logObj = {
					                    methodName: 'Dragon.view.core.TabBar.afterrender',
					                    osViewId: this.immutableStaticId
					                };
				            	APPUTILS.addOsViewIdToDom(this.immutableStaticId, this.id, 
				            		logObj, this.el.query('.x-btn-inner')[0]);
				            	if (button.isDefaultTf) {
				                	APPUTILS.setDefaultButton(button);
				                }
							}
						};
					}

					tabAreaButtons.push(tabAreaBtn);
					if( i >= 0 && i < (ln-1) )
					{
						if (tabObj.actionButtonStyle !== Dragon.ViewConstants.BUTTON_STYLE_FILLER &&
							tabObj.actionButtonStyle !== Dragon.ViewConstants.BUTTON_STYLE_SPACER)
						{
							tabAreaButtons.push({ xtype: 'tbtext',text : '|' });
						}
					}
				}
			}
			if (!Ext.isEmpty(tabArrActionButtons)) {

				var actionButtonCont = Ext.create('Ext.panel.Panel', {
					type: 'hbox',
					renderTo : Ext.getBody(),
					pack: 'end ',
					align: 'stretch',
					id:'staticActionButton',
					border: false,
				});
				var hbox1 = Ext.create('Ext.panel.Panel', {
						type: 'vbox',
						renderTo  : Ext.getBody(),
						pack: 'end ',
						align: 'stretch',
						id:'tabActionButtonCont',
						border: false,
				});
				var actionButton= document.createElement('span');
                actionButton.classList.add('actionButton-menu');
				actionButton.innerHTML= 'Actions';
				let osviewidActionButton = 'actionButton-menu' ;
				actionButton.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+osviewidActionButton)
				document.getElementById('staticActionButton').prepend(actionButton)
			
               var paramStyleObj = {};
				
				for(var i = 0, ln = tabArrActionButtons.length; i < ln; i++ ){
					var btnObj = tabArrActionButtons[i];
                    if (btnObj.current === true) {
                        paramStyleObj.cls = 'tab-action-button-current';
                    } else {
                        paramStyleObj.cls = 'tab-action-button';
                    }
                    if (btnObj.actionId != Dragon.ViewConstants.MINI_DIARY_BUTTON_ACTION_ID) {
                        var btnWidget = Dragon.view.ButtonFactory.createButton({
                            btnObj: btnObj,
                            paramStyleObj: paramStyleObj
                        });
						
                        hbox1.add(btnWidget);
                    }
				}
				
            }
		
			if (!Ext.isEmpty(tabArrFloatingButtons)) {

				var hbox2 = Ext.create('Ext.panel.Panel', {
						type: 'vbox',
						renderTo  : Ext.getBody(),
						pack: 'end ',
						align: 'stretch',
						id:'tabFloatingButtonCont',
						border: false,
				});
			
               var paramStyleObj = {};
				
				for(var i = 0, ln = tabArrFloatingButtons.length; i < ln; i++ ){
					var btnObj = tabArrFloatingButtons[i];
                    // if (btnObj.current === true) {
                    //     paramStyleObj.cls = 'tab-action-button-current';
                    // } else {
                    //     paramStyleObj.cls = 'tab-action-button';
                    // }
                    if (btnObj.actionId != Dragon.ViewConstants.MINI_DIARY_BUTTON_ACTION_ID) {
                        var btnWidget = Dragon.view.ButtonFactory.createButton({
                            btnObj: btnObj,
                            paramStyleObj: paramStyleObj
                        });
						
                        hbox2.add(btnWidget);
                    }
				}
				
            }
			

			// if( isDiaryPresent === true ){
			// 	// tabAreaButtons.push({xtype: 'tbfill'});

			// 	// tabAreaButtons.push({
			// 	// 	xtype: 'OsDiaryButton',
			// 	// 	oneShieldDesktop:this.oneShieldDesktop
			// 	// });
			// 	this.remove(isDiaryPresent)
			// }
			this.add( tabAreaButtons );
			if (!Ext.isEmpty(tabArrActionButtons)) {
				this.add(actionButtonCont);
				this.add(hbox1);
			}
			else if (!Ext.isEmpty(tabArrFloatingButtons)) {
				this.add(hbox2);
			}
			this.show();
		}
		else{
			g_OsLogger.error("There are no tab bar buttons to show..",this,{methodName:'repaint',objectTree:localDesktop.objectTree,workflowContext:localDesktop.workflowContext});
			this.hide();
		}
		g_OsLogger.info('repaint() of TabBar class is called to display tabBar Buttons if present..',this,{methodName:'repaint',objectTree:localDesktop.objectTree,workflowContext:localDesktop.workflowContext});
	
	}
});


