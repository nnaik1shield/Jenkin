/**
 * @class Dragon.view.CustomFooter
 * @extends Ext.Container 
 * This class is responsible for adding the buttons to the toolbar
 */

 Ext.define('Dragon.view.CustomFooter', {
    extend: 'Ext.Container',
    alias: 'widget.osappcustomfooter',
    itemId: 'custom-footer-panel',
    cls: 'os-page-footer',
    split: false,
    id: 'custom-footer-panel',
    bodyCls: 'os-page-footer',
    enableOverflow: true,

    layout: {
        type: 'hbox',
        padding: 5,
        pack: 'end',
        align: 'middle'
    },
    height: 35,
    defaults: { margin: '0 5 0 0' },
initComponent: function() {
 var me = this;
        // Ext.apply(me, {
        //     items: me.buildViewPortItems()
        // });
        me.callParent(arguments);   
        g_OsLogger.info("Hello",this);
        me.repaint(me.oneShieldDesktop);
        
    },
      buildViewPortItems: function() {
        var me = this;
        return [
            {
                region: 'south',
                xtype: 'osappfooter'
            }
        ];
    },
    /**
     * @method repaint
     * This function makes a repaint function call inorder to render the components.
     * @param oneShieldDesktop
     * @param addlButtons
     */
    repaint: function(oneShieldDesktop, addlButtons) {
        g_OsLogger.info("Creates footer component",this,{methodName:'repaint',actionButtons:oneShieldDesktop.actionBarButtons,actionButtonsLevel3:oneShieldDesktop.actionBarLevel3Buttons});

        var me = this;
        var actionButtons = oneShieldDesktop.actionBarButtons;
        var actionButtonsLevel3 = oneShieldDesktop.actionBarLevel3Buttons;

        var frameworkPanel = APPUTILS.getMainFormPanel();
        if (!Ext.isEmpty(actionButtons)) {
            actionButtons.forEach(function(btnObj,i){
                if (btnObj.actionId == Dragon.ViewConstants.MINI_DIARY_BUTTON_ACTION_ID) {
                    actionButtons.splice(i,1);
                }
            })
        actionButtons.forEach(function(btnObj,i){
            if(btnObj.label.toLowerCase().replace(/\s+/g, ' ').trim() == "exit"){
                var exitBtn = actionButtons[i];
                actionButtons.splice(i,1);
                actionButtons.splice(0,0, exitBtn);
            }
        })
        actionButtons.forEach(function(btnObj,i){
            if(btnObj.label.includes("<")){
               btnObj.label =  btnObj.label.replaceAll('<', '')
           }
        });
        actionButtons.forEach(function(btnObj,i){
             if(btnObj.label.includes(">")){
                btnObj.label =  btnObj.label.replaceAll('>', '')
                var chevBtn = actionButtons[i];
                actionButtons.push(actionButtons.splice(actionButtons.indexOf(chevBtn), 1)[0]);
            }
            });
            actionButtons.forEach(function(btnObj,i){
                if(btnObj.label.includes(">")){
                   btnObj.label =  btnObj.label.replaceAll('>', '')
               }
            });
        }
       // me.removeAll(); // remove all anyways, otherwise if next page has no buttons prev page's buttons remain 

        if (
            (!Ext.isEmpty(actionButtons) && actionButtons.length > 0) ||
            (!Ext.isEmpty(actionButtonsLevel3) && actionButtonsLevel3.length > 0) ||
            (!Ext.isEmpty(oneShieldDesktop.diagnostics) &&
                !Ext.isEmpty(oneShieldDesktop.diagnostics.debug) &&
                oneShieldDesktop.diagnostics.debug == true
            )
        ) {
            //Create hbox to contain level three buttons so we can control their alignment
            var hbox1 = Ext.create('Ext.panel.Panel', {
                type: 'hbox',
                padding: 5,
                pack: 'start',
                align: 'middle',
                bodyStyle: 'background:transparent;',
                border: false,
                flex: 1
            });

            //Populate level three buttons if present.
            if (!Ext.isEmpty(actionButtonsLevel3)) {
                g_OsLogger.info("Populate level3 buttons.",this,{methodName:'repaint',actionButtonsLevel3: actionButtonsLevel3});
                var paramStyleObj = {};
                paramStyleObj.focusCls = 'action-level3-button-focus';
                // paramStyleObj.overCls = 'action-level3-button-hover';

                Ext.each(actionButtonsLevel3, function(btnObj, btnIdx, btnArray) {
                    if (btnObj.current === true) {
                        paramStyleObj.cls = 'action-level3-button-current';
                    } else {
                        paramStyleObj.cls = 'action-level3-button';
                    }
                    if (btnObj.actionId != Dragon.ViewConstants.MINI_DIARY_BUTTON_ACTION_ID) {
                        var btnWidget = Dragon.view.ButtonFactory.createButton({
                            btnObj: btnObj,
                            paramStyleObj: paramStyleObj
                        });

                        hbox1.add(btnWidget);
                    }
                });

                //Add sub-hbox for level three buttons to footer hbox
                me.add(hbox1);

                //Make sure footer area is visible
                me.setVisible(true);
            }

            if (!Ext.isEmpty(actionButtons)) {
                g_OsLogger.info("Populate actionButtons.",this,{methodName:'repaint',actionButtons: actionButtons});
                var paramStyleObj = {};
                paramStyleObj.focusCls = 'action-level1-button-focus';
                // paramStyleObj.overCls = 'action-level1-button-hover';

                Ext.each(actionButtons, function(btnObj, btnIdx, btnArray) {
                    if (btnObj.current === true) {
                        paramStyleObj.cls = 'action-level1-button-current';
                    } else {
                        paramStyleObj.cls = 'action-level1-button';
                    }
                    if(btnObj.label.toLowerCase().replace(/\s+/g, ' ').trim()  == "exit"){
                        paramStyleObj.cls = 'action-level1-button-exit';
                    }
                    if (btnObj.actionId != Dragon.ViewConstants.MINI_DIARY_BUTTON_ACTION_ID) //&& abs
                    //btnObj.actionId != Dragon.ViewConstants.NO_OP_POPUP_ACTION_ID ){
                    {
                        var btnWidget = Dragon.view.ButtonFactory.createButton({
                            btnObj: btnObj,
                            paramStyleObj: paramStyleObj
                        });

                        me.add(btnWidget);
                    }
                });

                me.setVisible(true);
            }


            if (!Ext.isEmpty(oneShieldDesktop.diagnostics) && !Ext.isEmpty(oneShieldDesktop.diagnostics.debug) && oneShieldDesktop.diagnostics.debug == true) {
                me.add(Ext.create('Ext.toolbar.Separator'));

                var sysLogBtn =
                    Ext.create('Ext.button.Button', {
                        _name: 'System Log',
                        id: 'SystemLogBtn',
                        text: null,
                        iconCls: 'SystemLog'
                    });

                me.add(sysLogBtn);

                var uiLogBtn =
                    Ext.create('Ext.button.Button', {
                        _name: 'UI Log',
                        id: 'UiLogBtn',
                        text: null,
                        iconCls: 'UIlog'
                            // tooltip:'click to view ui log',
                    });

                me.add(uiLogBtn);
            }

            if (!Ext.isEmpty(addlButtons)) {
                me.insert(
                    0,
                    addlButtons
                );
            }

            me.show();
            g_OsLogger.info("Footer Created",this,{methodName:'repaint',actionButtons:oneShieldDesktop.actionBarButtons,actionButtonsLevel3:oneShieldDesktop.actionBarLevel3Buttons});
        } else {
            me.hide();
            g_OsLogger.error("No items to show in Footer",this,{methodName:'repaint',actionButtons:oneShieldDesktop.actionBarButtons,actionButtonsLevel3:oneShieldDesktop.actionBarLevel3Buttons});
        }

    }
});