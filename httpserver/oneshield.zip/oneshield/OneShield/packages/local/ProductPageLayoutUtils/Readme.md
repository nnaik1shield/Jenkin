# ProductPageLayoutUtils - Read Me

# Contains all the custom widgets, blocks, overrides, controllers etc. which are applicable for page layout viewport. This can be re-used for other applications having page layout viewport.