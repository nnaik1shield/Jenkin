Ext.namespace('Ext.theme.is')['OSPortalCustMob'] = true;
Ext.theme.name = 'OSPortalCustMob';