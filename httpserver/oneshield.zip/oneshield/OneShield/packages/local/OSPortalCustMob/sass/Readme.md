# OSPortalCustMob/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    OSPortalCustMob/sass/etc
    OSPortalCustMob/sass/src
    OSPortalCustMob/sass/var
