# BaseWidgets/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    BaseWidgets/sass/etc
    BaseWidgets/sass/src
    BaseWidgets/sass/var
