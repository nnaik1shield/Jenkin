/**
 * @class Dragon.view.widget.WatermarkText
 * @extends Dragon.view.widget.Text
 * A class to create text field with placeholder text which will disappear once the user enters the value
 */
Ext.define('Dragon.view.widget.WatermarkText', {
    extend: 'Dragon.view.widget.Text',
    alias: 'widget.oswatermarkfield',
    mixins: ['Dragon.view.widget.Mixin'],
    config: {
        commonConfigObj: {},
        fieldObject: {},
        parentObject: {},
        paramsObj: {}
    },
    /*
    * Ashish Badoni
    */
    cls: 'waterMarkTxtCls',
    /**
     * @method initComponent
     * Function initializes an text field component.
     */
    initComponent: function () {
        g_OsLogger.info("Text component is initialised", this, {
            methodName: 'initComponent'
        });
        
        this.callParent(arguments);
    },
	/**
     * @method onAfterRender 
     * This method is called after execution of widget class afterRender method.
     * This method adds tooltip to widget (If tooltip is not required then noToolTip config is set
     * as true to that widget)
     */
    afterRender: function () {
        var me = this;
        this.callParent(arguments);
		this.addPlaceholder();
    },
	/**
     * @method addPlaceholder
     * This method adds Placeholder to the dom object of the widget 
     */
    addPlaceholder: function () {
        // var placeholderValue = this.fieldLabel;
        var placeholderValue = this.OsCellObj.label;
        if (!Ext.isEmpty(placeholderValue)) {
            var placeholderEl = this.bodyEl.el.query('input', false)[0];
            if (Ext.isEmpty(placeholderEl)) {
                g_OsLogger.warn("placeholderEl is set as null",
                    this, {
                        methodName: 'addPlaceholder',
                        id: this.parentObject.pageLayoutCellId
                    });
            } else {
            	var logObj = {
	                    methodName: 'Dragon.view.widget.WatermarkText.addPlaceholder',
	                    placeholder: placeholderValue
	                };
                placeholderEl.dom.setAttribute('placeholder', placeholderValue);
            }
        }
    }
});
