/**
 * @class Dragon.view.DocumentIframeBlock
 * @extends Ext.panel.Panel
 * Block load an document in an Iframe, source URL of the document will be provided to load the content
 */
Ext.define('Dragon.view.DocumentIframeBlock', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.documentIframeBlock',
    mixins: ['Dragon.view.BlocksMixin'],
    requires:['Ext.ux.IFrame'],
    config: {
        blockObj: {}
    },
    /**
     * @method initComponent
     * This function is responsible for creating the component based on the type received from the backend.
     */
    initComponent: function() {
        
    	var me = this;
    	
    	//create an array of items which need to be pushed into this block
        var blkItemsArray = [];
        
        // this is the source URL of the document which need to be loaded into the block
        // this block must have only one cell and value of cell must be source URL of the document

         var docID = ' ';
		 var url ='';
        
        
        if(this.blockObj && this.blockObj.cellRows && this.blockObj.cellRows.length > 0 && this.blockObj.cellRows[0].cells && this.blockObj.cellRows[0].cells.length > 0)
        {
        	if(this.blockObj.cellRows[0].cells[0].value != undefined)
        	{
        		docID = this.blockObj.cellRows[0].cells[0].value;
				url = "/oneshield/DocGenServlet?" +
						"docId=" + docID +
						"&USER_SESSION_GUID=" + encodeURIComponent(Dragon.config.Runtime.getUserSessionGUID()) +
						"&DRAGON_TRANSACTION_ID=" + Dragon.config.Runtime.getTransactionId();
						
			      if(this.blockObj.cellRows[1] != undefined && this.blockObj.cellRows[1].cells[0].value != undefined)
            {
					    url = url + "&DISPOSITION_TYPE=" + this.blockObj.cellRows[1].cells[0].lookups[0].displayValue;
				    } 
        	}
        }
        
        // create an IFrame item
        var documentIframe = new Ext.ux.IFrame({
            src: url,
            style: me.blockObj.uiStyle
        });
        
        blkItemsArray.push(documentIframe);
        
        this.items = blkItemsArray;
        this.callParent(arguments);
    }
});
