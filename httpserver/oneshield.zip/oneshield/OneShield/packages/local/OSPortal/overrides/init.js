Ext.namespace('Ext.theme.is')['OSPortal'] = true;
Ext.theme.name = 'OSPortal';