/**
 * @class Dragon.view.BetterviewIframeBlock
 * @extends Ext.panel.Panel
 * Block load an document in an Iframe, source URL of the document will be provided to load the content
 */
Ext.define('Dragon.view.BetterviewIframeBlock', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.betterviewIframeBlock',
    mixins: ['Dragon.view.BlocksMixin'],
    requires:['Ext.ux.IFrame'],
    config: {
        blockObj: {}
    },
    /**
     * @method initComponent
     * This function is responsible for creating the component based on the type received from the backend.
     */
    initComponent: function() {
    	
		var me = this;
        
    	//create an array of items which need to be pushed into this block
        var blkItemsArray = [];
        
        // this is the source URL of the document which need to be loaded into the block
        // this block must have only one cell and value of cell must be source URL of the document
        var iFrameURL = "";
        var inputArr = [];
        var outputArr = [];
        var actionLabel = "";
        var label = "";
        var params = "?";
        var ALLOWED_ORIGIN = "";
        
        if(this.blockObj && this.blockObj.cellRows && this.blockObj.cellRows.length > 0)
        {
            var cellRowsArr = this.blockObj.cellRows;

            cellRowsArr.map(cellRow => {
                if(cellRow.cells && cellRow.cells.length > 0)
                {                    
                    var cellArr = cellRow.cells
                    cellArr.map(cell => {
                        label = cell.label.toLowerCase();
                        if(cell.value != undefined && label.startsWith("in")){                            
                            if(label.slice(2) == "url"){
                                iFrameURL = cell.value
                            } else if(label.slice(2) == "allowedorigin"){
                                ALLOWED_ORIGIN = cell.value
                            } else {
                                inputArr.push(cell.label.slice(2))
                            }
                        } else if(cell.actionOne != undefined && label == "submitaction") {
                            actionLabel = cell.label
                        } else if(label.startsWith("out")){
                            outputArr.push(cell.label.slice(3))
                        }
                    })
                }
            })

            inputArr.map(labelValue => {
                if (params != "?"){
                    params = `${params}&`
                }
                label = `in${labelValue}`
                params = `${params}${labelValue}=${Dragon.view.common.ViewHelper.findCellValueByLabel(this.blockObj, label)}`
            })
    
            iFrameURL = `${iFrameURL}${params}`
        }      

        const flattenObj = (ob) => { 
            let result = {}
            if((typeof ob) === 'string' || (typeof ob) === 'number' || (typeof ob) === 'boolean'){
                return {message:ob}
            }
            if ((typeof ob) !== 'object') {
                return undefined
            }         
            for (const i in ob) {
                if ((typeof ob[i]) === 'object' && !Array.isArray(ob[i])) {
                    const tempObj = flattenObj(ob[i])
                    for (const j in tempObj) {
                        result[i + '.' + j] = tempObj[j]
                    }
                }         
                else {
                    result[i] = ob[i]
                }
            }
            return result
        }

        const sendData = (data, outBV) => {
            if(data !== undefined){
                outBV.map(label => {
                    if(label in data){
                        var cell = Dragon.view.common.ViewHelper.findCellByAttribute(this.blockObj, 'label', `out${label}`);
                        var cellBVName = cell.varName;
                        Dragon.util.OSFormUtils.addHiddenParam(cellBVName, '', true);
                        var cellField = Dragon.util.OSFormUtils.getBvElement(cell.varName);
                        if (cellField != null) {
                            cellField.setValue(data[label]);
                        } else {
                            cellField.setValue('');
                        }
                    } else {
                        var cell = Dragon.view.common.ViewHelper.findCellByAttribute(this.blockObj, 'label', `out${label}`);
                        var cellBVName = cell.varName;
                        Dragon.util.OSFormUtils.addHiddenParam(cellBVName, '', true);
                    }
                })                
            }            
        }

        const submitData = (action) => {
            var actionCell = Dragon.view.common.ViewHelper.findCellByAttribute(this.blockObj, 'label', action);
            var actionCellBVName = actionCell.varName;
            Dragon.util.OSFormUtils.addHiddenParam(actionCellBVName, '', true);
            var actionField = Dragon.util.OSFormUtils.getBvElement(actionCell.varName);
            if (actionField != null) {
                Dragon.util.OSFormUtils.submitForm(actionCell.actionOne, '1', 'null', '');
            }
        }

        //Code from here is specific to betterview        
        const BETTERVIEW_MESSAGE_STATUS = "betterview-order-complete";
        
        window.onmessage = function(event){
            if(event.origin == ALLOWED_ORIGIN){
                data = flattenObj(event.data)
                if(data.type == BETTERVIEW_MESSAGE_STATUS){
                    sendData(data, outputArr)
                    submitData(actionLabel)
                }                        
            }                
        }         
        
        // create an IFrame item
        var documentIframe = new Ext.ux.IFrame({
            src: iFrameURL,
            style: me.blockObj.uiStyle
        });
        
        blkItemsArray.push(documentIframe);
        
        this.items = blkItemsArray;
        this.callParent(arguments);
    }
     
});
