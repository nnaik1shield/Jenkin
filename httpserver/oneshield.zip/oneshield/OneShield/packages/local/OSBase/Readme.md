# OSBase
#### Created on 23 August, 2017 By Debabrata Sarker.

#### This theme extends core theme "OSCore".

* "package.json" - This is the package definition file. It tells Sencha Cmd certain things about the package like its name and dependencies (i.e., the packages it requires, which theme it extends from).

* "sass/" - This directory contains all of your theme's Fashion source files. The source files are divided into 3 main sections:

  * sass/var/ - This directory contains the theme variables. Theme variables are variables          specific to a component that defines one of the layout attributes of the component. These       variables can further be used within component's css classes.

    * sass/var/all.scss - It contains all the sass theme variables related to components/Widgets

	  For example: 

		$breadcrumb-bar-height: 31px;
		$breadcrumb-bar-padding-left: 22px;

  * sass/src/ - This directory contains the rules and mixins calls that can use the variables       defined in sass/var

	  * sass/src/all.scss - It contains the mixins and css rules. In this file, we are creating the   mixins based on the component/widget wise and write the css rules inside the mixins

		For example: 

		@mixin breadcrumb {
    		div#os-bread-crumb-bar {
        		height: $breadcrumb-bar-height;
        		padding-left: $breadcrumb-bar-padding-left;
				}
    }
	  @include breadcrumb;

  * sass/etc/ - This directory contains the additional utility functions or mixins.

* "resources/" - Images and other static resources.

* "overrides/" - JavaScript overrides to Ext JS component classes.