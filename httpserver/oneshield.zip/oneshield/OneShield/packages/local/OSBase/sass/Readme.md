# OSBase/sass

### This folder contains SASS files of various kinds, organized in sub-folders:

* OSTheme/sass/etc - This folder contains all.scss file to provids extjs default css classes, variables and custom css class styles. 
* OSTheme/sass/src - This folder contains ext default folder sturectured folders depending on component styles and You can overrid here component default css class styles.
* OSTheme/sass/var - This folder contains ext default folder sturectured folders depending on component styles and You can overrid here component default scss variables.