# OSBase/sass/etc

This folder contains miscellaneous SASS files. Unlike `"OSBase/sass/etc"`, these files
need to be used explicitly.
* all.scss/ - File contains extjs default css class styles, custom styles and custom scss global variables
