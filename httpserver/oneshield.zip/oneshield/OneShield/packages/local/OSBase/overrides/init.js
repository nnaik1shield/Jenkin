Ext.namespace('Ext.theme.is')['OSBase'] = true;
Ext.theme.name = 'OSBase';