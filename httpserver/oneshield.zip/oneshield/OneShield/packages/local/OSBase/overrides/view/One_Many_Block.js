Ext.define('Dragon.overrides.view.One_Many_Block', {
    override: 'Dragon.view.One_Many_Block',
    
    applyParBlockTitle: function () {
        var me = this;
        
        if (!Ext.isEmpty(me.parBlock.title)) {

            if (me.blockObj.grid.totalRows > 0 && me.blockObj.showListControls != 0) {
                var ofStr = Localize.processLocalStr('of');
                if (me.blockObj.grid.listThresholdExceeded) {
                	me.parBlock.title =
                        me.parBlock.title +
                        ' ' +
                        me.blockObj.grid.startRow +
                        ' - ' +
                        me.blockObj.grid.endRow +
                        ' ' + ofStr + ' ' +
                        Localize.processLocalStr('Many');
                } else {
                	me.parBlock.title =
                        me.parBlock.title +
                        ' ' +
                        me.blockObj.grid.startRow +
                        ' - ' +
                        me.blockObj.grid.endRow +
                        ' ' + ofStr + ' ' +
                        me.blockObj.grid.totalRows;
                }
                g_OsLogger.debug("Applying the title for grid", this, {
                    methodName: 'applyParBlockTitle',
                    objectId: me.blockObj.objectId,
                    id: me.blockObj.id,
                    label: me.blockObj.label,
                    title: me.parBlock.title
                });
            }
        }
        this.setTitle(me.parBlock.title);
    }
});
