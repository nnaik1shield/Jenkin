/**
 * @class Dragon.view.widget.ActionButton
 * @extends Ext.button.button
 * This class creates action button instance on the screen.
 * Here we have two types of button configuration are available.
 * One is the cell level(cellObj) and second one(btnObj) is static component level ( Header, Footer ).
 */
Ext.define('Dragon.view.widget.PaymentProviderBtn', {
    extend: 'Ext.button.Button',
    alias: 'widget.osPaymentProviderBtn',
    mixins: ['Dragon.view.widget.Mixin'],
    config: {
        commonConfigObj: {},
        btnObj: {},
        cellObj: {},
        paramStyleObj: {},
        addlConfig: {},
        paramsObj: {},
        OsCellObj: {}
    },
    handler : function() 
    {
        var objId = this.objectId,
            fldPayIQurl = OSFormUtils.getBvElement('bv_'+objId+'_32892448'),
            fldPayIQurl2 = OSFormUtils.getBvElement('bv_'+objId+'_32892448'),
            fldAccessToken = OSFormUtils.getBvElement('bv_'+objId+'_32892548'),
            fldAccessToken2 = OSFormUtils.getBvElement('bv_'+objId+'_32892548'), 
            fldName = OSFormUtils.getBvElement('bv_'+objId+'_32833940'),
            fldCard = OSFormUtils.getBvElement('bv_'+objId+'_32835640'),
            fldMnth = OSFormUtils.getBvElement('bv_'+objId+'_30011246'),
            fldYear = OSFormUtils.getBvElement('bv_'+objId+'_30011146'),
            fldCvv = OSFormUtils.getBvElement('bv_'+objId+'_30010946'),
            fldState = OSFormUtils.getBvElement('bv_'+objId+'_32972648p33024848'),
            fldCity = OSFormUtils.getBvElement('bv_'+objId+'_32972648p29326314'),
            fldZip = OSFormUtils.getBvElement('bv_'+objId+'_32972648p29327414'),
            fldAddress = OSFormUtils.getBvElement('bv_'+objId+'_32972648p29325214'),
            fldErrCode = OSFormUtils.getBvElement('bv_'+objId+'_32788908'),
            fldErrors = OSFormUtils.getBvElement('bv_'+objId+'_32789008'),
            fldDescription = OSFormUtils.getBvElement('bv_'+objId+'_32788608'),
            fldPayer = OSFormUtils.getBvElement('bv_'+objId+'_32689146'),
            fldRountingNumber = OSFormUtils.getBvElement('bv_'+objId+'_30011346'),
            fldAccountNumber = OSFormUtils.getBvElement('bv_'+objId+'_30011946'),
            fldBankName = OSFormUtils.getBvElement('bv_'+objId+'_30011446'),
            fldFirstName = OSFormUtils.getBvElement('bv_'+objId+'_30743846'),
            fldLastName = OSFormUtils.getBvElement('bv_'+objId+'_30743946'),
            fldAccountType = OSFormUtils.getBvElement('bv_'+objId+'_30011646'),
            fldRetTempToken = OSFormUtils.getBvElement('bv_'+objId+'_32892648'),
            fldCompanyName = OSFormUtils.getBvElement('bv_'+objId+'_32689246'),
            fldRetTempToken2 = OSFormUtils.getBvElement('bv_'+objId+'_32892648');
            fldDisClaimer = OSFormUtils.getBvElement('bv_'+objId+'_33039648').getFieldValue();
		
            
            
            // console.log("Payer",fldPayer.getValue());
            // if(
            //  this.validateRequired(fldAccessToken,'Access Token') == false || 
            //  this.validateRequired(fldName,'Name') == false || 
            //  this.validateRequired(fldCard,'Card') == false || 
            //     this.validateRequired(fldMnth,'Month') == false || 
            //     this.validateRequired(fldYear,'Year') == false || 
            //  this.validateRequired(fldCvv,'cvv ') == false ||
            //     this.validateRequired(fldState,'State') == false || 
            //  this.validateRequired(fldCity,'city') == false || 
            //  this.validateRequired(fldZip,'zip') == false || 
            //  this.validateRequired(fldAddress,'address ') == false
            // )
            // {
            //  return;
            // }
            //Credit card
           // alert(fldPayer.getValue());
            if ( document.querySelectorAll('input[name*="30010546"]')[1].checked == true &&
               ( this.validateRequired(fldAccessToken,'Access Token') == false || 
                this.validateRequired(fldName,'Name') == false || 
                this.validateRequired(fldCard,'Card') == false || 
                this.validateRequired(fldMnth,'Month') == false || 
                this.validateRequired(fldYear,'Year') == false || 
                this.validateRequired(fldCvv,'cvv ') == false ||
                this.validateRequired(fldState,'State') == false || 
                this.validateRequired(fldCity,'city') == false || 
                this.validateRequired(fldZip,'zip') == false || 
                this.validateRequired(fldAddress,'address ') == false ||
				this.validateTnC(fldDisClaimer,0) == false)
            ) {
				
                return;
            }
             else if ( document.querySelectorAll('input[name*="30010546"]')[2].checked == true && fldPayer.getValue() == "1" &&//ACH
                (this.validateRequired(fldAccessToken2,'Access Token') == false || 
                this.validateRequired(fldPayer,'Payer') == false || 
                this.validateRequired(fldFirstName,'First Name') == false || 
                this.validateRequired(fldLastName,'Last Name') == false || 
                this.validateRequired(fldRountingNumber,'Routing Number') == false || 
                this.validateRequired(fldBankName,'Bank Name') == false ||
                this.validateRequired(fldAccountNumber,'Account Number') == false ||
                this.validateRequired(fldAccountType,'Account Type') == false  ||
			    this.validateTnC(fldDisClaimer,1) == false )
                // this.validateRequired(fldCompanyName, 'Company Name') == false
                // this.validateRequired(fldFirstName,'First Name') == false ||
                // this.validateRequired(fldLastName,'Last Name') == false || 
                // this.validateRequired(fldUsageType,'Usage Type') == false
            ) {
				
               return;
            }
            else if(document.querySelectorAll('input[name*="30010546"]')[2].checked == true && fldPayer.getValue() == "2" &&
                 (          this.validateRequired(fldAccessToken2,'Access Token') == false || 
                this.validateRequired(fldPayer,'Payer') == false || 
                this.validateRequired(fldRountingNumber,'Routing Number') == false || 
                this.validateRequired(fldBankName,'Bank Name') == false ||
                this.validateRequired(fldAccountNumber,'Account Number') == false ||
                this.validateRequired(fldAccountType,'Account Type') == false ||
                this.validateRequired(fldCompanyName, 'Company Name') == false ||
				this.validateTnC(fldDisClaimer,1) == false)
                ) {
				   
                    return;
              }
        if(document.querySelectorAll('input[name*="30010546"]')[2].checked == true){
                onPayIqSuccess = function(temporaryToken) 
            {
                console.log('obtained temporaryToken '+temporaryToken);
                fldRetTempToken2.setValue(temporaryToken);
                fldRetTempToken2.OsCellObj = fldRetTempToken2.paramsObj.OsCellObj;
                Dragon.view.common.Functions.bkupField(fldRetTempToken2.name, temporaryToken, fldRetTempToken2);
                // fldRountingNumber.setValue('');
                // fldAccountNumber.setValue('');
                 var myBtn = window['payiq-btn'];
                // var actionSpec =  myBtn.OsCellObj.actionButton;
                // var actionId = myBtn.OsCellObj.actionId;
                 Dragon.util.OSFormUtils.submitForm(
                            myBtn.OsCellObj.actionOne,
                            '');
             };
            var paymentAccount = {};
            if(document.querySelectorAll('input[name*="30010546"]')[2].checked == true && fldPayer.getValue() == "1"){
                Ext.apply( paymentAccount,{
                    AchAccountNumber: fldAccountNumber.getValue(),
                    AchRoutingNumber: fldRountingNumber.getValue(),
                    Name: fldFirstName.getValue() + ' ' + fldLastName.getValue(),
                    AccountType: fldAccountType.getValue(),
                    AchType: fldAccountType.getValue(),
                    // AchType: '2',
                    // AchUsageType: fldPayer.getValue()
                    AchUsageType: '1'
                });
            }
            else if(document.querySelectorAll('input[name*="30010546"]')[2].checked == true && fldPayer.getValue() == "2"){
                Ext.apply( paymentAccount,{
                    AchAccountNumber: fldAccountNumber.getValue(),
                    AchRoutingNumber: fldRountingNumber.getValue(),
                    Name: fldCompanyName.getValue(),
                    AccountType: fldAccountType.getValue(),
                    AchType: fldAccountType.getValue(),
                    AchUsageType: '2'
                });
            }
             window['payiq-btn'] = this;
             this.disable();
             //generalize this post URL as a system attribute and let it read by the backend.
             PayIQ.PaymentAccount.submit(fldPayIQurl2.getValue(), fldAccessToken2.getValue(), paymentAccount, onPayIqSuccess, this.onPayIqError);
        }
        else if(document.querySelectorAll('input[name*="30010546"]')[1].checked == true){
            onPayIqSuccess = function(temporaryToken) 
            {
                 console.log('obtained temporaryToken '+temporaryToken);
                 fldRetTempToken.setValue(temporaryToken);
                 fldRetTempToken.OsCellObj = fldRetTempToken.paramsObj.OsCellObj;
                 Dragon.view.common.Functions.bkupField(fldRetTempToken.name, temporaryToken, fldRetTempToken);
                 fldCard.setValue('');
                 fldCvv.setValue('');
                //  fldExp.setValue('');
                 var myBtn = window['payiq-btn'];
                // var actionSpec =  myBtn.OsCellObj.actionButton;
                // var actionId = myBtn.OsCellObj.actionId;
                 Dragon.util.OSFormUtils.submitForm(
                            myBtn.OsCellObj.actionOne,
                            '');
             };
            var paymentAccount = {};
            Ext.apply( paymentAccount,{
                CcAccountNumber:fldCard.getValue(),
                CcExpirationDate: fldMnth.getValue() + '/' + fldYear.getValue().substring(2),
                CcCVV: fldCvv.getValue(),
                Name: fldName.getValue(),
                Address: fldAddress.getValue(),
                City: fldCity.getValue(),
                State: fldState.getValue(),
                Zip: fldZip.getValue()
            });
            // console.log(fldPayIQurl.getValue());
            // console.log(fldAccessToken.getValue());
            // console.log("Payment account",paymentAccount);
            // console.log("Payment success", onPayIqSuccess);
            // console.log("CVV",fldCvv.getValue());
            // console.log("Card",fldCard.getValue());
             window['payiq-btn'] = this;
             this.disable();
            //  console.log('using post url '+fldPayIQurl.getValue());
             //generalize this post URL as a system attribute and let it read by the backend.
             PayIQ.PaymentAccount.submit(fldPayIQurl.getValue(), fldAccessToken.getValue(), paymentAccount, onPayIqSuccess, this.onPayIqError);
        }
    },
     onPayIqError: function(errorCode, errors, validationErrors){
        var errorMessage = "";
        console.log(errorCode, errors, validationErrors);
        if (errors) {
            $.each(errors, function (i, e) {
                errorMessage += e + ". ";
            });
        }
        if (validationErrors) {
            $.each(validationErrors, function (i, e) {
                errorMessage += "Validation on " + e.Field + " failed: " + e.Message + ".\n ";
            });
        }
       // this.enable();
        alert(errorMessage);
        var myBtn = window['payiq-btn'];
        myBtn.enable();
        //$("#errors").removeClass("hidden").html(errorCode + " error returned. " + errorMessage);
       // $("form input, form button, form select").prop("disabled", false);
       // $("#wait-notice").addClass("hidden");
    },
    validateRequired: function(fld,name)
    {
        if( fld == null || Ext.isEmpty(fld.getValue()) )
        {
            alert("Required field "+name);
            return false;
        }
        return true;
    },
	validateTnC: function(fld,index)
    {    if(fld == null)
             {
                 alert("Please accept the Disclaimer Checkbox");
                 return false;
             }
      
        return true;
    },
    /**
     * @method initComponent
     * Function initializes a component.
     */
    initComponent: function () {
        this.cellObj = (Ext.isEmpty(this.paramsObj)) ? this.paramsObj : this.paramsObj.OsCellObj;
        this.OsCellObj = this.cellObj;
        var me = this,
            cellObj = this.cellObj,
            btnObj = this.btnObj,
            buttonProperties = {};
        if(Ext.isGecko){
            this.cls = ((this.cls)?this.cls:"") + " os-cell-button-gecko";
        }
        if (!Ext.isEmpty(cellObj)) {
            if (cellObj.actionButton) {
                for(var attr in cellObj.actionButton) {
                    cellObj[attr] = cellObj.actionButton[attr];
                }
            }
            if (cellObj.actionButton && cellObj.actionButton.helpText) {
                cellObj['mouseoverMesg'] = {
                    'content': cellObj.actionButton.helpText
                };
            }
            if (cellObj.current) {
                this.cls = ((this.cls)?this.cls:"") + " plc-current";
            }
            this.paramStyleObj = {
                'cls': 'os-cell-action-button'
            };
            if (!Ext.isEmpty(cellObj.id)) {
                buttonProperties.id = VIEWCONSTANTS.CELL_ACTION_BUTTON_IDPREFIX +
                    '-' + cellObj.id;
            }
            buttonProperties.text = cellObj.label;
            if (!Ext.isEmpty(cellObj.mouseoverMesg) &&
                !Ext.isEmpty(cellObj.mouseoverMesg.content)) {
                buttonProperties.mouseoverMesg = cellObj.mouseoverMesg;
            }
            if (!Ext.isEmpty(cellObj.uiStyle)) {
                // To be applied ui on button
                var uiStyle = Dragon.view.common.Functions.getUiMixin(cellObj.uiStyle);
                if (!Ext.isEmpty(uiStyle)) {
                    buttonProperties.ui = uiStyle;
                }
                /* remove mixin: prefix if it was defined before applying as inline style*/
                var uiInlineStyle = Dragon.view.common.Functions.getUiExcludingMixin(cellObj.uiStyle);
                if (!Ext.isEmpty(uiInlineStyle)) {
                    buttonProperties.style = uiInlineStyle;
                }
            }
            if (!Ext.isEmpty(cellObj.iconPath)) {
                var skinPath = Dragon.util.OSFormUtils.getBvElement('CURRENT_SKIN').getValue();
                buttonProperties.icon = skinPath + '/icons/' + cellObj.iconPath;
                if (!Ext.isEmpty(cellObj.iconPosition)) {
                    buttonProperties.iconAlign = cellObj.iconPosition;
                }
            }
            Ext.applyIf(buttonProperties, this.prepareAdditionalProperties(cellObj));
            g_OsLogger.debug("Cell (cellObj) level action button has configured", this, {
                methodName: 'initComponent',
                id: cellObj.id,
                buttonText: cellObj.text,
                buttonObjectId: cellObj.objectId
            });
        } else if (!Ext.isEmpty(btnObj)) {}
        Ext.apply(buttonProperties, this.addlConfig);
        Ext.apply(me, buttonProperties);
        this.callParent(arguments);
        g_OsLogger.info("ActionButton component has been initialized", this, {
            methodName: 'initComponent'
        });
    },
    /**
     *@method getOsViewIdVal
     * This method returns the osViewId
     */
    getOsViewIdVal: function () {
        var cellObj = this.cellObj;
        var btnObj = this.btnObj;
        var immutableStaticId = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE + (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]) + 
        VIEWCONSTANTS.UNDERSCORE;
        if (!Ext.isEmpty(cellObj)) {
            return immutableStaticId + this.commonConfigObj.immutableStaticIdPrefix + VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.CELL_ID + VIEWCONSTANTS.UNDERSCORE + 
                cellObj.pageLayoutCellId;
        } else if (!Ext.isEmpty(btnObj)) {
            if(this.commonConfigObj) {
                // append immutable prefix for row level buttons configured as subblocks in case of labels as left/top
                if(this.commonConfigObj.immutableStaticIdPrefix) {
                    immutableStaticId = immutableStaticId + this.commonConfigObj.immutableStaticIdPrefix + VIEWCONSTANTS.UNDERSCORE;
                }
                // append block id for block level buttons && row level buttons configured as subblocks in case of labels as left/top
                if(this.commonConfigObj.blockId) {
                    immutableStaticId = immutableStaticId + VIEWCONSTANTS.BLOCK_ID + VIEWCONSTANTS.UNDERSCORE + this.commonConfigObj.blockId + VIEWCONSTANTS.UNDERSCORE;
                }
            }
            return  immutableStaticId + VIEWCONSTANTS.ACTION_BUTTON + VIEWCONSTANTS.UNDERSCORE + btnObj.id;
        }
        return null;
    },
    /**
     *@method getOsViewIdVal
     * This method returns the dom element el object where the osViewId attribute has to be added
     */
    getOsViewIdEl: function () {
        return this.btnInnerEl.el;
    },
    /**
     * Call the handleCellLevelButtonWidth method to update button width
     * Apply alignment and justification for text by adding cls based on metadata configuration 
     * @template
     * @protected
     */
    afterRender: function () {
        var me = this;
        me.callParent(arguments);
        g_OsLogger.info("ActionButton component was rendered on the screen", me, {
            methodName: 'afterRender',
            id: me.id,
            buttonText: me.text
        });
        APPUTILS.handleCellLevelButtonWidth(this);
        if (!Ext.isEmpty(me.cellObj) &&
           ( !Ext.isEmpty(me.cellObj.valueVerticalAlignment) ||
             !Ext.isEmpty(me.cellObj.valueHorizontalJustification)
           )
        ) {
           this.applyBtnValueAlignJustify();
        }
    },
    /**
     * @private
     * Method to prepare additional properties for Action button
     */
    prepareAdditionalProperties: function (cellObj) {
        g_OsLogger.info("Method to prepare additional properties for Action button", this, {
            methodName: 'prepareAdditionalProperties'
        });
        var additionalProperties = {};
        if (!Ext.isEmpty(cellObj)) {
            if (!Ext.isEmpty(cellObj.hyperLinkObjectId)) {
                Ext.apply(additionalProperties, {
                    'objectId': cellObj.hyperLinkObjectId
                });
            } else if (!Ext.isEmpty(cellObj.value)) {
                Ext.applyIf(additionalProperties, {
                    'objectId': cellObj.value
                });
            } else if (!Ext.isEmpty(cellObj.objectId)) {
                Ext.applyIf(additionalProperties, {
                    'objectId': cellObj.objectId
                });
            }
            if (!Ext.isEmpty(cellObj.ui)) {
                additionalProperties.ui = cellObj.ui;
            }
            // For finding / querying cell based on 'cellId' 
            if (!Ext.isEmpty(cellObj.cellId)) {
                additionalProperties.cellId = cellObj.cellId;
            }
        }
        return additionalProperties;
    },
    /**
     * @private
     * Method to prepare additional styles from stylesObj object
     */
    prepareAdditionalStyleProperties: function (stylesObj) {
        g_OsLogger.info("Method to prepare additional styles from stylesObj object", this, {
            methodName: 'prepareAdditionalStyleProperties'
        });
        var additionalStyleProperties = {};
        if (!Ext.isEmpty(stylesObj)) {
            if (stylesObj.hasOwnProperty('cls')) {
                additionalStyleProperties.cls = stylesObj['cls'];
            }
            if (stylesObj.hasOwnProperty('focusCls')) {
                additionalStyleProperties.focusCls = stylesObj['focusCls'];
            }
            if (stylesObj.hasOwnProperty('overCls')) {
                additionalStyleProperties.overCls = stylesObj['overCls'];
            }
            if (stylesObj.hasOwnProperty('iconCls')) {
                additionalStyleProperties.iconCls = stylesObj['iconCls'];
            }
            if (!Ext.isEmpty(this.btnObj) &&
                Ext.isEmpty(this.btnObj.uiStyle) &&
                stylesObj.hasOwnProperty('style')) {
                additionalStyleProperties.style = stylesObj['style'];
            }
        }
        return additionalStyleProperties;
    },
    /**
     * @method skipMandatoryCheckForThisWidget
     * To skip mandatory check for this widget 
     * To skip Field Processor Servlet call for this widget
     */
    skipMandatoryCheckForThisWidget: function () {
        g_OsLogger.info('Function to skip mandatory check for this widget', this,
            {
                methodName: 'skipMandatoryCheckForThisWidget'
            });
        return true;
    },
    applyCellAlignJustification:function(rowTRHeight,rowTDWidth){
        this.mixins['Dragon.view.widget.Mixin'].applyBtnAlignJustification.call(this,rowTRHeight, rowTDWidth);
    },
    resetCellAlignJustification: function(){
        this.mixins['Dragon.view.widget.Mixin'].resetBtnAlignJustification.call(this);
    }
});
    
    
  
  

