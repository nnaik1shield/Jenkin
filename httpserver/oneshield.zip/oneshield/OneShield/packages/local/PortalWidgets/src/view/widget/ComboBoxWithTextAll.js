/**
 * @class Dragon.view.widget.ComboBoxWithTextAll
 * @extends Ext.form.field.ComboBoxWithTextAll
 * A class to create select field with required features
 * It will generate either static store or dynamic store
 */
Ext.define('Dragon.view.widget.ComboBoxWithTextAll', {
    extend: 'Dragon.view.widget.ComboBox',
    alias: 'widget.osComboBoxWithTextAll',
    mixins: ['Dragon.view.widget.Mixin'],
    config: {
        commonConfigObj: {},
        /**
         * @cfg {Object}
         * A custom config to store field configs comes from backend
         */
        fieldObject: {},
        /**
         * @cfg {Object}
         * A custom config to store parent configs comes from backend
         */
        parentObject: {},
        /**
        * @cfg {Object}
        * A custom config to check if ComboBoxWithTextAll is searchable lookup or not
        */
        isSearchableLookup: false,
    },
    cls: 'osComboBoxWithTextAll',
       /**
     * @method initComponent
     * Function intializes a  component.
     */
    initComponent: function () {
        g_OsLogger.info("Text component is initialised", this, {
            methodName: 'initComponent'
        });
        
        this.callParent(arguments);
    },
       /**
     * @method configureStoreData
     * To generate static store data.
     * @param cellObj parent level object
     * @return {Array}
     */
    configureStoreData: function (cellObj) {
        if(!Ext.isEmpty(cellObj.lookups) && cellObj.lookups[0].code == "0"){
               cellObj.lookups[0].displayValue = "All";
         }

         return this.callParent(arguments);
        },
    /**
     * @private 
     * Fire on after field rendered
     * Check for field is in responsive block.
     * Check for size and trigger element
     * Summarize the given size and trigger width into calculated Width
     * Apply calculated width on field body
     */
    afterRender: function () {
        var me = this;
        this.callParent(arguments);
        
    }
});
