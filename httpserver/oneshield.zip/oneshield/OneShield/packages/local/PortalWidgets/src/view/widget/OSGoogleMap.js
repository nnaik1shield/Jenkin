/**
 * @class Dragon.view.widget.OSGoogleMap
 * @extends Ext.ux.IFrame
 * This class is responsible for rendering the OSGoogleMap field
 */
Ext.define('Dragon.view.widget.OSGoogleMap', {
	extend: 'Ext.ux.IFrame',
	alias: 'widget.OSGoogleMap',
	mixins: ['Dragon.view.widget.Mixin', 'Dragon.view.BlocksMixin'],
	config: {
		commonConfigObj: {},
		parentObject: {},
		lookupObj: {},
		listSize: null,
		noTooltip: true
	},
	initComponent: function () {
		this.callParent(arguments);
		var destinationAddress = this.blockObj.cellRows[0].cells[0].value;
		var mapHtmlFileLocation = Ext.getResourcePath("OSGoogleMap.html", null, "PortalWidgets");
		this.src = mapHtmlFileLocation + "?destination=" + destinationAddress;
	},
})