/**
 * @class Dragon.view.widget.ImageComboBox
 * @extends Ext.form.field.ImageComboBox
 * A class to create select field with required features
 * It will generate either static store or dynamic store
 */
Ext.define('Dragon.view.widget.ImageComboBox', {
    extend: 'Dragon.view.widget.ComboBox',
    alias: 'widget.osImageComboBox',
    mixins: ['Dragon.view.widget.Mixin'],
    listConfig: {
            getInnerTpl: function () {
                var tpl = '<div>'+
                '<img src="'+GFlags.skin_path+'/resources{displayImage}">&nbsp;&nbsp;'+
                '{displayText}</div>';
                return tpl;
                
                }
    },
    config: {
        commonConfigObj: {},
        /**
         * @cfg {Object}
         * A custom config to store field configs comes from backend
         */
        fieldObject: {},
        /**
         * @cfg {Object}
         * A custom config to store parent configs comes from backend
         */
        parentObject: {},
        /**
        * @cfg {Object}
        * A custom config to check if ImageComboBox is searchable lookup or not
        */
        isSearchableLookup: false,
    },
    listeners: {
     
        afterrender: function(field, newValue, oldValue, eOpts) {
            let seletedValue = this.getValue();
        	 /*Getting the value of the selected list item from the lookup list*/
             let selectedCountryObj = this.initialList.find((obj)=>{
                return obj.code == seletedValue && obj.code != 0;
            });
          
            /*Condition to check if the selected item has an image or not*/
            if(selectedCountryObj && selectedCountryObj.itemImageName){
                this.setStyle("background-image",'url('+ GFlags.skin_path + "/resources" + selectedCountryObj.itemImageName +')');
                this.addCls("flagImage");
            }
            else{
                this.setStyle("background-image",null);
                this.removeCls("flagImage");
            }
        },
        change: function(field, newValue, oldValue, eOpts) {
            /*Getting the value of the selected list item from the lookup list*/
            let selectedCountryObj = this.initialList.find((obj)=>{
                return obj.code == newValue && obj.code != 0;
            });
            /*Condition to check if the selected item has an image or not*/
            if(selectedCountryObj && selectedCountryObj.itemImageName){
                this.setStyle("background-image",'url('+ GFlags.skin_path + "/resources" + selectedCountryObj.itemImageName +')');
                this.addCls("flagImage");
            }
            else{
                this.setStyle("background-image",null);
                this.removeCls("flagImage");
            }
        }
    },
    cls: 'osImageComboBox',
    initialList: [],
    /**
     * @method initComponent
     * Function intializes a  component.
     */
    initComponent: function () {
        g_OsLogger.info("Text component is initialised", this, {
            methodName: 'initComponent'
        });
        
        this.callParent(arguments);
    },

    /**
     * @method configureStoreData
     * To generate static store data.
     * @param cellObj parent level object
     * @return {Array}
     */
    configureStoreData: function (cellObj) {
        var lookupList;
        var listSize, lookupData = [];
        if (!Ext.isEmpty(cellObj)) {
            lookupList = cellObj.lookups;
            this.initialList = cellObj.lookups;
        }
        if (!Ext.isEmpty(lookupList)) {
            listSize = lookupList.length;
        }
        /*Pushed the image in the lookup list*/
        for (var i = 0, ln = listSize; i < ln; i++) {
            var lookupItem = [];
            lookupItem.push(lookupList[i].code);
            lookupItem.push(lookupList[i].displayValue);
            lookupItem.push(lookupList[i].itemImageName);
            lookupData.push(lookupItem);
        }
        g_OsLogger.info("Generate static store data", this, {
            methodName: 'configureStoreData',
            id: cellObj.id
        });
        return lookupData;
    },
    /**
     * @method configureStore
     * To configure static store with data.
     * @param configObj field level object
     * @param cellObj parent level object
     */
    configureStore: function (configObj, cellObj) {
        g_OsLogger.info("To configure static store with data.", this, {
            methodName: 'configureStaticStore',
            id: cellObj.id
        });
        var me = this,
            aDataArr = me.configureStoreData(cellObj);
        configObj.queryMode = 'local';
        /*Added country image in the fields*/
        configObj.store = {
            fields: ['enumCode', 'displayText', 'displayImage'],
            data: aDataArr,
            autoLoad: true,
            proxy: {
                type: 'memory',
                reader: { type: 'array' }
            }
        };
    },
    /**
     * @private 
     * Fire on after field rendered
     * Check for field is in responsive block.
     * Check for size and trigger element
     * Summarize the given size and trigger width into calculated Width
     * Apply calculated width on field body
     */
    afterRender: function () {
        var me = this;
        this.callParent(arguments);
        
    }
});
