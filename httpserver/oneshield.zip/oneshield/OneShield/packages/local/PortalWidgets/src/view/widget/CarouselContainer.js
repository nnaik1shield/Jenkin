Ext.define('Dragon.view.CarouselContainer', {
	extend: 'Ext.container.Container',
	alias: 'widget.OsCarouselContainer',
	
	mixins: ['Dragon.view.BlocksMixin'],
	cls: 'OsCarouselContainerWrap blockWrapperContainer',
	config: {
        paramsObj: {},
        blockObj: {}
    },
    layout: {"type":'fit'},
    hideMode : 'offsets',
    //height : '230px',
    containerLayout:true,//flag to indicate if this is an instance of container block
	
    /**
     * Initialize config items, creates child blocks of the container
     */
	initComponent: function() {
		
		var me = this;
		
		// flag indicates if animation is supported or not
		me.isAnimationSupported = false;
		
		var containerWidth = undefined;
		if(!Ext.isEmpty(this.blockObj.width))
		{
			containerWidth = this.blockObj.width;
			//this.blockObj.width = undefined;
		}
		var containerStyle = undefined;
		var containerHeight = undefined;
		if(!Ext.isEmpty(this.blockObj.uiStyle))
		{
			containerHeight = this.getHeightFromUiStyle(this.blockObj.uiStyle);
			this.blockObj.style = this.getUiExcludingHeight(this.blockObj.uiStyle);
		}
		
		if(containerHeight)
		{
			this.height = (parseInt(containerHeight) + 25) + 'px';
			containerHeight = containerHeight + 'px';
		}
		
		
		this.rowIndex = this.blockRowIndex;
		
		this.carouselItems = this.createContainerItems(this);
		
		this.numberOfSlides = this.carouselItems.length;
		
		this.currentSlide = this.carouselItems[0];
		
		me.currentSlideIndex = 0;
		
		// Dynamically Generate Pill Buttons 
		var pillButtons = []
		for (let j = 0; j < this.numberOfSlides; j++) {
			let myCls = (j == 0) ? 'carousel-pill selected-carousel-pill' : 'carousel-pill' ;
			pill = Ext.create('Ext.Button', {
				id : 'carousel-pill-' + j,
				cls : myCls,
				handler: function(btn) {
					me.currentSlideIndex = j;
					me.changeSlide(j);
					
				}
			});
			pillButtons.push(pill);
		}
		// Pills Container
		this.navigationPillsContainer = Ext.create('Ext.container.Container', {
			id : 'carousel-pills-container',
			cls : 'carousel-pills-container',
			items : pillButtons
		});
		
		// slide container
		this.carouselBlockContainer = Ext.create('Ext.container.Container', {
			
			items : me.carouselItems,
			//style: containerStyle,
			//width : containerWidth,
			height : containerHeight,
			hideMode : 'offsets'
		});
		
		//this.items = this.carouselItems;
		this.items = [];
		this.items.push(this.carouselBlockContainer);
		//this.items.push(this.carouselItems);
		this.items.push(this.navigationPillsContainer);
		
		this.callParent(arguments);
		
	},
	
	/** 
     * Create block object of each child block of the container block and return array of items
     * @param paramObj blockobject of container block
     * @returns array of items/block instances
    */
    createContainerItems: function(paramObj){
    	if(!Ext.isEmpty(paramObj.blockObj)){
    		// if it is container block
			if(!Ext.isEmpty(paramObj.blockObj.layout)){
				// check if layoutObject sent while build/creating instance of  container block
				if(!Ext.isEmpty(paramObj.layoutObj)){
					var items = [];
					// container block will always have single blockrow
			    	var blocksInRow = paramObj.blockObj.layout.blockRows[0].blocks;
			    	var numOfBlocksInRow = blocksInRow.length;
			    	var isVisibleBlkFound = false;
			    	for (var blockIdx = 0; blockIdx < numOfBlocksInRow; blockIdx++) {
			    		var blockObj = blocksInRow[blockIdx];
			    		if(isVisibleBlkFound)
		    			{
		    				blockObj.visibility = false;
		    			}
		    			if(blockObj.visibility)
		    			{
		    				isVisibleBlkFound = true;
		    			}
			    		
			    		var blk = paramObj.layoutObj.createBlockItem(blockObj, blockIdx, 0, numOfBlocksInRow, paramObj.oneShieldDesktop, true);
			    		if(blk){
			    			// mark this block as container child item
			    			blk.containerChildItem = true;
			    			
			    			items.push(blk);
			    		}
			    	}
			    	return items;
				}
				else{
					g_OsLogger.error("layout object is not passed as parameter while instantiating container block", this, {
			            methodName: 'createContainerItems',
			            blockObject:paramObj.blockObj
			        });
				}
			}
			else{
				//subblocks 1-M RW repeating
				var items = this.createRepeatingSubblockItems(paramObj,"carousel");
				if(!Ext.isEmpty(items)){
					//For subblocks use label as title
					items.forEach(function(item){
						if(Ext.isEmpty(item.title) && item.subBlockObj){
							item.title = item.subBlockObj.label;
						}
						// mark this block as container child item, it is later used in accordion container while building nested container blocks
						item.containerChildItem = true;
					});
				}
				return items;
			}
		}
		else{
			g_OsLogger.error("block object is not passed as parameter while instantiating container block", this, {
	            methodName: 'createContainerItems',
	            paramObj:paramObj
	        });
		}
    },
    
    /** 
     * For 1-M RW block(labels as top/left), create instances of subblocks
     * @param paramObj blockobject of 1-M block
     * @returns array of items/block instances
    */
    createRepeatingSubblockItems: function(paramsObj, layoutType){
    	var blkItemsArray = [];
    	if(!Ext.isEmpty(paramsObj) && !Ext.isEmpty(paramsObj.blockObj) && !Ext.isEmpty(paramsObj.blockObj.subBlocks)){
    		var numOfSubBlocks = paramsObj.blockObj.subBlocks.length
    		var isVisibleBlkFound = false
    		for (var subBlkIdx = 0; subBlkIdx < numOfSubBlocks; subBlkIdx++) {
    			var subBlockObj = paramsObj.blockObj.subBlocks[subBlkIdx];
    			var subBlockId = 'blk_' + subBlockObj.objectId + '_' + subBlockObj.id;
    			
    			if (false === paramsObj.blockObj.visibility) {
    				subBlockObj.visibility = false;
    			}
    			
    			if(layoutType && layoutType == "carousel")
	    		{
	    			if(isVisibleBlkFound)
	    			{
	    				subBlockObj.visibility = false;
	    			}
	    			if(subBlockObj.visibility)
	    			{
	    				isVisibleBlkFound = true;
	    			}
	    			
	    		}
    			
    			var subBlockPanel = Ext.create('Dragon.view.One_Many_RW_SubBlock', {
    				id: subBlockId,
    				subBlockObj: subBlockObj,
    				actionId: paramsObj.actionId,
    				oneShieldDesktop: paramsObj.oneShieldDesktop,
    				parBlockObj: paramsObj.blockObj
    			});
    			
    			var tbarObj = Ext.create('Ext.toolbar.Toolbar');
    			
    			tbarObj.cls = 'sub_block_1mrw_title';
    			if (!subBlockObj.label) {
    				subBlockObj.label = '';
    			}
    			
    			var osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                	(Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]) +
                	VIEWCONSTANTS.UNDERSCORE + subBlockObj.immutableStaticIdPrefix + VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.BLOCK_ID + 
        			VIEWCONSTANTS.UNDERSCORE + subBlockObj.id + VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.LABEL;
    			
    			tbarObj.add({
    				xtype: 'label',
    				text: subBlockObj.label,
    				osviewid: osviewid
    			});
    			
    			tbarObj.on('afterlayout', function (tbar, layout) {
    				if (tbar.items && tbar.items.length > 0) {
    					for (var i = 0; i < tbar.items.length; i++) {
    						tbar.items.items[0].el.dom.setAttribute(
    								GFlags.os_immutable_static_id_name, tbar.items.items[0].osviewid);
    					}
    				}
                });
    			
    			subBlockPanel.setDockedItemsFromBlockLevelButtons(
    					paramsObj.blockObj.blockRowLevelButtons,
    					subBlockObj.objectId,
    					subBlockId,
    					'gridMode' in subBlockObj && subBlockObj.gridMode,
    					tbarObj,
    					paramsObj.blockObj.id,
    					subBlockObj.immutableStaticIdPrefix
    			);
    			
    			
    			blkItemsArray.push(subBlockPanel);
    		}
    	}
    	else{
    		g_OsLogger.warn("Empty 1-M RW block", this, {
	            methodName: 'createRepeatingSubblockItems',
	            paramObj:paramsObj
	        });
    	}
    	
    	return blkItemsArray;

    },

    /**
     * Update state of pills buttons, activate pill by index number
     * @param pillIndex index of the pill button
     */
    updatePillState : function(pillIndex) 
	{
		for (let i = 0; i < this.numberOfSlides; i++) 
		{
			if( i == pillIndex )
            {
                Ext.get('carousel-pill-'+i).addCls("selected-carousel-pill");
            }
			else
			{
                Ext.get('carousel-pill-'+i).removeCls("selected-carousel-pill");
            }
		} 
	},
	
	/**
	 * Switch slide by index
	 * @param index of the slide which need to be switched/activated
	 */
	changeSlide : function(slideIndex) 
	{
		var me = this;
		
		var nextSlide = this.carouselItems[this.currentSlideIndex];
		
		if(this.isAnimationSupported)
		{
			// animation is supported by child blocks
			this.animateSlide(slideIndex);
		}
		else
		{
			this.updatePillState(slideIndex);
			
			
			this.updateSlideState();
		}
		
		
		
	},
	
	animateSlide : function(slideIndex)
	{
		var me = this;
		
		// stop displaying current slide then start displaying next slide
		this.currentSlide.animate({
		       duration: 2000,
		        to: {
		            opacity: 0
		        },
		        listeners: {
		            beforeanimate:  function() {
		                // Execute my custom method before the animation
		                //me.myBeforeAnimateFn();
		            },
		            afteranimate: function() {
		            	// Execute my custom method after the animation
 		            	me.updatePillState(slideIndex);
 		   			
 		            	me.updateSlideState();
		            },
		            scope: me
		        }
		  });
		
		
	},
	
	/**
	 * Update state of the slide on switching
	 */
	updateSlideState : function()
	{
		this.currentSlide.hide();
		this.currentSlide = this.carouselItems[this.currentSlideIndex];
		this.currentSlide.show();
		
		
	},
	
	onBoxReady:function()
	{
		var me = this;
		this.callParent(arguments);
		
		// register touch gesture
		this.carouselItems.forEach(function(item){
			item.el.on('swipestart', me.swipeSlideStart, me);
			if(!Ext.isFunction(item.animate))
			{
				me.isAnimationSupported = false;
			}
		});
	},
	
	/**
	 * Callback for swipe event
	 * @param event
	 */
	swipeSlideStart : function(event) 
	{
		if(event == undefined || event.direction == undefined)
		{
			g_OsLogger.error("swipe event or swipe event direction is not supported", this, {
	            methodName: 'swipeSlideStart',
	            blockObject:paramObj.blockObj
	        });
			return;
		}
		
		if(event && event.direction)
		{
			if(event.direction == "left"){
				if(this.currentSlideIndex < this.numberOfSlides -1)
				{
					this.currentSlideIndex++;
					this.changeSlide(this.currentSlideIndex);
				}
			}
			else if(event.direction == "right"){
				if(this.currentSlideIndex > 0)
				{
					this.currentSlideIndex--;
					this.changeSlide(this.currentSlideIndex);
				}
			}
		}
	},
	
	/**
	 * Get height from uiStyle
	 * @param uiStyle
	 */
	getHeightFromUiStyle: function (uiStyle) {
		if (Ext.isEmpty(uiStyle)) {
			g_OsLogger.warn("Method got empty uistyle.", this, {
				methodName: 'getHeightFromUiStyle'
			});
			return undefined;
		}
		
		g_OsLogger.info("Method to get height from uistyle metadata.", this, {
			methodName: 'getHeightFromUiStyle', style: uiStyle
		});
		
		var style, uiStyleArray = uiStyle.split(';');

		for (var index = 0; index < uiStyleArray.length; index++) {
			var element = uiStyleArray[index];
			if(element)
			{
				if(element.trim)
				{
					element = element.trim();
				}
				if (element.indexOf('height:') > -1) {
					return element.substring(element.indexOf(':') + 1);
				}
			}
			
		}
		return style;
	},
	
    /**
     * Method to get UiMixin from uistyle metadata after excluding height
     * @param uiStyle metadata string
     */
	getUiExcludingHeight: function (uiStyle) {
		if (Ext.isEmpty(uiStyle)) {
			g_OsLogger.warn("Method got empty uistyle.", this, {
				methodName: 'getUiExcludingHeight'
			});
			return undefined;
		}
		g_OsLogger.info("Method to get ui from uistyle metadata.", this, {
			methodName: 'getUiExcludingHeight',
			style: uiStyle
		});
		var style,
			uiStyleArray = uiStyle.split(';'), uiInlineStyleArr = [];

		for (var index = 0; index < uiStyleArray.length; index++) {
			var element = uiStyleArray[index];
			if(element)
			{
				if(element.trim)
				{
					element = element.trim();
				}
				if (element.indexOf('height:') > -1) {
					continue;
				} else {
					uiInlineStyleArr.push(element);
				}
			}
			
		}
		if (uiInlineStyleArr.length == 0) {
			return undefined;
		}
		return uiInlineStyleArr.join(';');
	}
});