/**
 * @class Dragon.view.PortalLoadMask
 * 
 *  This class be responsible for loading loadMask of type PortalLoadMask
 */

Ext.define('Dragon.view.PortalLoadMask', {
	alias: 'PortalLoadMask',
	statics: {

	    mask: function (that, msg, msgCls, elHeight) {
	        var me = that,
	            dom = me.dom,
	            data = me.getData(),
	            maskEl = data.maskEl,
	            bodyRe = /^body/i,
	            XMASKEDRELATIVE = Ext.baseCSSPrefix + "masked-relative",
	            XMASKED = Ext.baseCSSPrefix + "masked",
	            DOC = document,
	            maskMsg;
	
	        if (!(bodyRe.test(dom.tagName) && me.getStyle('position') === 'static')) {
	            me.addCls(XMASKEDRELATIVE);
	        }
	
	        // We always needs to recreate the mask since the DOM element may have been re-created 
	        if (maskEl) {
	            maskEl.destroy();
	            delete data.maskEl;
	        }
	        if(Ext.isEmpty(msg)) {
		        maskEl = Ext.DomHelper.append(dom, {
		            role: 'presentation',
		            cls: 'loadmask-body-container',
		            children: [{
		                role: 'presentation',
		                tag: 'div',
		                cls: 'bouncer-loadmask-container spinner',
		                id: 'loadmask-center-container',
		                children: [
		                	{
		                        tag: 'div',
		                        role: 'presentation',
		                        id: 'bouncer-loadText',
		                        html: Localize.processLocalStr('Please wait'),
		                        [GFlags.os_immutable_static_id_name]: 'bouncer-component1'
		                    },
		                	{
		                        tag: 'div',
		                        role: 'presentation',
		                        cls: 'bounce1 ',
		                        id: 'bounce1',
		                        [GFlags.os_immutable_static_id_name]: 'bouncer-component2'
		                    },
		                    {
		                        tag: 'div',
		                        role: 'presentation',
		                        cls: 'bounce2',
		                        id: 'bounce2',
		                        [GFlags.os_immutable_static_id_name]: 'bouncer-component3'
		                    },
		                    {
		                        tag: 'div',
		                        role: 'presentation',
		                        cls: 'bounce3',
		                        id: 'bounce3',
		                        [GFlags.os_immutable_static_id_name]: 'bouncer-component4'
		                    },
		                 
		                    {
		                        tag: 'div',
		                        role: 'presentation',
		                        id: 'bouncer-loadText',
		                        html: Localize.processLocalStr('Your Request is Processing')+'...',
		                        [GFlags.os_immutable_static_id_name]: 'bouncer-component5'
		                    }
		                ]
		            }]
		        
		        }, true);
	        } else {
	        	maskEl = Ext.DomHelper.append(dom, {
		            role: 'presentation',
		            cls: 'loadmask-body-container',
		            children: [{
		                role: 'presentation',
		                tag: 'div',
		                cls: 'bouncer-loadmask-container spinner',
		                id: 'loadmask-center-container',
		                children: [
		                	 {
		                        tag: 'div',
		                        role: 'presentation',
		                        id: 'bouncer-loadText',
		                        children : [
			                       	{
				                       	tag: 'img',
				                       	src: APPUTILS.getImagePath(msg.image1, '') 
			                       	}
			                    ],
			                    [GFlags.os_immutable_static_id_name]: 'bouncer-component1'
		                    },
		                    {
		                        tag: 'div',
		                        role: 'presentation',
		                        id: 'bouncer-loadText',
		                        html: Localize.processLocalStr(msg.text1),
		                        [GFlags.os_immutable_static_id_name]: 'bouncer-component2'
		                    },
		                    {
		                        tag: 'div',
		                        role: 'presentation',
		                        id: 'bouncer-loadText',
		                        html: Localize.processLocalStr(msg.text2),
		                        [GFlags.os_immutable_static_id_name]: 'bouncer-component3'
		                    },
		                    {
		                        tag: 'div',
		                        role: 'presentation',
		                        id: 'bouncer-loadText',
		                        children : [
			                       	{
				                       	tag: 'img',
				                       	src:   APPUTILS.getImagePath(msg.image2, '') 
			                       	}
		                       	],
		                       	[GFlags.os_immutable_static_id_name]: 'bouncer-component4'
		                    },
		                    {
		                        tag: 'div',
		                        role: 'presentation',
		                        id: 'bouncer-loadText',
		                        html: Localize.processLocalStr(msg.text3),
		                        [GFlags.os_immutable_static_id_name]: 'bouncer-component5'
		                    }
		                ]
		            }]
		        }, true);
	        }
	       
	        data.maskEl = maskEl;
	        me.addCls(XMASKED);
	        if (dom === DOC.body) {
	            var centerItem = Ext.get('loadmask-center-container');
	            if(!Ext.isEmpty(centerItem)){
	                centerItem.center();
	            }
	        }
	        return maskEl;
	    },
	
	    unmask: function (that) {
	        var me = that,
	            data = me.getData(),
	            maskEl = data.maskEl,
	            XMASKEDRELATIVE = Ext.baseCSSPrefix + "masked-relative",
	            XMASKED = Ext.baseCSSPrefix + "masked",
	            DOC = document,
	            style;
	
	        if (!Ext.isEmpty(maskEl)) {
	            style = maskEl.dom.style;
	            if (style.clearExpression) {
	                style.clearExpression('width');
	                style.clearExpression('height');
	            }
	            maskEl.dom.style.display = "none"
	            maskEl.destroy();
	            delete data.maskEl;
	            me.removeCls([XMASKED, XMASKEDRELATIVE]);
	        }
	
	        me.restoreTabbableState(me.dom === DOC.body);
	    }

	}
}); 