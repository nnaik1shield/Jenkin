/**
 * @class 'Dragon.util.OSFormUtils'
 * A class to handle form utilities
 */
Ext.define('Dragon.overrides.util.OSFormUtils', {
    override: 'Dragon.util.OSFormUtils',
    /**
     * @method getMessage
     * Function will be called to render the message.
     * Fires everytime value changes and on blur.
     * @return {String}
     */
    getMessage: function () {
        var msg;
        msg = Localize.processLocalStr('Please complete the mandatory fields.');
        return msg;
        // if (GFlags.os_mandatory_scheme == VIEWCONSTANTS.VALIDATION_ASTERISK_CLASS) {
        //     msg = Localize.processLocalStr('All the Fields marked with' + VIEWCONSTANTS.VALIDATION_ASTERISK +
        //         ' are mandatory');
        //     g_OsLogger.info("Showing mandatory msg on screen through " + VIEWCONSTANTS.VALIDATION_ASTERISK_CLASS, this, {
        //         methodName: 'getMessage'
        //     });
        //     return msg;
        // } else {
        //     msg = Localize.processLocalStr(VIEWCONSTANTS.VALIDATION_YELLOW_ERROR);
        //     g_OsLogger.info("Showing mandatory msg on screen through " + VIEWCONSTANTS.VALIDATION_YELLOW_CLASS, this, {
        //         methodName: 'getMessage'
        //     });
        //     return msg;
        // }
    }
});
