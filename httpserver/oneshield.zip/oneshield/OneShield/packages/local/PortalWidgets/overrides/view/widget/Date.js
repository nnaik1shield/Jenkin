function detectmob() {
    if(window.innerWidth <= 600) {
    Ext.define('Dragon.overrides.view.widget.Date', {
        override: 'Dragon.view.widget.Date',
            editable: false,
            typeAhead: false
    });
    } else {
        Ext.define('Dragon.overrides.view.widget.Date', {
            override: 'Dragon.view.widget.Date',
                editable: true,
                typeAhead: true
        });
    }
}
detectmob();  