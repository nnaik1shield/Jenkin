Ext.define('Dragon.overrides.view.BlockItemsMixin', {
    override: 'Dragon.view.BlockItemsMixin',
    //alias: 'widget.OnemEmptyBlock',
    createCell: function (paramsObj,parentCellObj) {

		if(paramsObj.cellObj.fes==101){
            paramsObj.cellObj.uiStyle= 'display: none;';
        }
		  
		return this.callParent(arguments);
	}
	
});
