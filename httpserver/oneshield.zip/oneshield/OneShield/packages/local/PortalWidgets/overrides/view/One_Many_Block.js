Ext.define('Dragon.overrides.view.One_Many_Block', {
    override: 'Dragon.view.One_Many_Block',
    mixins: ['Dragon.view.BlocksMixin'],
     config: {  
        /**
         * @cfg {Object} currentView 
         * Custom config to get and set backend currentView data
         */
        currentView: {}
    },
    initComponent: function () {
        g_OsLogger.info("One-Many-Block type grid has been initialized on screen", this, {
            methodName: 'initComponent'
        });
        this.callParent(arguments);
    },
    /**
     * @method _initControls
     * Function is a common method to create table toolbar etc.
     */
    _initControls: function () {
        g_OsLogger.info("_initControls() is called to create toolbar to the grid if exists", this, {
            methodName: '_initControls'
        });
        var me = this;
        if (me.blockObj.showListControls === 0 || me.blockObj.datamart === false) {
            me.addCls("no-toolbar");
        } 
        else {
            me.addCls("with-toolbar");
        }
        this.callParent(arguments);

    },
    alias: 'widget.OnemEmptyBlock',
    viewConfig: {
        deferEmptyText: false,
        //emptyText: 'No data Available'
        emptyText:'<div class="grid-data-empty" style="text-align: center"><div class="empty-grid-icon"><img src="./osportaluber/resources/image_widget/no-result-icon.svg"></div><div class="empty-grid-headline">No results found</div><div class="empty-grid-byline"><p>Suggestions:</p><ul><li>Make sure that all words are spelled correctly.</li><li>Try different keywords.</li><li>Try more general keywords.</li></div></div>'
    }
});
