function detectmob2() {
    if(window.innerWidth <= 600) {
        Ext.define('Dragon.overrides.view.widget.ComboBox', {
            override: 'Dragon.view.widget.ComboBox',
                editable: false,
                typeAhead: false,
                onFocus: function() {
                    var me = this;
                
                    if (!me.isExpanded) {
                        me.expand()
                    }
                    me.getPicker().focus();
                }
          });
    } else {
        Ext.define('Dragon.overrides.view.widget.ComboBox', {
            override: 'Dragon.view.widget.ComboBox',
                editable: true,
                typeAhead: true
           
          });
    }
 }
detectmob2();

