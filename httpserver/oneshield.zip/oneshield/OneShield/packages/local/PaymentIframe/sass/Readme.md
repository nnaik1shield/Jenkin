# PaymentIframe/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    PaymentIframe/sass/etc
    PaymentIframe/sass/src
    PaymentIframe/sass/var
