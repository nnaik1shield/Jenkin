# OSPortal/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    OSPortal/sass/etc
    OSPortal/sass/src
    OSPortal/sass/var
