Ext.namespace('Ext.theme.is')['OSPortalUber'] = true;
Ext.theme.name = 'OSPortalUber';