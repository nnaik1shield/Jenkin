Ext.define('Dragon.overrides.view.WaitPageBlock', {
	 override: 'Dragon.view.WaitPageBlock',
	 cls: "wait-page-layout-block",
	
	/**
	 * @method initComponent
	 * Function will initializes a component.
	 */
	 initComponent: function() {
		 
		this.callParent(arguments);
	 }
	 
});