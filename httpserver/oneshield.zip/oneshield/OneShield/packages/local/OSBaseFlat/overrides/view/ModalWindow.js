/**
 * @class Dragon.overrides.view.ModalWindow
 * @override Dragon.view.ModalWindow
 * Overriding the behavior of ModalWindow class
 */
 Ext.define('Dragon.overrides.view.ModalWindow', {
    override: 'Dragon.view.ModalWindow',
    
    listeners: {
        afterHide: function() {
            Dragon.util.OSAppUtils.setContext();
            this.destroy();
        }
    },
    initComponent: function() {
        var me = this;
        if (this.oneShieldDesktop.workflowContext.split(',')[0] == '1789948') {
            this.mon(Ext.getBody(), 'click', function(el, e) {
                me.close(me.closeAction);
                this.afterHide();
            }, me, {
                delegate: '.x-mask'
            });
        }
        me.callParent(arguments);

    }
}

);
