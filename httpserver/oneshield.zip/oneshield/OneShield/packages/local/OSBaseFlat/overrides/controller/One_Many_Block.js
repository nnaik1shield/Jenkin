/**
 * This class contains all the logic for the One_Many_Block view events.
 * @extends Ext.app.Controller
 * $HeadURL: http://oscsvn01.oneshield.com/svnrepos/OneShield/coresrc/4.30/branches/CORE_4.30.1.DEV5/Dragon6Web/WebContent/app/controller/One_Many_Block.js $
 * $Revision: 415 $
 * $Author: mpetrov $
 * $Date: 2013-09-26 16:52:16 -0400 (Thu, 26 Sep 2013) $
 */
Ext.define('Dragon.overrides.controller.One_Many_Block', {
    override: 'Dragon.controller.One_Many_Block',
    init: function () {
        var me = this;
        me.callParent(arguments);
    },

    /**
     * @event onClickSaveFilter
     * Function is responsible for saving the personalized filters.
     * @param button
     */
    onClickSaveFilter: function (button) {
        var me = this,
            buttonID = button.up().up().id,
            buttonIDsplit= buttonID.split('_')[1],
            buttonIDnew= buttonID.replace(buttonIDsplit+'_',''),
            buttonIDLatest = buttonIDnew.concat('_'+buttonIDsplit),
            res = buttonIDLatest.replace(/filterModalWindow/g, "blk"),
            grid = Ext.getCmp(res),
            newSavedQuery,
            loadedView,
            personalizedFilterAdd;

        // g_OsLogger.info("Save filter is clicked", this, {
        //     methodName: 'onClickSaveFilter',
        //     // id: grid.id
        // });

        if (Dragon.model.PersonalizedFilter.isRunning) {
            // g_OsLogger.warn("PersonalizedFilter is running, please finish your work with" +
            //     "another personalized filter.", this, {
            //         methodName: 'onClickSaveFilter',
            //         id: grid.id
            //     });
            Ext.Msg.alert('Status', "Please finish your work with another personalized filter");
            return;
        }
        newSavedQuery = grid.config['savedQuery'];

        grid.config['newFilterSortData'] = me.buildJsonSortData(grid.droppable);

        loadedView = grid['currentView'] && grid.currentView['viewId'];

        if ((!newSavedQuery || newSavedQuery.trim() == '[]') && !loadedView && grid.config['newFilterSortData'].trim() == '') {
            g_OsLogger.warn("New saved query is empty, create a new filter or load the existing one.", this, {
                methodName: 'onClickSaveFilter',
                id: grid.id
            });
            personalizedFilterAdd = Ext.create('widget.osPersonalizedFilterList', {
                showList: false,
                showAdd: true,
                sessionId: Dragon.config.Runtime.getUserSessionId(),
                transactionId: Dragon.config.Runtime.getTransactionId(),
                blockId: grid.blockObj.id,
                actionId: grid.actionId,
                parGrid: grid
            });

            personalizedFilterAdd.show();
            g_OsLogger.info("Personalized filter is created", this, {
                methodName: 'onClickSaveFilter',
                blockId: grid.blockObj.id
            });
        } else {
            personalizedFilterAdd = Ext.create('widget.osPersonalizedFilterList', {
                showList: false,
                showAdd: true,
                sessionId: Dragon.config.Runtime.getUserSessionId(),
                transactionId: Dragon.config.Runtime.getTransactionId(),
                blockId: grid.blockObj.id,
                actionId: grid.actionId,
                parGrid: grid
            });

            personalizedFilterAdd.show();
            g_OsLogger.info("Personalized filter is created", this, {
                methodName: 'onClickSaveFilter',
                blockId: grid.blockObj.id
            });
        }
    },
    selectFilter: function (callerId, sessionId, transactionId, viewId) {
        g_OsLogger.info("selectFilter() got called.", this, { methodName: 'selectFilter', callerId: callerId, sessionId: sessionId, viewId: viewId });
        var me = this,
            personalFilter = Ext.getCmp(callerId),
            parGrid = personalFilter.parGrid,
            curGridFilters = parGrid.columnFilters,
            viewName = '',
            filterJson,
            persFilterList,
            sortList,
            filterListAsString,
            sortListAsString,
            sortFilterListsAsString,
            gridStore;
        g_OsLogger.info("Request is sent to 'PersonalizedFilterServlet'", this, { methodName: 'selectFilter' });
        Ext.Ajax.request({
            url: 'PersonalizedFilterServlet',
            method: 'POST',
            params: {
                'op': 'get',
                'viewId': viewId,
                'USER_SESSION_GUID': Dragon.config.Runtime.getUserSessionGUID(),
                'transactionId': Dragon.config.Runtime.getTransactionId()
            },
            success: function (response) {
                g_OsLogger.info("Ajax call made successfully.", this, { methodName: 'selectFilter', statusText: response.statusText });

                filterJson = Ext.decode(response.responseText);
                parGrid.currentView.viewName = filterJson['view_name'];

                persFilterList = filterJson['filter_list'];
                sortList = filterJson['sort_list'];

                for (var persFilterIndx = 0; persFilterIndx < persFilterList.length; persFilterIndx++) {
                    persFilterList[persFilterIndx]["value"] = persFilterList[persFilterIndx]["search_value1"];

                    if (!persFilterList[persFilterIndx]["field"]) {
                        persFilterList[persFilterIndx]["field"] = persFilterList[persFilterIndx]["cell_id"];
                    }

                    for (var jj = 0; jj < curGridFilters.length; jj++) {
                        if (
                            curGridFilters[jj]['dataIndex'] === persFilterList[persFilterIndx]['cell_id'] ||
                            curGridFilters[jj]['dataIndex'] === '' + persFilterList[persFilterIndx]['cell_id'] + '' /*todo make the personalized filter to return a string dataindex*/
                        ) {
                            persFilterList[persFilterIndx]['type'] = curGridFilters[jj]['type'];

                            curGridFilters[jj].active = true;
                            
                            curGridFilters[jj]['value'] = persFilterList[persFilterIndx]['value'];

                        }
                    }
                }
                filterListAsString = Ext.JSON.encode(persFilterList);
                sortListAsString = Ext.JSON.encode(sortList);

                sortFilterListsAsString = '{"filter_list":' + filterListAsString + ',"sort_list":' + sortListAsString + '}';

                me.clearSort(parGrid.droppable.toolbar, true);

                me.dropMultiSortPersonalizedFilterButtons(sortListAsString, parGrid);

                gridStore = parGrid.getStore();
                
                parGrid.filters.bindStore(gridStore);

        		gridStore.load();
        		
                parGrid.blockObj.personalizedFilter = sortFilterListsAsString;
                
                var cols = parGrid.columnManager.getColumns();
        		for (var i = 0; i < cols.length; i++) {
        			if(cols[i].filter != undefined){
        				cols[i].filter.setActive(false);
        				
        			}
        		}                

                me.updateCachedFilters(parGrid);

        		
//        		gridStore.load({
//                    params: {
//                        'personalizedFilterString': sortFilterListsAsString
//                    }
//                });
//                parGrid.filters.createFilters();
                
//                gridFilterBv = "bv_" + parGrid.listObjectId + "_31917001";
//                Dragon.util.OSFormUtils.addHiddenParam(gridFilterBv, sortFilterListsAsString);
                
  				/*
                 * As of 09/30/2013, the columns are not sorted properly if clearSort is called.
                 * The code should be revised later to firure out what exactly breaks the sorting if clearSort is used.
                 * parGrid.clearSort(parGrid.droppable);
                */
            

                
                return;
                /* */

            },
            failure: function (response) {
                g_OsLogger.error("Request to PersonalizedFilterServlet service failed", 'Dragon.controller.One_Many_Block', { methodName: 'selectFilter', statusText: response.statusText })
            }
        });

        parGrid.currentView.viewId = viewId;

        Ext.destroy(personalFilter);
    },
    /**
     * @event onClickListFilter
     * Function is responsible for displaying the personalized filters list.
     * @param button
     */
    onClickListFilter: function (button) {
        var me = this,
            grid = button,
            personalizedFilterList;
        g_OsLogger.info("List filter is clicked", this, {
            methodName: 'onClickListFilter',
            id: grid.id
        });

        if (Dragon.model.PersonalizedFilter.isRunning) {
            g_OsLogger.warn("PersonalizedFilter is running, please finish your work with another" +
                " personalized filter.", this, {
                    methodName: 'onClickListFilter',
                    id: grid.id
                });
            Ext.Msg.alert('Status', "Please finish your work with another personalized filter");
            return;
        }

        personalizedFilterList = Ext.create('widget.osPersonalizedFilterList', {
            showList: true,
            showAdd: false,
            sessionId: Dragon.config.Runtime.getUserSessionId(),
            transactionId: Dragon.config.Runtime.getTransactionId(),
            blockId: grid.blockObj.id,
            actionId: grid.actionId,
            parGrid: grid
        });
        g_OsLogger.info("Personalized filter list is created.", this, {
            methodName: 'onClickListFilter',
            blockId: grid.blockObj.id
        });

        personalizedFilterList.show();

    },
    /**
     * @event onClickClearFilters
     * Function is responsible for clearing the filters when clicked on
     * clear filter button.
     * @param button
     */
    onClickClearFilters: function (button) {
        var me = this,
            gridFilterBv, gridFilterBvField,
            grid = button.up('gridpanel');
        g_OsLogger.info("Clear filter is clicked", this, {
            methodName: 'onClickClearFilters',
            id: grid.id
        });
        
        grid.store.clearFilter();
 
        grid.store.sorters.clear();
        //Set AutoReload false prior to clearFilter() to prevent duplicate events
        grid.filters.autoReload = false;

        grid.filters.clearFilters();
        grid.filters.clearColumnHeadings();

        // OSEXTJSDEV-158
        var cols = grid.columnManager.getColumns();
        for (var i = 0; i < cols.length; i++) {
            if (cols[i].filter) {
                if (cols[i].filter.filter._value) {
                    cols[i].filter.filter.setValue();
                }
            }
        }

        grid.getStore().load({
            params: {
                'listAction': '99',
                'multiSortString': ''

            }
        });

        grid.filters.autoReload = true;

        //Also clear grid state on column hide/show/move
        gridFilterBv = "bv_" + grid.listObjectId + "_31917001";
        gridFilterBvField = Dragon.util.OSFormUtils.getBvElement(gridFilterBv);

        if (!Ext.isEmpty(gridFilterBvField)) {
            g_OsLogger.warn("Clear grid state on column hide/show/move.", this, {
                methodName: 'onClickClearFilters',
                id: grid.id
            });
            gridFilterBvField.setValue(null);
            Dragon.util.OSFormUtils.processCache(gridFilterBv, null);
        }
    },
    /**
     * @method hideToolbarSortButtons
     * Function is responsible for hiding the tbar components.
     * @param grid
     */
     hideToolbarSortButtons: function (grid) {
        g_OsLogger.info("hideToolbarSortButtons() is called", this, { methodName: 'hideToolbarSortButtons', id: grid.id });
        var me = this,
            tbar = grid.down('toolbar');

        // tbar.getComponent('clearSortSeparator').hide();
        // tbar.getComponent('clearSortSpacer').hide();
        // tbar.getComponent('clearSortButton').hide();

        if (!grid.personalizedFilterLoaded) {
            grid.getStore().load();
        }

    },

    /**
     * overriding the base function to manually add comparison=eq for date filter
     */
     interceptGridBeforeLoad: function (options, searchTxtId, searchColumnId, gridPanel) {
        var sortList, sortOrder,
        goodSubmit = (APPUTILS.uiValidationMesgMap.length == 0);
    options.action = 'read';

    if (goodSubmit === false) {
        Dragon.util.OSFormUtils.updateUiMessages(APPUTILS.uiValidationMesgMap);
        Dragon.util.OSFormUtils.resetIsProcessing();
        return false;
    }

    if (gridPanel.getStore().isLoading()) {
        g_OsLogger.debug('Concurrent grid operations, cancelling the last one', this, { methodName: 'interceptGridBeforeLoad' });
        return false;
    }

    if (!options.params) {
        options.params = new Object;
    }
 
    options.params['EXCHANGE_ID']= GFlags.os_startup_exchange_id;
    let hasComparison = false;
    if(!Ext.isEmpty(options) && !Ext.isEmpty(options._params) && !Ext.isEmpty(options._params['filter'])){
        var jsonArray = JSON.parse(options._params['filter']);
        
        for (const obj of jsonArray) {
            if (obj.hasOwnProperty('comparison')) {
                hasComparison = true;
                break;
            }
            }
    }

    if( !Ext.isEmpty(options) && !Ext.isEmpty(options._params) && !Ext.isEmpty(options._params['filter']) && !hasComparison)
    {
        let jsonObj = Ext.JSON.decode(options._params['filter']);
        if( Ext.isArray(jsonObj))
        {
            var updatedJsonObjects = [];
            for( let i = 0 ; i < jsonObj.length; i++ )
            {
                if( !Ext.isEmpty(jsonObj[i].type) && jsonObj[i].type == 'date' && !Ext.isEmpty(jsonObj[i].value))
                {
                    var modal= document.getElementsByClassName('NewFilterModal');
                    let lastElement;
                    let dataIndex = jsonObj[i].field;
                    if(modal.length !=0){
                        for(let i=0; i<modal.length; i++){
                            if(modal[i].querySelectorAll('input[id*="combo"]').length>1){
                                let comboList= modal[i].querySelectorAll('input[id*="combo"]');
                                for (let j=0; j<comboList.length;j++){
                                    if(comboList[j].name == dataIndex){
                                        lastElement = modal[i];
                                    }
                                }
                            }
                            else {
                                if(modal[i].querySelector('input[id*="combo"]').name == dataIndex){
                                    lastElement = modal[i];
                                }
                            }
                        }
                        var combomodal2 = "input[id*='combo'][name='" + jsonObj[i].field + "']";
                        var combomodal= lastElement.querySelector(combomodal2).value;
                        
                        if(combomodal){
                        var combomodalvalue = combomodal;
                        }
                        if(combomodalvalue == "After"){
                            Ext.applyIf(jsonObj[i],{
                                'comparison' : 'gt'
                            });
                        }
                        else if(combomodalvalue == "Before"){
                            Ext.applyIf(jsonObj[i],{
                                'comparison' : 'lt'
                            });
                        }
                       
                       else if (combomodalvalue === "Between" && !Ext.isEmpty(jsonObj[i].type) && jsonObj[i].type === 'date' && !Ext.isEmpty(jsonObj[i].value)) {
                                if ( jsonObj[i].type === "date") {
                                    var newfilterdatepickerLabel = document.getElementsByClassName('newfilterdatepickerLabel');
                                    if (newfilterdatepickerLabel.length > 1) {
                                        for (let k = 0; k < newfilterdatepickerLabel.length; k++) {
                                            if (newfilterdatepickerLabel[k].getElementsByTagName('input')[0].name === jsonObj[i].field) {
                                                var combomodal3 = newfilterdatepickerLabel[k].getElementsByTagName('input')[0].value;
                                                if (!Ext.isEmpty(combomodal3) && combomodal3 != jsonObj[i].value) {
                                                    // Corrected index here from k to i
                                                    var newJsonObject = {
                                                        value: combomodal3,
                                                        type: 'date',
                                                        field: jsonObj[i].field,
                                                        comparison: 'lt'
                                                    };
                                                    updatedJsonObjects.push(newJsonObject);
                                                    // jsonObj[k] = { value: combomodal3, type: 'date', field: jsonObj[i].field, 'comparison': 'lt' };
                                                }
                                                else{
                                                     // Moved this outside the inner loop and corrected index from k to i
                                                    Ext.applyIf(jsonObj[i], {
                                                        'comparison': 'gt'
                                                    });
                                                }
                                            }
                                        }
                                       
                                    }
                                }
                            }
                                                
                        else if(combomodalvalue === "On"){
                            // if(jsonObj.length>1){
                            //     jsonObj.shift();
                            // }
                            if(jsonObj[i].type=="date"){
                                Ext.applyIf(jsonObj[i],{
                                    'comparison' : 'eq'
                                });
                            }
                        }
                    }
                    else if(modal.length == 0){
                        let userData = JSON.parse(localStorage.getItem('oneManyNewFilter'));
                        if(userData && userData[dataIndex]){
                        var combomodal = userData[dataIndex][0];
                        
                        if(combomodal){
                            var combomodalvalue = combomodal;
                            }
                            if(combomodalvalue == "After"){
                                // var abc=null;
                                // localStorage.setItem("oneManyNewFilter2", JSON.stringify(abc));
                                Ext.applyIf(jsonObj[i],{
                                    'comparison' : 'gt'
                                });
                            }
                            else if(combomodalvalue == "Before"){
                                // var abc=null;
                                // localStorage.setItem("oneManyNewFilter2", JSON.stringify(abc));
                                Ext.applyIf(jsonObj[i],{
                                    'comparison' : 'lt'
                                });
                            }
                            else if (combomodalvalue === "Between" && !Ext.isEmpty(jsonObj[i].type) && !Ext.isEmpty(jsonObj[i].value)) {
                                if ( jsonObj[i].type === "date") {
                                    var newfilterdatepickerLabel = document.getElementsByClassName('newfilterdatepickerLabel');
                                    if (newfilterdatepickerLabel.length > 1) {
                                        for (let k = 0; k < newfilterdatepickerLabel.length; k++) {
                                            if (newfilterdatepickerLabel[k].getElementsByTagName('input')[0].name === jsonObj[i].field) {
                                                var combomodal3 = newfilterdatepickerLabel[k].getElementsByTagName('input')[0].value;
                                                if (!Ext.isEmpty(combomodal3) && combomodal3 != jsonObj[i].value) {
                                                    // Corrected index here from k to i
                                                    var newJsonObject = {
                                                        value: combomodal3,
                                                        type: 'date',
                                                        field: jsonObj[i].field,
                                                        comparison: 'lt'
                                                    };
                                                    updatedJsonObjects.push(newJsonObject);
                                                    // jsonObj[k] = { value: combomodal3, type: 'date', field: jsonObj[i].field, 'comparison': 'lt' };
                                                }
                                                else{
                                                     // Moved this outside the inner loop and corrected index from k to i
                                                    Ext.applyIf(jsonObj[i], {
                                                        'comparison': 'gt'
                                                    });
                                                }
                                            }
                                        }
                                        // // Moved this outside the inner loop and corrected index from k to i
                                        // Ext.applyIf(jsonObj[i], {
                                        //     'comparison': 'gt'
                                        // });
                                    }
                                    else{
                                        const toDateee = JSON.parse(localStorage.getItem('oneManyNewFilter'));
                                        if(!Ext.isEmpty(toDateee)){
                                            toDate = toDateee[jsonObj[i].field][2];
                                            var newJsonObject = {
                                                value: toDate,
                                                type: 'date',
                                                field: jsonObj[i].field,
                                                comparison: 'lt'
                                            };
                                            updatedJsonObjects.push(newJsonObject);
                                        }
                                        else{
                                           Ext.applyIf(jsonObj[i], {
                                               'comparison': 'gt'
                                           });
                                       }
                                    }
                                }
                            }
                            else if(combomodalvalue === "On"){
                                if(jsonObj[i].type=="date"){
                                    Ext.applyIf(jsonObj[i],{
                                        'comparison' : 'eq'
                                    });
                                }
                            }
                        }
                        else {
                            for(let i = 0 ; i < jsonObj.length; i++){
                                if(jsonObj[i].type=="date" && jsonObj[i].comparison=="lt"){
                                    Ext.applyIf(jsonObj[i],{
                                        'comparison' : 'lt'
                                    });
                                }
                                else if(jsonObj[i].type=="date" && jsonObj[i].comparison=="gt"){
                                    Ext.applyIf(jsonObj[i],{
                                        'comparison' : 'gt'
                                    });
                                }
                                else if(jsonObj[i].type=="date" && jsonObj[i].comparison=="eq"){
                                    Ext.applyIf(jsonObj[i],{
                                        'comparison' : 'eq'
                                    });
                                }
                            }
                           
                        }
                    }
                }
            }
            jsonObj = jsonObj.filter(item => item !== null);
            for(let i = 0 ; i < jsonObj.length; i++){
                if(jsonObj[i].value[0] == "eq" || jsonObj[i].value[0] == "="){
                    Ext.applyIf(jsonObj[i],{
                        'comparison' : 'eq'
                    });
                    jsonObj[i].type = "number"
                }
                else if(jsonObj[i].value[0] == "geq"){
                    Ext.applyIf(jsonObj[i],{
                        'comparison' : 'geq'
                    });
                    jsonObj[i].type = "number"
                }
                else if(jsonObj[i].value[0] == "gt"){
                    Ext.applyIf(jsonObj[i],{
                        'comparison' : 'gt'
                    });
                    jsonObj[i].type = "number"
                }
                else if(jsonObj[i].value[0] == "leq"){
                    Ext.applyIf(jsonObj[i],{
                        'comparison' : 'leq'
                    });
                    jsonObj[i].type = "number"
                }
                else if(jsonObj[i].value[0] == "lt"){
                    Ext.applyIf(jsonObj[i],{
                        'comparison' : 'lt'
                    });
                    jsonObj[i].type = "number"
                }
                else if(jsonObj[i].value[0] == "neq"){
                    Ext.applyIf(jsonObj[i],{
                        'comparison' : 'neq'
                    });
                    jsonObj[i].type = "number"
                }
            }
            for (let i = 0; i < jsonObj.length; i++) {
                if (jsonObj[i].type === 'number') {
                  // Check if the 'value' array has at least two elements         

                  if (Ext.isArray(jsonObj[i].value) && jsonObj[i].value.length >= 2) {
                    // Remove the first value (element at index 1)
                    jsonObj[i].value.splice(0, 1);
                    jsonObj[i].value = jsonObj[i].value[0];
                  }
                  else{
                    let checkFilterJson = options.config.filters.filter((filter) => filter._value !== "");
                    for (let m = 0; m < jsonObj.length; m++) {
                        let jsonObjItem = jsonObj[m];
                        let jsonObjField = jsonObjItem.field;
                      
                        for (let j = 0; j < checkFilterJson.length; j++) {
                          let checkFilterJsonItem = checkFilterJson[j];
                          let checkFilterJsonProperty = checkFilterJsonItem._property;
                      
                          if (jsonObjField === checkFilterJsonProperty) {
                            jsonObjItem.comparison = checkFilterJsonItem.comparison;
                            break; // Break the inner loop once a match is found
                          }
                        }
                      }
                  }
          
                }
              }
            if(!Ext.isEmpty(updatedJsonObjects)){
               Array.prototype.push.apply(jsonObj,updatedJsonObjects);
            }

            if (jsonObj.length > 1) {
                let hasGtLtPair = false;
                
                               
                // Variables to store the objects that need comparison updates
                var objectWithLtComparison = null;

                // Iterate through the array
                for (let i = 0; i < jsonObj.length; i++) {
                var currentObject = jsonObj[i];

                // Check if the object has "type" equal to "date"
                if (currentObject.type === 'date') {
                    // Check if the object has "field" equal to the same value as the previous object
                    if (objectWithLtComparison && objectWithLtComparison.field === currentObject.field) {
                    // Check if the previous object has "comparison" equal to "lt"
                    if (objectWithLtComparison.comparison === 'lt') {
                        // Update the current object with "comparison" equal to "gt"
                        currentObject.comparison = 'gt';
                        objectToUpdate = currentObject;
                    } else {
                        // Update the previous object with "comparison" equal to "gt"
                        objectWithLtComparison.comparison = 'gt';
                        objectToUpdate = objectWithLtComparison;
                    }
                    } else {
                    // Set the current object as the one with "comparison" equal to "lt" for future comparison
                    objectWithLtComparison = currentObject;
                    }
                }
                else if(currentObject.type == "number"){
                    let filteredArray = jsonObj.filter(obj => obj.value !== '');
                    jsonObj = filteredArray;
                }
                }



                for (let i = 0; i < jsonObj.length; i++) {
                    var uniqueValue = {};
                    Ext.Array.each(jsonObj, function (obj) {
                        var value = obj.field;
                        uniqueValue[value] = obj;
                    });
                    if (jsonObj[i].comparison === undefined) {
                        Ext.applyIf(jsonObj[i], {
                            'comparison': 'like'
                        });
                    }
                    var resultArray = Ext.Object.getValues(uniqueValue);
            
                    if (jsonObj[i].comparison === "gt" && i < jsonObj.length - 1) {
                        for (let j = i + 1; j < jsonObj.length; j++) {
                            if (
                                jsonObj[j].comparison === "lt" &&
                                jsonObj[i].field === jsonObj[j].field
                            ) {
                                hasGtLtPair = true;
                                break;
                            }
                        }
                    }
                }
            
                if (hasGtLtPair) {
                    options._params['filter'] = Ext.JSON.encode(jsonObj);
                } else {
                    options._params['filter'] = Ext.JSON.encode(resultArray);
                }
            }
            
               else{
                   options._params['filter'] = Ext.JSON.encode(jsonObj);
               }
               // }
        }
    }
    else if(!Ext.isEmpty(options) && !Ext.isEmpty(options._params) && !Ext.isEmpty(options._params['filter']) && hasComparison){
        let filteredArray  = Ext.JSON.decode(options._params['filter']);
        const jsonObj = filteredArray.filter(obj => obj.hasOwnProperty('comparison'));
        if( Ext.isArray(jsonObj))
        {
            var updatedJsonObjects = [];
            for( let i = 0 ; i < jsonObj.length; i++ )
            {
                if( !Ext.isEmpty(jsonObj[i].type) && jsonObj[i].type == 'date' && !Ext.isEmpty(jsonObj[i].value))
                {
                    var modal= document.getElementsByClassName('NewFilterModal');
                    let lastElement;
                    let dataIndex = jsonObj[i].field;
                    if(modal.length !=0){
                        for(let i=0; i<modal.length; i++){
                            if(modal[i].querySelectorAll('input[id*="combo"]').length>1){
                                let comboList= modal[i].querySelectorAll('input[id*="combo"]');
                                for (let j=0; j<comboList.length;j++){
                                    if(comboList[j].name == dataIndex){
                                        lastElement = modal[i];
                                    }
                                }
                            }
                            else {
                                if(modal[i].querySelector('input[id*="combo"]').name == dataIndex){
                                    if(modal.length==1){
                                        lastElement = modal[0];
                                    }
                                    else{
                                        lastElement = modal[i];
                                    }
                                }
                            }
                        }
                        var combomodal2 = "input[id*='combo'][name='" + jsonObj[i].field + "']";
                        var combomodal= lastElement.querySelector(combomodal2).value;
                        
                        if(combomodal){
                        var combomodalvalue = combomodal;
                        }
                        if(combomodalvalue == "After"){
                            Ext.applyIf(jsonObj[i],{
                                'comparison' : 'gt'
                            });
                        }
                        else if(combomodalvalue == "Before"){
                            Ext.applyIf(jsonObj[i],{
                                'comparison' : 'lt'
                            });
                        }
                       
                       else if (combomodalvalue === "Between" && !Ext.isEmpty(jsonObj[i].type) && jsonObj[i].type === 'date' && !Ext.isEmpty(jsonObj[i].value)) {
                                if ( jsonObj[i].type === "date") {
                                    var newfilterdatepickerLabel = document.getElementsByClassName('newfilterdatepickerLabel');
                                    if (newfilterdatepickerLabel.length > 1) {
                                        for (let k = 0; k < newfilterdatepickerLabel.length; k++) {
                                            if (newfilterdatepickerLabel[k].getElementsByTagName('input')[0].name === jsonObj[i].field) {
                                                var combomodal3 = newfilterdatepickerLabel[k].getElementsByTagName('input')[0].value;
                                                if (!Ext.isEmpty(combomodal3) && combomodal3 != jsonObj[i].value) {
                                                    // Corrected index here from k to i
                                                    var newJsonObject = {
                                                        value: combomodal3,
                                                        type: 'date',
                                                        field: jsonObj[i].field,
                                                        comparison: 'lt'
                                                    };
                                                    updatedJsonObjects.push(newJsonObject);
                                                    // jsonObj[k] = { value: combomodal3, type: 'date', field: jsonObj[i].field, 'comparison': 'lt' };
                                                }
                                                else{
                                                     // Moved this outside the inner loop and corrected index from k to i
                                                    Ext.applyIf(jsonObj[i], {
                                                        'comparison': 'gt'
                                                    });
                                                }
                                            }
                                        }
                                       
                                    }
                                }
                            }
                                                
                        else if(combomodalvalue === "On"){
                            // if(jsonObj.length>1){
                            //     jsonObj.shift();
                            // }
                            if(jsonObj[i].type=="date"){
                                Ext.applyIf(jsonObj[i],{
                                    'comparison' : 'eq'
                                });
                            }
                        }
                    }
                    else if(modal.length == 0){
                        let userData = JSON.parse(localStorage.getItem('oneManyNewFilter'));
                        if(userData && userData[dataIndex]){
                        var combomodal = userData[dataIndex][0];
                        
                        if(combomodal){
                            var combomodalvalue = combomodal;
                            }
                            if(combomodalvalue == "After"){
                                // var abc=null;
                                // localStorage.setItem("oneManyNewFilter2", JSON.stringify(abc));
                                Ext.applyIf(jsonObj[i],{
                                    'comparison' : 'gt'
                                });
                            }
                            else if(combomodalvalue == "Before"){
                                // var abc=null;
                                // localStorage.setItem("oneManyNewFilter2", JSON.stringify(abc));
                                Ext.applyIf(jsonObj[i],{
                                    'comparison' : 'lt'
                                });
                            }
                            else if (combomodalvalue === "Between" && !Ext.isEmpty(jsonObj[i].type) && !Ext.isEmpty(jsonObj[i].value)) {
                                if ( jsonObj[i].type === "date") {
                                    var newfilterdatepickerLabel = document.getElementsByClassName('newfilterdatepickerLabel');
                                    if (newfilterdatepickerLabel.length > 1) {
                                        for (let k = 0; k < newfilterdatepickerLabel.length; k++) {
                                            if (newfilterdatepickerLabel[k].getElementsByTagName('input')[0].name === jsonObj[i].field) {
                                                var combomodal3 = newfilterdatepickerLabel[k].getElementsByTagName('input')[0].value;
                                                if (!Ext.isEmpty(combomodal3) && combomodal3 != jsonObj[i].value) {
                                                    // Corrected index here from k to i
                                                    var newJsonObject = {
                                                        value: combomodal3,
                                                        type: 'date',
                                                        field: jsonObj[i].field,
                                                        comparison: 'lt'
                                                    };
                                                    updatedJsonObjects.push(newJsonObject);
                                                    // jsonObj[k] = { value: combomodal3, type: 'date', field: jsonObj[i].field, 'comparison': 'lt' };
                                                }
                                                else{
                                                     // Moved this outside the inner loop and corrected index from k to i
                                                    Ext.applyIf(jsonObj[i], {
                                                        'comparison': 'gt'
                                                    });
                                                }
                                            }
                                        }
                                        // // Moved this outside the inner loop and corrected index from k to i
                                        // Ext.applyIf(jsonObj[i], {
                                        //     'comparison': 'gt'
                                        // });
                                    }
                                    else{
                                        const toDateee = JSON.parse(localStorage.getItem('oneManyNewFilter'));
                                        if(!Ext.isEmpty(toDateee)){
                                            toDate = toDateee[jsonObj[i].field][2];
                                            var newJsonObject = {
                                                value: toDate,
                                                type: 'date',
                                                field: jsonObj[i].field,
                                                comparison: 'lt'
                                            };
                                            updatedJsonObjects.push(newJsonObject);
                                        }
                                        else{
                                           Ext.applyIf(jsonObj[i], {
                                               'comparison': 'gt'
                                           });
                                       }
                                    }
                                }
                            }
                            else if(combomodalvalue === "On"){
                                if(jsonObj[i].type=="date"){
                                    Ext.applyIf(jsonObj[i],{
                                        'comparison' : 'eq'
                                    });
                                }
                            }
                        }
                        else {
                            for(let i = 0 ; i < jsonObj.length; i++){
                                if(jsonObj[i].type=="date" && jsonObj[i].comparison=="lt"){
                                    Ext.applyIf(jsonObj[i],{
                                        'comparison' : 'lt'
                                    });
                                }
                                else if(jsonObj[i].type=="date" && jsonObj[i].comparison=="gt"){
                                    Ext.applyIf(jsonObj[i],{
                                        'comparison' : 'gt'
                                    });
                                }
                                else if(jsonObj[i].type=="date" && jsonObj[i].comparison=="eq"){
                                    Ext.applyIf(jsonObj[i],{
                                        'comparison' : 'eq'
                                    });
                                }
                            }
                           
                        }
                    }
                }
          
            }
            // jsonObj = jsonObj.filter(item => item !== null);
            for(let i = 0 ; i < jsonObj.length; i++){
                if(jsonObj[i].type == "number" && !Ext.isArray(jsonObj[i].value)){
                    jsonObj[i].value = jsonObj[i].value.toString();
                }
            }
      
            if(!Ext.isEmpty(updatedJsonObjects)){
               Array.prototype.push.apply(jsonObj,updatedJsonObjects);
            }
            
            if (jsonObj.length > 1) {
                let hasGtLtPair = false;
                
                // Variables to store the objects that need comparison updates
                var objectWithLtComparison = null;

                // Iterate through the array
                for (let i = 0; i < jsonObj.length; i++) {
                var currentObject = jsonObj[i];

                // Check if the object has "type" equal to "date"
                if (currentObject.type === 'date') {
                    // Check if the object has "field" equal to the same value as the previous object
                    if (objectWithLtComparison && objectWithLtComparison.field === currentObject.field) {
                    // Check if the previous object has "comparison" equal to "lt"
                    if (objectWithLtComparison.comparison === 'lt') {
                        // Update the current object with "comparison" equal to "gt"
                        currentObject.comparison = 'gt';
                        objectToUpdate = currentObject;
                    } else {
                        // Update the previous object with "comparison" equal to "gt"
                        objectWithLtComparison.comparison = 'gt';
                        objectToUpdate = objectWithLtComparison;
                    }
                    } else {
                    // Set the current object as the one with "comparison" equal to "lt" for future comparison
                    objectWithLtComparison = currentObject;
                    }
                }
                // else if(currentObject.type == "number"){
                //     let filteredArray = jsonObj.filter(obj => obj.value !== '');
                //     jsonObj = filteredArray;
                // }
                }

            
                for (let i = 0; i < jsonObj.length; i++) {
                    var uniqueValue = {};
                    Ext.Array.each(jsonObj, function (obj) {
                        var value = obj.field;
                        uniqueValue[value] = obj;
                    });
                    if (jsonObj[i].comparison === undefined) {
                        Ext.applyIf(jsonObj[i], {
                            'comparison': 'like'
                        });
                    }
                    var resultArray = Ext.Object.getValues(uniqueValue);
            
                    if (jsonObj[i].comparison === "gt" && i < jsonObj.length - 1) {
                        for (let j = i + 1; j < jsonObj.length; j++) {
                            if (
                                jsonObj[j].comparison === "lt" &&
                                jsonObj[i].field === jsonObj[j].field
                            ) {
                                hasGtLtPair = true;
                                break;
                            }
                        }
                    }
                }
            
                if (hasGtLtPair) {
                    options._params['filter'] = Ext.JSON.encode(jsonObj);
                } else {
                    options._params['filter'] = Ext.JSON.encode(resultArray);
                }
            }
            
               else{
                   options._params['filter'] = Ext.JSON.encode(jsonObj);
               }
               /*OSPRODUCT-34763*/
               var newfilterFromList = options._params['filter'];
               localStorage.setItem("newfilterFromList", newfilterFromList);
                /**/
               // }
        }
    }
    


    options.params['blkType'] = gridPanel.blockObj.type;

    if (gridPanel.blockObj.grid.editable === true) {
        var changesOnPage = this.getChangesAvailableOnPage();
        if (changesOnPage.nameFields.length > 0) {
            options.params['namefields'] = changesOnPage.nameFields;
            var nameFieldsKeyValue = changesOnPage.nameFieldsKeyValue;
            for (var nameFieldKeyValue in nameFieldsKeyValue) {
                options.params[nameFieldKeyValue] = nameFieldsKeyValue[nameFieldKeyValue];
            }
            options.params['WORKFLOW_CONTEXT'] = Dragon.util.OSFormUtils.getBvElement('WORKFLOW_CONTEXT').getValue();
        }
    }

    if (options.getSorters() && options.getSorters().length > 0) {
        /**
         * The following code commented for sort issue
         */

        var sortColumn = options.getSorters()[0].getProperty();
        sortOrder = options.getSorters()[0].getDirection() == 'ASC' ? 1 : 0;

        sortList = '"sort_list":[{"cell_id":' + sortColumn + ', "order":' + sortOrder + '}]';

        options.params['multiSortString'] = sortList;
    }

    var searchTxtObj = Ext.getCmp(searchTxtId);

    if (searchTxtObj) {
        options.params['searchString'] = searchTxtObj.getValue();
    }

    var searchColumnObj = Ext.getCmp(searchColumnId);

    if (searchColumnObj) {
        options.params['searchColumn'] = searchColumnObj.getValue();
    }

    if (gridPanel && gridPanel.blockObj && gridPanel.blockObj.grid && gridPanel.blockObj.grid.editorCells && !Ext.isEmpty(gridPanel.blockObj.grid.editorCells)) {
        if (!Ext.isEmpty(gridPanel.blockObj.grid.editorCells[0])) {
            options.params['editorCells'] = Ext.encode(gridPanel.blockObj.grid.editorCells[0]);
        }

        var prevObjectIDs = new Array(gridPanel.blockObj.grid.editorCells.length);

        for (var i = 0; i < prevObjectIDs.length; i++) {
            prevObjectIDs[i] = gridPanel.blockObj.grid.editorCells[i]["ROW-OBJECT-ID"];
        }

        options.params['prevObjectIDs'] = prevObjectIDs.join();
    }

    options.params['objectTree'] = Dragon.util.OSFormUtils.getBvElement('OBJECT_TREE').getValue();

    options.params['gridObjectType'] = gridPanel.blockObj.grid.listElementObjecttype;

    options.setParams(Ext.apply(options.getParams() || {}, options.params));

    gridPanel.getSelectionModel().suspendEvents(false);
        
    }
});