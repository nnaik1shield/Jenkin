Ext.define('Dragon.overrides.view.One_Many_Row_Level_Block', {
    override: 'Dragon.view.One_Many_Row_Level_Block',
    initComponent: function() {
        var me = this;
        var  maxWidthFlutter = 0;
        me.on('afterlayout', () => {
            // var myblockpar = document.getElementById(this.id);
            // console.log(me.el.findParentNode(".page-layout-block"));
            // var myblock =  document.getElementsByClassName("x-panel-DashboardTaskBlock ");
           var myblock =  me.el.findParent(".page-layout-block");
           var imagesrc = APPUTILS.getImagePath('chevron-white.svg', VIEWCONSTANTS.FES_IMAGE_DEFAULT_FOLDER)
           var blockLevelButtons = myblock.getElementsByClassName('block-level-button');
           var notFlutterBtn = myblock.getElementsByClassName('x-btn-notFlutterBtn-small');
           var blockLevelButtonsMaxWidth = [...myblock.getElementsByClassName('block-level-button')].filter(x => {
             return !x.classList.contains('x-btn-notFlutterBtn-small')
           });
           var titleBlock = myblock.getElementsByClassName('x-panel-header')
           var labeltitleBlock = myblock.getElementsByClassName('x-panel-header-title')
           if(!Ext.isEmpty(labeltitleBlock[0])){
            var titleValueBlock = labeltitleBlock[0].childNodes[0].childNodes[0].innerHTML
            labeltitleBlock[0].setAttribute('data-qtip',titleValueBlock);
          }  
           
           if(titleBlock.length>0){
           /**************************************************
               To add the block level buttons to the flutter button menu 
               To add ellipsis menu 
               To add modal window on new filter click 
               **************************************************/
               if (blockLevelButtons.length > 0) {
                 if(blockLevelButtonsMaxWidth.length > 0) {
                   for (let i = 0; i < blockLevelButtonsMaxWidth.length; i++) {
                     var btnWidth = blockLevelButtonsMaxWidth[i].clientWidth + 10
                     maxWidthFlutter = btnWidth > maxWidthFlutter ? btnWidth : maxWidthFlutter
                   }
                   for (let p = 0; p < blockLevelButtonsMaxWidth.length; p++) {
                     blockLevelButtonsMaxWidth[p].style.width = maxWidthFlutter + 'px';
                   }
                 }
                   /**************************************************
                            To remove the extra space of the toolbar between the title and table header
                               **************************************************/
                   var hidetoolbar = [...myblock.getElementsByClassName('x-toolbar x-docked x-toolbar-default')].filter(x => {
                     return !x.classList.contains('x-one-many-block-toolbar')
                   })
             
            
                   if (blockLevelButtons.length > 1) {
                     //blockLevelButtons[0].style = 'background: 92% 50% #008ccc url(' + imagesrc + ') no-repeat;'
                     blockLevelButtons[0].style = 'background-image: url(' + imagesrc + ');background-repeat: no-repeat;background-position: 95% 50%;padding-right: 15px;width:' + maxWidthFlutter + 'px';
                   }
                   // var deleteButton = document.createElement('div')
                   // deleteButton.classList.add('deleteButton')
                   var menu = document.createElement('div')
                   menu.classList.add('flutter-button-menu')
                   menu.style = 'min-width:' + maxWidthFlutter + 'px';
                   var content = document.createElement('div')
                   content.classList.add('flutter-list')
                   const blockLevelBtnLength = blockLevelButtons.length;
                   for ( var f = 0; f <= blockLevelBtnLength; f++) {
                     if(blockLevelButtons[0]){
                     var delteee = blockLevelButtons[0].childNodes[0].innerText;
                     
                     // var dassa = blockLevelButtons[f].lastChild.childNodes[0].childNodes[1].innerText;
                       if(delteee.toLowerCase() != "delete"){
                       // if(delteee.toLowerCase() != "add" && dassa.toLowerCase() != "add" ){
                         if(!blockLevelButtons[0].classList.contains('x-btn-notFlutterBtn-small')){
                           if(
                             menu.childElementCount<1
                         ) {
                           menu.appendChild(blockLevelButtons[0]);
                           }
                           else {
                             content.appendChild(blockLevelButtons[0]);
                           }
                         }
                       }
                     }
                     // else if (menu.childElementCount>=1){
                     //   for ( var v = 0; v <= blockLevelButtons.length; v++) {
                     //     if(!blockLevelButtons[0].classList.contains('x-btn-notFlutterBtn-small')){
                     //       content.appendChild(blockLevelButtons[0]);
                     //     }
                     //   }
                     // }
                   }
              
              
                   
                       if(notFlutterBtn.length == 0){
                         if (hidetoolbar[0]) {
                           hidetoolbar[0].style = 'padding:0px';
                           hidetoolbar[0].style.display = "none";
                           hidetoolbar[0].firstChild.style.height = 0;
                         }
                       }
                   menu.appendChild(content)
                   titleBlock[0].appendChild(menu)
                   // titleBlock[0].appendChild(deleteButton)
                   menu.addEventListener('mouseover', () => {
                     content.style.display = 'block';
                   })
                   menu.addEventListener('mouseleave', () => {
                     content.style.display = 'none';
                   })
            
                   var elm = document.getElementsByClassName('flutter-button-menu')
                   for (k = 0; k < elm.length; k++) {
                     if (elm[k].childNodes.length < 2) {
                       elm[k].remove()
                     }
                   }
                  
                   /******************************************* */
            
                   if (!content.hasChildNodes()) {
                     menu.classList.add("rounded-borders");
                   } else if (content.hasChildNodes()) {
                     menu.addEventListener('mouseover', () => {
                       content.style.display = 'block';
                       blockLevelButtons[0].style = 'background-image: none;background-repeat: no-repeat;background-position: 95% 50%;padding-right: 15px;width:' + maxWidthFlutter + 'px';
                     })
                     menu.addEventListener('mouseleave', () => {
                       content.style.display = 'none';
                       blockLevelButtons[0].style = 'background-image: url(' + imagesrc + ');background-repeat: no-repeat;background-position: 95% 50%;padding-right: 15px;width:' + maxWidthFlutter + 'px';
            
                     })
                   }
            
                 }
                 
               }

        })
        this.callParent(arguments);
    }
});
