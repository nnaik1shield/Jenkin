
Ext.define('Dragon.overrides.view.widget.PersonalizedFilterList', {
	override: 'Dragon.view.widget.PersonalizedFilterList',
/**
 * @method initComponent
 * Function initializes a component.
 * @param cfg
 */
initComponent:function(cfg) 
{
var me = this;
if( me.showAdd ){
	me.cls ="AddFilterWindow"
}
else if ( me.showList ){
	me.cls ="ApplyFilterWindow"
}
  me.callParent(arguments);
},
items: [{
itemId: 'cb',
layout: 'fit',
anchor: '100%',  
xtype: 'combo',
typeAhead: true,
hideLabel: true,
hideTrigger:false,
hidden: true,
minChars: 1,
  store : 
  {
	model: 'Dragon.model.PersonalizedFilter',
	proxy:
	{	
		type :'ajax',
		url : 	'PersonalizedFilterServlet',
		actionMethods: {create: 'POST', read: 'POST', update: 'POST', destroy: 'POST'}
	}
  },
  listConfig: 
  {
	  getInnerTpl: function() 
	  {
		g_OsLogger.info("getInnerTpl() is called", this, { 
			methodName: 'getInnerTpl'
		});
		var me = this;
		var filterPars = this.up('window').getFilterParameters(['sessionId','transactionId','{view_id}']);
		  
		  return '<div class="pers-filter-lookup-item">' +
					  '<span class="item-text">' +
						  '<a class="pers-filter-lookup-text" onclick="javascript:Ext.getCmp(\''+ this.getId() +
							  '\').up(\'osPersonalizedFilterList\').fireEvent(\'pers-filter-item-select\',' +
							  filterPars  +
							  ');">{view_name}' +
						  '</a>' +
					  '</span>'+
					  '<span class="item-del">' + 
						  '<a class="pers-filter-lookup-delete" onclick="javascript:Ext.getCmp(\''+ this.getId() +
							  '\').up(\'osPersonalizedFilterList\').fireEvent(\'pers-filter-item-delete\',' +
							  filterPars +
							  ');">delete' +
						  '</a>' +
					  '</span>' +
				  '</div>';
		}
  },
  listeners: 
  {
	  destroy: function() 
	  {
		Dragon.model.PersonalizedFilter.isRunning = false;
	  },
	scope: this,
	  afterRender: function(me){
		if(!Ext.isEmpty(me.ownerCt.parGrid) && !Ext.isEmpty(me.ownerCt.parGrid.currentView.viewName)){
			me.setValue(me.ownerCt.parGrid.currentView.viewName); 
		}
		else{
			me.setValue('-Select-'); 
		}
		var closeButton = me.ownerCt.down('tool[type=close]');
		if (closeButton) {
		  closeButton.getEl().set({'osviewid': 'PAI'+'_'+me.ownerCt.parGrid.id+'_'+closeButton.type+'_'+'personalizedFilter'});
		}	
		if ( me) {
			let osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
			(Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+VIEWCONSTANTS.UNDERSCORE+me.ownerCt.container.id+VIEWCONSTANTS.UNDERSCORE) ;
			me.inputEl.dom.setAttribute('osviewid',osviewid+me.xtype+VIEWCONSTANTS.UNDERSCORE+'personalizedFilterList');
		}   
		if ( me.triggerEl.elements.length>0) {
			let osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
			(Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+VIEWCONSTANTS.UNDERSCORE+me.ownerCt.container.id+VIEWCONSTANTS.UNDERSCORE) ;
			me.triggerEl.elements[0].dom.setAttribute('osviewid',osviewid+me.xtype+'combotrigger'+VIEWCONSTANTS.UNDERSCORE+'personalizedFilterTrigger');
		}  
	  }
  }
}, 
{
	xtype: 'textfield',
	name: 'pfsAdd',
	fieldLabel: 'pfsAdd',
	hideLabel: true,
	allowBlank: false,
	hidden: true,
	maxLength: 16,
	validationMessage: '',
	checkChangeEvents :[],
	msgTarget: 'side',
	listeners: 
	{
		/**
		 * @event destroy
		 * Function fires after the component is method destroyed.
		 */
		destroy: function()
		{
			Dragon.model.PersonalizedFilter.isRunning = false;
		},
		/**
		 * @event specialkey
		 * Function fires when any key related to event is pressed.
		 * @param field
		 * @param e
		 */
		specialkey: function(field, e)
		{
			g_OsLogger.info("Event key is pressed", this, { 
				methodName: 'specialkey', 
				specialkey: e.getKey()
			});
			// e.HOME, e.END, e.PAGE_UP, e.PAGE_DOWN,
			// e.TAB, e.ESC, arrow keys: e.LEFT, e.RIGHT, e.UP, e.DOWN
			if (e.getKey() == e.ENTER || e.getKey() == e.TAB) 
			{
				if (field.getValue() !== "") 
				{
					var modal= document.getElementsByClassName('NewFilterModal');
					if(!Ext.isEmpty(modal)){
						 if(modal.length>1){
							var arr = Array.prototype.slice.call( modal )
							arr.shift();
							modal = arr;
                            }
						var combomodal= modal[0].querySelectorAll('input[id*="combo"]');
					}
					var blk = this.ownerCt.parGrid;
					var oldVal = (blk.currentView && blk.currentView['viewName']) || '';
					var viewId = (blk.currentView && blk.currentView['viewId']) || '';
					if (oldVal && this.getValue() != oldVal)
					{
						viewId = '';
					}
					if(!Ext.isEmpty(modal)){
						
						var savedQuery = JSON.parse(blk.config['savedQuery']);
						savedQuery = savedQuery.filter(item => item.data.value[1] !== "");
						// const dateFilterIdx = savedQuery.findIndex((entry) => entry.data.type === 'date');
						const dateFilterIdx = savedQuery.reduce((count, obj) => {
							if (obj.data && obj.data.type === 'date') {
							  return count + 1;
							} else {
							  return count;
							}
						  }, 0);
						
						if (dateFilterIdx >= 0) {
							let prevIndex = -1; // Initialize with an invalid index

							for (let i = 0; i < combomodal.length; i++) {
							  if (combomodal[i].attributes.name && typeof combomodal[i].attributes.name === 'string') {
								var comboDataIndex = combomodal[i].attributes.name;
							  } else if (combomodal[i].attributes.name) {
								comboDataIndex = combomodal[i].attributes.name.value;
							  }
							
							  // Check if savedQuery[i] is present, otherwise use the previous non-empty index
							  const savedQueryIndex = savedQuery[i] ? i : prevIndex;
							
							  if (combomodal[i].value === 'On' && !Ext.isEmpty(savedQuery[savedQueryIndex]) && savedQuery[savedQueryIndex].field === comboDataIndex) {
								 if(savedQuery[savedQueryIndex].data.type === "string" && !Ext.isArray(savedQuery[savedQueryIndex].data.value)){
									savedQuery[savedQueryIndex].data.comparison = 'like'
								} else {
								  savedQuery[savedQueryIndex].data.comparison = 'eq';
								}
							  } else if (combomodal[i].value === 'After' && !Ext.isEmpty(savedQuery[savedQueryIndex])) {
								savedQuery[savedQueryIndex].data.comparison = 'gt';
							  } else if (combomodal[i].value === 'Before' && !Ext.isEmpty(savedQuery[savedQueryIndex])) {
								savedQuery[savedQueryIndex].data.comparison = 'lt';
							  } else if (combomodal[i].value === 'Between' && !Ext.isEmpty(savedQuery[savedQueryIndex])) {
								
								let obj= Ext.JSON.decode(localStorage.getItem('oneManyNewFilter'));
								// Iterate through the object
								for (var key in obj) {
								if (Array.isArray(obj[key]) && obj[key][0] === "Between") {
									var currentIndex = parseInt(key, 10);
									currentIndex = currentIndex.toString();
									if (currentIndex === comboDataIndex) {
									// If the index matches, get the last value of the object
									var gtDate = obj[key][2];
									// console.log("Last value:", lastValue);
									break; // Exit the loop since we found the match
									}
								}
								}

								var gtDateValue = gtDate;
								var ab = { field: savedQuery[savedQueryIndex].field, data: { type: "date", value: gtDateValue, comparison: 'lt' } };
								for (let i = 0; i < savedQuery.length; i++) {
									var currentItem = savedQuery[i];
								  
									// Check if the "field" property matches the fieldToMatch value
									if (currentItem.field === comboDataIndex) {
									  // If it matches, you can perform your desired action here
									  savedQuery[i].data.comparison = 'gt';
									}
								  }
								savedQuery.push(ab);
							  }
							  else{
								if (savedQuery[savedQueryIndex].data.type === "string" && Ext.isArray(savedQuery[savedQueryIndex].data.value) ) {
									savedQuery[savedQueryIndex].data.type = 'number';
									if(savedQuery[savedQueryIndex].data.value[0] == "eq"){
									  savedQuery[savedQueryIndex].data.comparison = 'eq'
									}
									else if(savedQuery[savedQueryIndex].data.value[0] == "neq"){
									  savedQuery[savedQueryIndex].data.comparison = 'neq'
									}
									else if(savedQuery[savedQueryIndex].data.value[0] == "leq"){
									  savedQuery[savedQueryIndex].data.comparison = 'leq'
									}
									else if(savedQuery[savedQueryIndex].data.value[0] == "gt"){
									  savedQuery[savedQueryIndex].data.comparison = 'gt'
									}
									else if(savedQuery[savedQueryIndex].data.value[0] == "lt"){
									  savedQuery[savedQueryIndex].data.comparison = 'lt'
									}
									else if(savedQuery[savedQueryIndex].data.value[0] == "geq"){
									  savedQuery[savedQueryIndex].data.comparison = 'geq'
									}
									savedQuery[savedQueryIndex].data.value.splice(0, 1);
									savedQuery[savedQueryIndex].data.value = savedQuery[savedQueryIndex].data.value[0];
								  }
								  
							  }
							
							  prevIndex = savedQueryIndex; // Update the previous index
							}
							
							this.ownerCt.parGrid.config.savedQuery = JSON.stringify(savedQuery);
							
						}
					}
			
			
			
					var viewName = this.getValue();
			
					var filterExist = false;
			
					//check the view name already used in this grid
					Ext.Ajax.request({
						url: 'PersonalizedFilterServlet',
						method: 'POST',
						async: false,
						params: {
							'op': 'list',
							'blockId' : this.ownerCt.parGrid.blockObj.id,
							'actionId' : this.ownerCt.actionId,
							'query' : viewName,
							'userSessionId': Dragon.config.Runtime.getUserSessionId(),
							'transactionId': Dragon.config.Runtime.getTransactionId()
						},
						success: function (response) {
							g_OsLogger.debug("call to PersonalizedFilterServlet is succesful", this, { methodName: 'addFilter', statusText: response.statusText });
			
							var jsonResponse = Ext.decode(response.responseText);
			
							if (jsonResponse['SUCCESS'] === 'false')
							{
								Ext.create('Dragon.view.ServerErrorWindow', { message: jsonResponse['MESSAGE'].replace(/<br[^>]*>/g, "\n") }).show();
							}
							else
							{
			
								g_OsLogger.debug("Filter list response:" + response.responseText);
			
								for (var ii = 0; ii < jsonResponse.length; ii++)
								{
									currentViewName = jsonResponse[ii]['view_name'];
			
									//check the view name already used in this grid
									if(viewName.toLowerCase() === currentViewName.toLowerCase())
										filterExist = true;
								}
			
							}
						},
						failure: function (response) {
							g_OsLogger.error("Request to 'PersonalizedFilterServlet' failed ", this, { methodName: 'addFilter', statusText: response.statusText })
						}
					});
			
					/* */
					if(filterExist)
					{
						var modalWindow = Ext.create('Ext.window.Window', {
							title: 'Error',
							width: 300,
							cls:'filterAlreadyExistModal',
							height: 200,
							modal: true, // Set modal to true to make it a modal window
							layout: 'fit', // Use fit layout to stretch the textarea to the window size
							items: [{
								xtype: 'panel',
								html: 'The filter name already exists. Enter a different filter name.'
							}],
							buttons: [
								{
								  text: 'OK',
								  handler: function() {
									// Close the modal window when the OK button is clicked
									modalWindow.close();
								  }
								}
							  ]
						});
						
						// Show the modal window
						modalWindow.show();	
					
						return "The filter name already exists. Enter a different filter name.";
					}
					else
					{
			
						this.up('osPersonalizedFilterList').fireEvent('pers-filter-item-add',viewId,this.getValue(),this.ownerCt.parGrid);
			
						this.ownerCt.destroy();
			
							Ext.MessageBox.show({
								msg: 'Your filter has been saved successfully!',
								cls: 'toastLikeModal',
								modal: false,
								closable: true
							});
			
							setTimeout(function() {
								Ext.MessageBox.hide();
							}, 6000);
			
							return true;
						}
							 
				}
			}
			
		},
		afterrender: function(textField) {
			if ( textField.inputEl) {
				let osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
				(Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+VIEWCONSTANTS.UNDERSCORE+textField.ownerCt.parGrid.id+VIEWCONSTANTS.UNDERSCORE) ;
				textField.inputEl.dom.setAttribute('osviewid',osviewid+textField.xtype+VIEWCONSTANTS.UNDERSCORE+textField.ownerCt.actionId);
			}
		},
	}
}
],
buttons: [
	{
		text: 'Save Filter',
		handler: function() {
			let parPanel = this.ownerCt.ownerCt;
			let field = parPanel.down('textfield[name=pfsAdd]');
				if (field.getValue() !== "") 
				{
					var modal= document.getElementsByClassName('NewFilterModal');
					if(!Ext.isEmpty(modal)){
						if(modal.length>1){
							var arr = Array.prototype.slice.call( modal )
							arr.shift();
							modal = arr;
                            }
						var combomodal= modal[0].querySelectorAll('input[id*="combo"]');
					}
					var blk = this.ownerCt.ownerCt.parGrid;
					var oldVal = (blk.currentView && blk.currentView['viewName']) || '';
					var viewId = (blk.currentView && blk.currentView['viewId']) || '';
					if (oldVal && field.getValue() != oldVal)
					{
						viewId = '';
					}
					if(!Ext.isEmpty(modal)){
						const savedQuery = JSON.parse(blk.config['savedQuery']);
						// const dateFilterIdx = savedQuery.findIndex((entry) => entry.data.type === 'date');
						const dateFilterIdx = savedQuery.reduce((count, obj) => {
							if (obj.data && obj.data.type === 'date') {
							  return count + 1;
							} else {
							  return count;
							}
						  }, 0);
						
						if (dateFilterIdx >= 0) {
							let prevIndex = -1; // Initialize with an invalid index

							for (let i = 0; i < combomodal.length; i++) {
							  if (combomodal[i].attributes.name && typeof combomodal[i].attributes.name === 'string') {
								var comboDataIndex = combomodal[i].attributes.name;
							  } else if (combomodal[i].attributes.name) {
								comboDataIndex = combomodal[i].attributes.name.value;
							  }
							
							  // Check if savedQuery[i] is present, otherwise use the previous non-empty index
							  const savedQueryIndex = savedQuery[i] ? i : prevIndex;
							
							  if (combomodal[i].value === 'On' && !Ext.isEmpty(savedQuery[savedQueryIndex]) && savedQuery[savedQueryIndex].field === comboDataIndex) {
								if (savedQuery[savedQueryIndex].data.type === "string") {
								  savedQuery[savedQueryIndex].data.comparison = 'like';
								} else {
								  savedQuery[savedQueryIndex].data.comparison = 'eq';
								}
							  } else if (combomodal[i].value === 'After' && !Ext.isEmpty(savedQuery[savedQueryIndex])) {
								savedQuery[savedQueryIndex].data.comparison = 'gt';
							  } else if (combomodal[i].value === 'Before' && !Ext.isEmpty(savedQuery[savedQueryIndex])) {
								savedQuery[savedQueryIndex].data.comparison = 'lt';
							  } else if (combomodal[i].value === 'Between' && !Ext.isEmpty(savedQuery[savedQueryIndex])) {
								let obj= Ext.JSON.decode(localStorage.getItem('oneManyNewFilter'));
								// Iterate through the object
								for (var key in obj) {
								if (Array.isArray(obj[key]) && obj[key][0] === "Between") {
									var currentIndex = parseInt(key, 10);
									currentIndex = currentIndex.toString();
									if (currentIndex === comboDataIndex) {
									// If the index matches, get the last value of the object
									var gtDate = obj[key][2];
									// console.log("Last value:", lastValue);
									break; // Exit the loop since we found the match
									}
								}
								}

								var gtDateValue = gtDate;
								var ab = { field: savedQuery[savedQueryIndex].field, data: { type: "date", value: gtDateValue, comparison: 'lt' } };
								for (let i = 0; i < savedQuery.length; i++) {
									var currentItem = savedQuery[i];
								  
									// Check if the "field" property matches the fieldToMatch value
									if (currentItem.field === comboDataIndex) {
									  // If it matches, you can perform your desired action here
									  savedQuery[i].data.comparison = 'gt';
									}
								  }
								savedQuery.push(ab);
							  }
							  else{
								if (savedQuery[savedQueryIndex].data.type === "string" && Ext.isArray(savedQuery[savedQueryIndex].data.value) ) {
									savedQuery[savedQueryIndex].data.type = 'number';
									if(savedQuery[savedQueryIndex].data.value[0] == "eq"){
									  savedQuery[savedQueryIndex].data.comparison = 'eq'
									}
									else if(savedQuery[savedQueryIndex].data.value[0] == "neq"){
									  savedQuery[savedQueryIndex].data.comparison = 'neq'
									}
									else if(savedQuery[savedQueryIndex].data.value[0] == "leq"){
									  savedQuery[savedQueryIndex].data.comparison = 'leq'
									}
									else if(savedQuery[savedQueryIndex].data.value[0] == "gt"){
									  savedQuery[savedQueryIndex].data.comparison = 'gt'
									}
									else if(savedQuery[savedQueryIndex].data.value[0] == "lt"){
									  savedQuery[savedQueryIndex].data.comparison = 'lt'
									}
									else if(savedQuery[savedQueryIndex].data.value[0] == "geq"){
									  savedQuery[savedQueryIndex].data.comparison = 'geq'
									}
									savedQuery[savedQueryIndex].data.value.splice(0, 1);
									savedQuery[savedQueryIndex].data.value = savedQuery[savedQueryIndex].data.value[0];
								  }
								  
							  }
							
							  prevIndex = savedQueryIndex; // Update the previous index
							}
								this.ownerCt.ownerCt.parGrid.config['savedQuery'] = JSON.stringify(savedQuery);
							
						}
					}
			
			
			
					var viewName = field.getValue();
			
					var filterExist = false;
			
					//check the view name already used in this grid
					Ext.Ajax.request({
						url: 'PersonalizedFilterServlet',
						method: 'POST',
						async: false,
						params: {
							'op': 'list',
							'blockId' : this.ownerCt.ownerCt.parGrid.blockObj.id,
							'actionId' : this.ownerCt.ownerCt.actionId,
							'query' : viewName,
							'userSessionId': Dragon.config.Runtime.getUserSessionId(),
							'transactionId': Dragon.config.Runtime.getTransactionId()
						},
						success: function (response) {
							g_OsLogger.debug("call to PersonalizedFilterServlet is succesful", this, { methodName: 'addFilter', statusText: response.statusText });
			
							var jsonResponse = Ext.decode(response.responseText);
			
							if (jsonResponse['SUCCESS'] === 'false')
							{
								Ext.create('Dragon.view.ServerErrorWindow', { message: jsonResponse['MESSAGE'].replace(/<br[^>]*>/g, "\n") }).show();
							}
							else
							{
			
								g_OsLogger.debug("Filter list response:" + response.responseText);
			
								for (var ii = 0; ii < jsonResponse.length; ii++)
								{
									currentViewName = jsonResponse[ii]['view_name'];
			
									//check the view name already used in this grid
									if(viewName.toLowerCase() === currentViewName.toLowerCase())
										filterExist = true;
								}
			
							}
						},
						failure: function (response) {
							g_OsLogger.error("Request to 'PersonalizedFilterServlet' failed ", this, { methodName: 'addFilter', statusText: response.statusText })
						}
					});
			
					/* */
					if(filterExist)
					{
						var modalWindow = Ext.create('Ext.window.Window', {
							title: 'Error',
							width: 300,
							cls:'filterAlreadyExistModal',
							height: 200,
							modal: true, // Set modal to true to make it a modal window
							layout: 'fit', // Use fit layout to stretch the textarea to the window size
							items: [{
								xtype: 'panel',
								html: 'The filter name already exists. Enter a different filter name.'
							}],
							buttons: [
								{
								  text: 'OK',
								  handler: function() {
									// Close the modal window when the OK button is clicked
									modalWindow.close();
								  }
								}
							  ]
						});
						
						// Show the modal window
						modalWindow.show();				
						return "The filter name already exists. Enter a different filter name.";
					}
					else
					{
			
						this.up('osPersonalizedFilterList').fireEvent('pers-filter-item-add',viewId,field.getValue(),this.ownerCt.ownerCt.parGrid);
			
						this.ownerCt.ownerCt.destroy();
			
							Ext.MessageBox.show({
								msg: 'Your filter has been saved successfully!',
								cls: 'toastLikeModal',
								modal: false,
								closable: true
							});
			
							setTimeout(function() {
								Ext.MessageBox.hide();
							}, 6000);
			
							return true;
						}
							 
			}
		}
	}]
});
