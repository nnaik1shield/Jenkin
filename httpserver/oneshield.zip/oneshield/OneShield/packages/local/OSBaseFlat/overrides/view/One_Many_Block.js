var currSavedFilter = null;
const storedFilters = localStorage.getItem('allSavedFilters');
if (storedFilters) {
    var allSavedFilters = JSON.parse(localStorage.getItem('allSavedFilters'));
} else {
    var allSavedFilters = [];
}
Ext.define('Dragon.overrides.view.One_Many_Block', {
  override: 'Dragon.view.One_Many_Block',
  requires :['Dragon.BaseNewUI.view.NewFilterModal'],
  initComponent: function() {
      var me = this;
      var  store = me.store;
      var maxWidthFlutter = 0;
      me["blockTitle"] = me.title;
      me.on('titlechange', () => {
          if (me.title.includes('of')) {
              me.setTitle(me.parBlock.title)
          }
      })
      me.blockObj.blockMsgWhenNoData = "No record found";
      me.on('afterlayout', () => {
       
          var savedFilterValue = "";
          var myblock = document.getElementById(this.id)
          var imagesrc = APPUTILS.getImagePath('chevron-white.svg', VIEWCONSTANTS.FES_IMAGE_DEFAULT_FOLDER)
          var blockLevelButtons = myblock.getElementsByClassName('block-level-button');
          var notFlutterBtn = myblock.getElementsByClassName('x-btn-notFlutterBtn-small');
          var hasDeleteButton = false;
          var blockLevelButtonsMaxWidth = [...myblock.getElementsByClassName('block-level-button')].filter(x => {
            return !x.classList.contains('x-btn-notFlutterBtn-small')
          });
          var titleBlock = myblock.getElementsByClassName('x-panel-header')
          var labeltitleBlock = myblock.getElementsByClassName('x-panel-header-title')
          var osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
          (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]) + 
          VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.OBJECT_TYPE + VIEWCONSTANTS.UNDERSCORE + this.blockObj.objectTypeId + 
          VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.BLOCK_ID + VIEWCONSTANTS.UNDERSCORE + this.blockObj.id + VIEWCONSTANTS.UNDERSCORE +
          VIEWCONSTANTS.GRID;

          if(labeltitleBlock.length>0){
            if(labeltitleBlock[0].childNodes[0]){
            var titleValueBlock = labeltitleBlock[0].childNodes[0].childNodes[0].innerHTML
            labeltitleBlock[0].setAttribute('data-qtip',titleValueBlock);
            }
          }    
          this.applyIconClassToGridRowButtons();
          /***********************************************/
          if(myblock.classList.contains('x-panel-DiaryGridIcons')){
              var lastCell = myblock.getElementsByClassName('x-grid-cell-last');
              for (let i = 0; i < lastCell.length; i++) {
                lastCell[i].classList.add('diaryactions')
                lastCell[i].setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+'diaryactions');
              }
              var lastDiaryCol = myblock.getElementsByClassName(' x-column-header-last');
              lastDiaryCol[0].childNodes[0].childNodes[0].innerHTML =" ";
              lastDiaryCol[0].classList.add('diaryActionHeader');
          }
           /***********************************************/
          if(titleBlock.length>0){
          /**************************************************
              To add the block level buttons to the flutter button menu 
              To add ellipsis menu 
              To add modal window on new filter click 
              **************************************************/
              if (blockLevelButtons.length > 0) {
                if(blockLevelButtonsMaxWidth.length > 0) {
                  for (let i = 0; i < blockLevelButtonsMaxWidth.length; i++) {
                    var btnWidth = blockLevelButtonsMaxWidth[i].clientWidth + 1
                    maxWidthFlutter = btnWidth > maxWidthFlutter ? btnWidth : maxWidthFlutter
                  }
                  for (let p = 0; p < blockLevelButtonsMaxWidth.length; p++) {
                    blockLevelButtonsMaxWidth[p].style.width = maxWidthFlutter + 'px';
                  }
                }
                  /**************************************************
                           To remove the extra space of the toolbar between the title and table header
                              **************************************************/
                  var hidetoolbar = [...myblock.getElementsByClassName('x-toolbar x-docked x-toolbar-default')].filter(x => {
                    return !x.classList.contains('x-one-many-block-toolbar')
                  })
            
           
                  if (blockLevelButtons.length > 1) {
                    //blockLevelButtons[0].style = 'background: 92% 50% #008ccc url(' + imagesrc + ') no-repeat;'
                    blockLevelButtons[0].style = 'background-image: url(' + imagesrc + ');background-repeat: no-repeat;background-position: 95% 50%;padding-right: 15px;width:' + maxWidthFlutter + 'px';
                  }
                  // var deleteButton = document.createElement('div')
                  // deleteButton.classList.add('deleteButton')
                  var menu = document.createElement('div')
                  menu.classList.add('flutter-button-menu')
                  menu.style = 'min-width:' + maxWidthFlutter + 'px';
                  var content = document.createElement('div')
                  content.classList.add('flutter-list')
                  const blockLevelBtnLength = blockLevelButtons.length;
                  for ( var f = 0; f <= blockLevelBtnLength; f++) {
                    if(blockLevelButtons[0]){
                    var delteee = blockLevelButtons[0].childNodes[0].innerText;
                    if(delteee.toLowerCase() == "delete"){
                      // blockLevelButtons[0].classList.add('DeleteIcon');
                      hasDeleteButton = true;
                    }
                    // var dassa = blockLevelButtons[f].lastChild.childNodes[0].childNodes[1].innerText;
                     else if(delteee.toLowerCase() != "delete"){
                      // if(delteee.toLowerCase() != "add" && dassa.toLowerCase() != "add" ){
                        if(!blockLevelButtons[0].classList.contains('x-btn-notFlutterBtn-small')){
                          if(
                            menu.childElementCount<1
                        ) {
                          menu.appendChild(blockLevelButtons[0]);
                          }
                          else {
                            content.appendChild(blockLevelButtons[0]);
                          }
                        }
                      }
                    }
           
                  }
             
             
                  
                      if(notFlutterBtn.length == 0 && hasDeleteButton == false){
                        if (hidetoolbar[0]) {
                          hidetoolbar[0].style = 'padding:0px';
                          hidetoolbar[0].style.display = "none";
                          hidetoolbar[0].firstChild.style.height = 0;
                        }
                      }
                  menu.appendChild(content)
                  titleBlock[0].appendChild(menu)
                  // titleBlock[0].appendChild(deleteButton)
                  menu.addEventListener('mouseover', () => {
                    content.style.display = 'block';
                  })
                  menu.addEventListener('mouseleave', () => {
                    content.style.display = 'none';
                  })
           
                  var elm = document.getElementsByClassName('flutter-button-menu')
                  for (k = 0; k < elm.length; k++) {
                    if (elm[k].childNodes.length < 2) {
                      elm[k].remove()
                    }
                  }
                 
                  /******************************************* */
           
                  if (!content.hasChildNodes()) {
                    menu.classList.add("rounded-borders");
                  } else if (content.hasChildNodes()) {
                    menu.addEventListener('mouseover', () => {
                      content.style.display = 'block';
                      blockLevelButtons[0].style = 'background-image: none;background-repeat: no-repeat;background-position: 95% 50%;padding-right: 15px;width:' + maxWidthFlutter + 'px';
                    })
                    menu.addEventListener('mouseleave', () => {
                      content.style.display = 'none';
                      blockLevelButtons[0].style = 'background-image: url(' + imagesrc + ');background-repeat: no-repeat;background-position: 95% 50%;padding-right: 15px;width:' + maxWidthFlutter + 'px';
           
                    })
                  }
           
                }
                
              }
           
            /**********************ellipsis button code */
           
                  var ellipsis = document.createElement('div')
                  ellipsis.classList.add('ellipsis-button-menu')
                  let osviewidEllipsis = 'ellipsis_button_menu' ;
                  ellipsis.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+osviewidEllipsis)
                  /**********************ellipsis list  code */
                  var ellipsisIcon = document.createElement('span')
                  ellipsisIcon.classList.add('ellipsis-icon')
                  var iconimagesrc = APPUTILS.getImagePath('kabab-menu.svg', VIEWCONSTANTS.FES_IMAGE_DEFAULT_FOLDER)
                  var ellipsisImg = document.createElement('img')
                  ellipsisImg.classList.add('ellipsis-image')
                  ellipsisImg.setAttribute("src", iconimagesrc);
           
                  ellipsis.style = 'position:absolute; top:12px; right:0; cursor:pointer';
                  var ellipsisInner = document.createElement('div')
                  ellipsisInner.classList.add('ellipsis-inner-button-menu')
                  ellipsisInner.style = 'position:relative;';
                  // console.log(me);
           
                  /******************************************* */
                  /**********************ellipsis list  code */
                  var ellipsisList = document.createElement('div')
                  ellipsisList.classList.add('ellipsis-list')
           
                  /**********************new filter button  code */
                  var newFilter = document.createElement('a')
                  newFilter.classList.add('newFilter-list')
                  newFilter.innerHTML = "New Filter"
                  let osviewidnewFilter = 'newFilter_list' ;
                  newFilter.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+osviewidnewFilter)
                  /**********************saved filters  code */
                  var savedFilter = document.createElement('div')
                  savedFilter.classList.add('savedFilter-list')
                  savedFilter.innerHTML = 'Filter List'
                  let osviewidsavedFilter = 'savedFilter_list' ;
                  savedFilter.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+osviewidsavedFilter)
                  savedFilter.addEventListener('click', () => {
                      
                      dragonExtApp.getController('One_Many_Block').onClickListFilter(me);
                    //  store.clearFilter();
                  });
                  /**********************export button  code */
                  var exportbtn = document.createElement('a')
                  exportbtn.classList.add('exportbtn')
                  exportbtn.innerHTML = "Export"
                  let osviewidexportbtn = 'exportbtn' ;
                  exportbtn.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+osviewidexportbtn)
                  exportbtn.addEventListener('click', () => {
                    if (me.blockObj.datamart === true) {
           
                      // Export To Excel button if blockObj has listExportToExcel config	
                      if (Ext.isEmpty(me.blockObj.listExportToExcel) == false) {
                        // tbarItems.push({ xtype: 'tbseparator' });	
                        var dataIndexArr = [],
                          cellBvIdArr = [],
                          colParamArr = [],
                          cellFesArr = [],
                          cols = me.blockObj.grid.columns;
                        for (var cIdx in cols) {
                          if (!Ext.isEmpty(cols[cIdx].dataIndex)) {
                            dataIndexArr.push(cols[cIdx].dataIndex);
                            cellBvIdArr.push(cols[cIdx].cellBvId);
                            cellFesArr.push(cols[cIdx].fes);
                            colParamArr.push({
                              t: cols[cIdx].text,
                              d: cols[cIdx].dataIndex,
                              ldt:cols[cIdx].ldt
                            });
                          }
                        }
           
                      }
                    }
                    // Create form panel. It contains a basic form that we need for the file download.
                    g_OsLogger.info("Exporting data on 1M grid cell through DataSearchServlet API", this, {
                      methodName: '_createToolBar',
                      isDatamart: true,
                      objectId: me.blockObj.objectId,
                      id: me.blockObj.id,
                      listObjectId: me.blockObj.listObjectId,
                      label: me.blockObj.label,
                      apiURL: GFlags.os_app_ctx_url + '/' + 'DataSearchServlet',
                      submitMethod: 'POST'
                    });
           
                    var limitExceeded = false;
                    if (me.blockObj && me.blockObj.grid) {
                      var exportLimit = APPUTILS.uiHiddenParamsObject.MAX_EXPORT_ROW_COUNT;
                      if (!Ext.isEmpty(exportLimit) && exportLimit < me.currentTotalRows) {
                        limitExceeded = true;
                        var limitExceededMsg = APPUTILS.uiHiddenParamsObject.MAX_EXPORT_CAPACITY_EXCEEDED_ERROR_MSG;
                        if (Ext.isEmpty(limitExceededMsg)) {
                          limitExceededMsg = 'Too many rows for export!';
                        }
                        Ext.MessageBox.show({
                          title: Localize.processLocalStr('Excel Export'),
                          msg: Localize.processLocalStr(limitExceededMsg),
                          buttons: Ext.MessageBox.OK,
                          icon: Ext.MessageBox.ERROR
                        });
                      }
           
                    }
                    if (!limitExceeded) {
                      var form = Ext.create('Ext.form.Panel', {
                        standardSubmit: true,
                        url: GFlags.os_app_ctx_url + '/' + 'DataSearchServlet',
                        method: 'POST'
                      });
                      // Call the submit to begin the file download.
                      form.submit({
                        target: '_blank',
                        headers: {
                          'Accept': 'application/json'
                        },
                        params: {
                          USER_SESSION_GUID: Dragon.config.Runtime.getUserSessionGUID(),
                          transactionId: Dragon.config.Runtime.getTransactionId(),
                          blockId: me.blockObj.id,
                          listObjectId: me.blockObj.listObjectId,
                          actionId: Dragon.view.common.Functions.getActionId(),
                          listAction: '89',
                          dataIndices: dataIndexArr.join(','),
                          cellBvIds: cellBvIdArr.join(','),
                          cellFESs: cellFesArr.join(','),
                          gridColumns: Ext.encode(colParamArr),
                          'exportToExcel': true
                        }
                      });
                      // Clean-up the form after 100 milliseconds.
                      // Once the submit is called, the browser does not care anymore with the form object.
                      Ext.defer(function() {
                        form.close();
                      }, 100);
                    }
                  })
                  /**********************columns  code */
                  var columnsEllipsis = document.createElement('a')
                  columnsEllipsis.classList.add('columns-list')
                  columnsEllipsis.innerHTML = "Columns"
                  let osviewidcolumnsEllipsis = 'columns_list' ;
                  columnsEllipsis.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+osviewidcolumnsEllipsis)
                  columnsEllipsis.addEventListener('click', () => {
                    var savedColumnSelectList = [];
                    var savedColumnSelectList2 = [];
                    // columnHeaderName =  this.columns;
                    var dataIndexArray = [];
                    dataIndexArray = me.blockObj.grid.columns;
                    var modalFilterId = me.blockId;
                    var checkedValue = '';
                    var checkValue = '';
                    if (Ext.getCmp("columnSelectModal_" + modalFilterId) != null) {
                      selectedColumnValues = Ext.getCmp("columnSelectModal_" + modalFilterId).getValues();
                      localStorage.setItem("oneManyColumnSelect", JSON.stringify(savedColumnSelectList2));
                      Ext.getCmp("columnSelectModal_" + modalFilterId).destroy();
                    }
           
                    var columnSelectModal = new Ext.form.Panel({
                      width: 400,
                      height: 500,
                      title: 'Columns',
                      floating: true,
                      closable: true,
                      drggable: true,
                      resizable: true,
                      scrollable: true,
                      fullscreen: true,
                      remoteFilter: true,
                      id: "columnSelectModal_" + modalFilterId,
                      modal: true,
                      maskOnDisable: false,
                      cls: 'NewFilterModal',
                      addRow: function(rowLabel, dIndex, checkedValue) {
                        this.add({
                          xtype: 'checkboxgroup',
                          layout: 'hbox',
                          items: [{
                              boxLabel: rowLabel,
                              name: dIndex,
                              checked: checkedValue,
                              listeners: {
                                change: function() {
                                  if (localStorage.getItem('oneManyColumnSelect')) {
                                    savedColumnSelectList = localStorage.getItem('oneManyColumnSelect');
                                    savedColumnSelectList2 = JSON.parse(savedColumnSelectList)
                                  } else {
                                    savedColumnSelectList2 = Ext.getCmp("columnSelectModal_" + modalFilterId).getValues();
                                  }
                                  for (let i = 0; i < dataIndexArray.length; i++) {
                                    if (this.name == dataIndexArray[i].dataIndex && this.checked == false) {
                                      me.columns[i].setVisible(false);
                                      localStorage.setItem("oneManyColumnSelect", JSON.stringify(savedColumnSelectList2));
                                      let previousSelectedColumnValues = localStorage.getItem('oneManyColumnSelect');
                                      let previousSelectedColumnValues2 = JSON.parse(previousSelectedColumnValues)
           
                                      previousSelectedColumnValues2[this.name] = "off";
           
                                      localStorage.setItem("oneManyColumnSelect", JSON.stringify(previousSelectedColumnValues2));
                                    } else if (this.name == dataIndexArray[i].dataIndex && this.checked == true) {
                                      me.columns[i].setVisible(true);
                                      localStorage.setItem("oneManyColumnSelect", JSON.stringify(savedColumnSelectList2));
                                      let previousSelectedColumnValues = localStorage.getItem('oneManyColumnSelect');
                                      let previousSelectedColumnValues2 = JSON.parse(previousSelectedColumnValues)
           
                                      previousSelectedColumnValues2[this.name] = "on";
           
                                      localStorage.setItem("oneManyColumnSelect", JSON.stringify(previousSelectedColumnValues2));
                                    }
                                  }
           
           
                                }
                              }
                            },
           
                          ],
           
                        });
           
                      },
                      buttons: [{
                        text: 'Save Changes',
                        handler: function() {
                          columnSelectModal.destroy();
                        }
                      }]
           
                    });
                    columnSelectModal.show();
                    for (let i = 0; i < dataIndexArray.length; i++) {
                      checkedValue = true;
                      var previousSelectedColumnValues = localStorage.getItem('oneManyColumnSelect');
                      var previousSelectedColumnValues2 = JSON.parse(previousSelectedColumnValues)
                      if (!Ext.isEmpty(previousSelectedColumnValues2)) {
                        checkValue = previousSelectedColumnValues2[dataIndexArray[i].dataIndex];
                        if (checkValue == 'off') {
                          checkedValue = false;
                        } else {
                          checkedValue = true;
                        }
                      }
                      columnSelectModal.addRow(dataIndexArray[i].text, dataIndexArray[i].dataIndex, checkedValue);
                    }
           
                  })
           
                  var savedFilterList = document.createElement('div')
                  savedFilterList.classList.add('savedFilter-cont')
                  // savedFilterList.innerHTML = "<a class='pers-filter-lookup-text' onclick='javascript:Ext.getCmp(\''+ this.getId() +'\').up(\'osPersonalizedFilterList\').fireEvent(\'pers-filter-item-select\',' +filterPars  +');>{view_name}' +'</a>";
           
           
                  ellipsisList.appendChild(newFilter);
                  ellipsisList.appendChild(savedFilter);
                  ellipsisList.appendChild(exportbtn);
                  ellipsisList.appendChild(columnsEllipsis);
                  ellipsisList.appendChild(savedFilterList)
                  ellipsisList.style = 'position:absolute; top:-40px;width:140px; right:40px; cursor:pointer';
                  ellipsis.appendChild(ellipsisIcon)
                  ellipsisIcon.appendChild(ellipsisImg)
                  ellipsis.appendChild(ellipsisInner)
                  ellipsisInner.appendChild(ellipsisList)
                  // for(i=0; i<titleBlock.length; i++){
                  // titleBlock[i].appendChild(ellipsis) 
                  // }
                  var titleBlock = myblock.getElementsByClassName('x-panel-header')
                  if(titleBlock.length>0){
                  titleBlock[0].appendChild(ellipsis)
                  }
                  ellipsis.addEventListener('click', () => {
                    ellipsisList.classList.toggle("showEllipsisList");
                  //   console.log(this)
                  })
                  window.addEventListener('click', function(e){   
                    if (ellipsis.contains(e.target)){
                      // Clicked in box
                      ellipsisList.classList.add("showEllipsisList");
                    } else{
                      // Clicked outside the box
                      ellipsisList.classList.remove("showEllipsisList");
                    }
                  });
                  

                  var savedFilterLink = document.createElement('div');
                  savedFilterLink.classList.add('savedFilter-link');
                  if (allSavedFilters.length > 0) {
                    for (let i = 0; i < allSavedFilters.length; i++) {
                      var savedFilterLink = document.createElement('div');
                      savedFilterLink.classList.add('savedFilter-link');
                      savedFilterLink.innerHTML = allSavedFilters[i];
                      savedFilterList.appendChild(savedFilterLink);
           
                      savedFilterLink.addEventListener('click', (e) => {
           
                        currSavedFilter = e.currentTarget.innerHTML
                        var pickedLocalFilter = localStorage.getItem(currSavedFilter);
                        var pickedLocalFilter2 = JSON.parse(pickedLocalFilter);
                        var columnHeaderName = [];
                        columnHeaderName = me.columns;
                        var dataIndexArray = [];
                        dataIndexArray = me.blockObj.grid.columns;
                        var modalFilterId = me.blockId;
           
                        var newSavedFilterModal = new Ext.form.Panel({
                          width: 500,
                          height: 500,
                          title: currSavedFilter,
                          floating: true,
                          closable: true,
                          drggable: true,
                          resizable: true,
                          scrollable: true,
                          fullscreen: true,
                          remoteFilter: true,
                          id: "newSavedFilterModal_" + modalFilterId + "_filtersetname_" + savedFilterValue,
                          modal: true,
                          maskOnDisable: false,
                          cls: 'NewFilterModal',
                          addRow: function(rowLabel, dIndex, textValue, fieldType) {
                            this.add({
                              xtype: 'fieldcontainer',
                              fieldLabel: rowLabel,
                              labelWidth: 130,
                              layout: 'hbox',
                              items: [{
                                xtype: fieldType,
                                dataIndex: dIndex,
                                name: dIndex,
                                value: textValue,
                                triggers: {
                                  clearText: {
                                    cls: 'clear-text-trigger-icon',
                                    handler: function() {
                                      this.setValue('');
                                    }
                                  }
                                },
                                listeners: {
                                  load: function(textField) {
           
                                    if (textField.getValue()) {
                                      // console.log(textField.getValue())
                                      textField.setHideTrigger(false);
                                      textField.cls('osnonempty')
                                    }
                                  },
                                  change: function(textField) {
                                    if (textField.getValue()) {
                                      // console.log(textField.getValue())
                                      textField.setHideTrigger(false);
                                    } else {
                                      textField.setValue('');
                                      textField.setHideTrigger(false);
                                    }
                                  }
                                }
           
                              }],
                              clearIcon: true,
                            });
           
                          },
                          buttons: [{
                              text: 'Delete Filter',
                              cls: 'secondaryBtn',
                              handler: function() {
                                localStorage.removeItem(currSavedFilter);
                                var index = allSavedFilters.indexOf(currSavedFilter);
                                allSavedFilters.splice(index, 1);
                                localStorage.setItem('allSavedFilters', JSON.stringify(allSavedFilters));
                                var allSavedFilterLink = document.getElementsByClassName("savedFilter-link");
                                for (let j = 0; j < allSavedFilterLink.length; j++) {
                                  if (allSavedFilterLink[j].innerHTML == currSavedFilter) {
                                    allSavedFilterLink[j].innerHTML = "";
                                  }
                                }
           
                                newSavedFilterModal.hide();
                              }
                            },
                            {
                              text: 'Update Filter',
                              cls: 'secondaryBtn',
                              handler: function() {
                                pickedLocalFilter2 = Ext.getCmp("newSavedFilterModal_" + modalFilterId + "_filtersetname_" + savedFilterValue).getValues();
                                localStorage.setItem(currSavedFilter, JSON.stringify(pickedLocalFilter2));
                                newSavedFilterModal.destroy();
                              }
                            },
                            {
                              text: 'Apply Filters',
                              handler: function() {
           
                                Object.keys(pickedLocalFilter2).forEach(key => {
                                  var filter = {
                                    id: key,
                                    property: key,
                                    value: pickedLocalFilter2[key]
                                  };
                                  filter.anyMatch = true;
                                  filter.disableOnEmpty = true;
                                  filter.comparison = "like";
                                  filter.type = "string";
                                  store.addFilter(filter);
                                });
                                if (Ext.getCmp("newSavedFilterModal_" + modalFilterId + "_filtersetname_" + savedFilterValue) != null) {
                                  previousFilteredValues = Ext.getCmp("newSavedFilterModal_" + modalFilterId + "_filtersetname_" + savedFilterValue).getValues();
                                  localStorage.setItem(currSavedFilter, JSON.stringify(previousFilteredValues));
                                  Ext.getCmp("newSavedFilterModal_" + modalFilterId + "_filtersetname_" + savedFilterValue).destroy();
                                }
                                newSavedFilterModal.hide();
           
                              }
                            }
                          ]
           
                        });
                        newSavedFilterModal.show();
                        for (let i = 0; i < dataIndexArray.length; i++) {
                          var textValue = '';
                          var textFields = "textfield";
                          var dateFields = "datefield";
                          var retrievedObject = localStorage.getItem(currSavedFilter);
                          var retrievedObject2 = JSON.parse(retrievedObject)
                          if (!Ext.isEmpty(retrievedObject2)) {
                            textValue = retrievedObject2[dataIndexArray[i].dataIndex];
                          }
                          if (!Ext.isEmpty(dataIndexArray[i].text) && columnHeaderName[i].filter.type === "string") {
                            newSavedFilterModal.addRow(dataIndexArray[i].text, dataIndexArray[i].dataIndex, textValue, textFields);
                          } else if (!Ext.isEmpty(dataIndexArray[i].text) && columnHeaderName[i].filter.type === "date") {
                            newSavedFilterModal.addRow(dataIndexArray[i].text, dataIndexArray[i].dataIndex, textValue, dateFields);
                          }
                        }
                        retrievedObject2 = null;
                      })
           
                    }
                  }
           
                  var previousFilteredValues = null;
                  /******************Creates New Filter Modal Window************************* */
                    
                  newFilter.addEventListener('click', () => {
                    var me = this;     
                    var columnHeaderName = [];
                    columnHeaderName = this.columns;
                    var dataIndexArray = [];
                    dataIndexArray = me.blockObj.grid.columns;
                    var modalFilterId = me.blockId;
                    if (Ext.getCmp("filterModalWindow_" + modalFilterId) != null) {
                      previousFilteredValues = Ext.getCmp("filterModalWindow_" + modalFilterId).getValues();
                      localStorage.setItem("oneManyNewFilter", JSON.stringify(previousFilteredValues));
                      Ext.getCmp("filterModalWindow_" + modalFilterId).destroy();
                    }
           
           
                    var newFilterModal = Ext.create({
                      xtype : 'newfiltermodal',
                      modalFilterId : modalFilterId,
                     parGrid : me,
                    });
                    
                    newFilterModal.show();
            
                  });

                  

      })

      me.callParent(arguments);


      /* On Data change hide and show prev/next/first/last buttons and calculate the page number*/
      var store = me.store;

      store.on('datachanged', (store) => {
        this.checkFilter();
        this.applyIconClassToGridRowButtons();
        this.addFilterBubbles();
        if (store.os_gridRef && store.os_gridRef.blockObj && store.os_gridRef.blockObj.datamart === true && store.getProxy() && store.getProxy().getReader() && store.getProxy().getReader().rawData) {
            var jResp = store.getProxy().getReader().rawData;
            var totalRowsCalc = jResp.totalRows;
            var currRow = jResp.endRow;
            var pageCount = Math.ceil(totalRowsCalc / store.data.length);
            var currRowCalc = Math.ceil(currRow / store.data.length);
            if(jResp.startRow == 1){
              currRowCalc = 1;
            }
            if(isNaN(pageCount)){
              pageCount = 0;
            }
            if(isNaN(currRowCalc)){
              currRowCalc = 0;
            }
            var numOfPagination = Ext.ComponentQuery.query("#next");
            var totalRowNumNew = document.getElementsByClassName('totalRowsCalc');
            var nextBtn = me.el.dom.getElementsByClassName('x-one-many-block-next-toolbar-btn');
            var prevBtn = me.el.dom.getElementsByClassName('x-one-many-block-prev-toolbar-btn');
            var firstBtn = me.el.dom.getElementsByClassName('x-one-many-block-first-toolbar-btn');
            var lastBtn = me.el.dom.getElementsByClassName('x-one-many-block-last-toolbar-btn');
          
           
            if(numOfPagination.length>0){
               if(nextBtn.length>0 && lastBtn.length>0 && firstBtn.length>0 && prevBtn.length>0){
                if (currRow == totalRowsCalc && totalRowsCalc == "1" || (currRow==0 && totalRowsCalc==0 && pageCount==0)) {
                    nextBtn[0].style.pointerEvents="none";
                    lastBtn[0].style.pointerEvents="none";
                    firstBtn[0].style.pointerEvents="none";
                    prevBtn[0].style.pointerEvents="none";

                    nextBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";
                    lastBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";
                    firstBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";
                    prevBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";
                } else if (currRowCalc == "1" && pageCount == "1") {
                  nextBtn[0].style.pointerEvents="none";
                  lastBtn[0].style.pointerEvents="none";
                  firstBtn[0].style.pointerEvents="none";
                  prevBtn[0].style.pointerEvents="none";

                  nextBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";
                  lastBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";
                  firstBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";
                  prevBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";

              } else if ((currRowCalc == "0" && totalRowsCalc == "0")||(currRow == "1" && totalRowsCalc == "1")) {
                  nextBtn[0].style.pointerEvents="auto";
                  lastBtn[0].style.pointerEvents="auto";
                  firstBtn[0].style.pointerEvents="none";
                  prevBtn[0].style.pointerEvents="none";

                  nextBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#4d525a";
                  lastBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#4d525a";
                  firstBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";
                  prevBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";

              } else if (currRowCalc == totalRowsCalc || currRow == totalRowsCalc) {
                    currRowCalc = pageCount;
                    nextBtn[0].style.pointerEvents="none";
                    lastBtn[0].style.pointerEvents="none";
                    firstBtn[0].style.pointerEvents="auto";
                    prevBtn[0].style.pointerEvents="auto";

                    nextBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";
                    lastBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";
                    firstBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#4d525a";
                    prevBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#4d525a";

                } else if (currRowCalc == "1") {
                    nextBtn[0].style.pointerEvents="auto";
                    lastBtn[0].style.pointerEvents="auto";
                    firstBtn[0].style.pointerEvents="none";
                    prevBtn[0].style.pointerEvents="none";

                    nextBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#4d525a";
                    lastBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#4d525a";
                    firstBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";
                    prevBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#eee";

                }  else {
                    nextBtn[0].style.pointerEvents="auto";
                    lastBtn[0].style.pointerEvents="auto";
                    firstBtn[0].style.pointerEvents="auto";
                    prevBtn[0].style.pointerEvents="auto";

                    nextBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#4d525a";
                    lastBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#4d525a";
                    firstBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#4d525a";
                    prevBtn[0].getElementsByClassName('x-btn-inner-default-toolbar-small')[0].style.color ="#4d525a";

                }
          
                document.getElementsByClassName('currentRowNum' + "_" + me.blockObj.id)[0].innerHTML = currRowCalc;
                document.getElementsByClassName('totalRowNum' + "_" + me.blockObj.id)[0].innerHTML = pageCount;
              }
                        
            }
            // document.getElementsByClassName('totalRowsCalc').innerHTML ="totalRowsCalc"
            if (!Ext.isEmpty(me.parBlock.title)) {
                if (me.blockTitle) {
                    me.parBlock.title = me.blockTitle + ' ' + '<span>' + totalRowsCalc + '</span>';
                }
                me.setTitle(me.parBlock.title);
            }
        }

    })
  },
  applyIconClassToGridRowButtons: function() {
      lastColumn = this.blockObj.grid.columns.slice(-1)[0],
          rowLevelButtons = lastColumn.rowButtons;
      element = document.getElementsByClassName('x-grid-cell-btn-row-column')
      if (rowLevelButtons) {
          for (let i = 0; i < element.length; i++) {
              element2 = element[i].getElementsByTagName('button')
              for (let j = 0; j < rowLevelButtons.length; j++) {
                  if (element2[j]) {
                      if (element2[j].firstChild.innerHTML.toLowerCase() == "edit") {
                          element2[j].classList.add('EditGridIcon');
                          element2[j].setAttribute('data-qtip',rowLevelButtons[j].helpText);
                      } else if (element2[j].firstChild.innerHTML.toLowerCase() == "add") {
                          element2[j].classList.add('AddGridIcon');
                          element2[j].setAttribute('data-qtip',rowLevelButtons[j].helpText);
                      } else if (element2[j].firstChild.innerHTML.toLowerCase() == "delete" || element2[j].firstChild.innerHTML.toLowerCase() == "remove") {
                          element2[j].classList.add('DeleteGridIcon');
                          element2[j].setAttribute('data-qtip',rowLevelButtons[j].helpText);
                      } else if (element2[j].firstChild.innerHTML.toLowerCase() == "download") {
                          element2[j].classList.add('DownloadGridIcon');
                          element2[j].setAttribute('data-qtip',rowLevelButtons[j].helpText);
                      } else if (element2[j].firstChild.innerHTML.toLowerCase() == "view") {
                          element2[j].classList.add('ViewGridIcon');
                          element2[j].setAttribute('data-qtip',rowLevelButtons[j].helpText);
                      } else if (element2[j].firstChild.innerHTML.toLowerCase() == "select") {
                          element2[j].classList.add('SelectGridIcon');
                          element2[j].setAttribute('data-qtip',rowLevelButtons[j].helpText);
                      } else if (element2[j].firstChild.innerHTML.toLowerCase() == "mark as complete") {
                        // element2[j].classList.add('SelectGridIcon');
                        element2[j].setAttribute('data-qtip',rowLevelButtons[j].helpText);
                    } else if (element2[j].firstChild.innerHTML.toLowerCase() == "go to file") {
                      // element2[j].classList.add('SelectGridIcon');
                      element2[j].setAttribute('data-qtip',rowLevelButtons[j].helpText);
                  }
                      
                  }
              }
          }
      }
  },
  checkFilter: function(store) {
      if (!this.store.isFiltered()) {
          localStorage.removeItem("oneManyNewFilter");
      }
  },
  addFilterBubbles: function(store) {
      // console.log(window.currSavedFilter);
      let osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
          (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]) + 
          VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.OBJECT_TYPE + VIEWCONSTANTS.UNDERSCORE + this.blockObj.objectTypeId + 
          VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.BLOCK_ID + VIEWCONSTANTS.UNDERSCORE + this.blockObj.id + VIEWCONSTANTS.UNDERSCORE +
          VIEWCONSTANTS.GRID;
      if (this.store.isFiltered()) {
        var filterItems = [];
        var retrievedObject = {};
        var toDate;
        var fromDate;
        const toDateee = JSON.parse(localStorage.getItem('oneManyNewFilter'));
        var dataIndexToDate;
        var dataIndexFromDate;
        function isMMDDYYYYFormat(dateString) {
          // Regular expression pattern for MM/DD/YYYY format
          const pattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/\d{4}$/;
          return pattern.test(dateString);
      }
        if(this.store.filters){
          /*OSPRODUCT-34763*/
          if(this.store.filters.items.length>this.columnFilters.length){
            filterItems = JSON.parse(localStorage.getItem('newfilterFromList'));
            if (filterItems.length > 0) {
              const fieldToObject = {}; // Map fields to their respective objects
              let fromDate, toDate;
            
              for (let i = 0; i < filterItems.length; i++) {
                const item = filterItems[i];
                const { field, type, value, comparison } = item;
            
                if (!field || !value) continue; // Skip empty fields or values
            
                if (type === "date") {
                  if (comparison === "lt") {
                    toDate = value;
                  } else if (comparison === "gt") {
                    fromDate = value;
                  } else if (comparison === "eq") {
                    retrievedObject[field] = `On: ${value}`;
                  }
                } else {
                  // Handle non-date type entries...
                  retrievedObject[field] = value;
                }
            
                // Map fields to their respective objects
                if (!fieldToObject[field]) {
                  fieldToObject[field] = [];
                }
                fieldToObject[field].push(item);
              }
            
              for (const field in fieldToObject) {
                const fieldItems = fieldToObject[field];
            
                if (fieldItems.length === 2) {
                  const gtItem = fieldItems.find(item => item.comparison === "gt");
                  const ltItem = fieldItems.find(item => item.comparison === "lt");
            
                  if (gtItem && ltItem) {
                    retrievedObject[field] = `Between: ${fromDate} - ${toDate}`;
                  }
                } else if (fieldItems.length === 1) {
                  if (fieldItems[0].comparison === "lt") {
                    retrievedObject[field] = `Before: ${toDate}`;
                  } else if (fieldItems[0].comparison === "gt") {
                    retrievedObject[field] = `After: ${fromDate}`;
                  }
                }
              }
            }
            
           
            
          }
          /**/
          else{
            filterItems = this.store.filters.items;
            if(filterItems.length>0){
              for (let i = 0; i < filterItems.length; i++) {
                if (!Ext.isEmpty(filterItems[i]._property) && filterItems[i].type == "date" && !Ext.isEmpty(filterItems[i]._value)) {
                    if ( (filterItems[i].comparison == "lt" || filterItems[i]._operator == "lt" || 
                    filterItems[i].comparison == "gt" || filterItems[i]._operator == "gt")) {
                            if ( filterItems[i].comparison == "lt" || filterItems[i]._operator == "lt") {
                                if (isMMDDYYYYFormat(filterItems[i]._value) === false) {
                                  toDate = filterItems[i]._value.toLocaleDateString();
                                  dataIndexToDate= filterItems[i]._property;
                                }
                                else if(filterItems[i]._value === undefined && !Ext.isEmpty(toDateee)){
                                  if (toDateee) {
                                      toDate = toDateee[filterItems[i]._property][2];
                                      dataIndexToDate = filterItems[i]._property;
                                  }
                                } 
                                else {
                                    toDate = filterItems[i]._value;
                                    dataIndexToDate = filterItems[i]._property;
                                }      
                            }
                            else if(filterItems[i].comparison == "gt" || filterItems[i]._operator == "gt"){
                                if (isMMDDYYYYFormat(filterItems[i]._value) === false) {
                                  fromDate = filterItems[i]._value.toLocaleDateString();
                                  dataIndexFromDate = filterItems[i]._property;
                              } else {
                                  fromDate = filterItems[i]._value;
                                  dataIndexFromDate = filterItems[i]._property;
                              }
                            }
                            if(fromDate == undefined && toDate == undefined){
                              if (isMMDDYYYYFormat(filterItems[i]._value) === false) {
                                filterItems[i]._value = filterItems[i]._value.toLocaleDateString();
                              }
                              retrievedObject[filterItems[i]._property] ="On: " + filterItems[i]._value;
                            }
                            if(toDate === undefined && !Ext.isEmpty(toDateee) && toDateee[filterItems[i]._property][0] == "Between"){
                              if (toDateee) {
                                  toDate = toDateee[filterItems[i]._property][2];
                                  dataIndexToDate = filterItems[i]._property;
                                  if(!Ext.isEmpty(toDate) && !Ext.isEmpty(fromDate) && dataIndexToDate == dataIndexFromDate ){
                                    retrievedObject[filterItems[i]._property] = "Between: " + fromDate+"-"+toDate;
                                  }
                              }
                            } 
                            else if(fromDate==undefined && !Ext.isEmpty(toDate)){
                              for(let k=0;k<filterItems.length;k++){
                                if(filterItems[i]._property == filterItems[k]._property && filterItems[k]._operator == "gt" && filterItems[k]._value){
                                  if (isMMDDYYYYFormat(filterItems[k]._value) === false) {
                                    fromDate = filterItems[k]._value.toLocaleDateString();
                                    if(!Ext.isEmpty(toDate) && !Ext.isEmpty(fromDate)){
                                      retrievedObject[filterItems[i]._property] = "Between: " + fromDate+"-"+toDate;
                                    }
                                  }
                                }
                              }
                              if(fromDate==undefined && !Ext.isEmpty(toDate)){
                              retrievedObject[filterItems[i]._property] = "Before: " + toDate;
                              }
                            }
                            else if(toDate==undefined && !Ext.isEmpty(fromDate)){
                              for(let k=0;k<filterItems.length;k++){
                                if(filterItems[i]._property == filterItems[k]._property && filterItems[k]._operator == "lt" && filterItems[k]._value){
                                  if (isMMDDYYYYFormat(filterItems[k]._value) === false) {
                                    toDate = filterItems[k]._value.toLocaleDateString();
                                    if(!Ext.isEmpty(toDate) && !Ext.isEmpty(fromDate)){
                                      retrievedObject[filterItems[i]._property] = "Between: " + fromDate+"-"+toDate;
                                    }
                                  }
                                }
                              }
                              if(toDate==undefined && !Ext.isEmpty(fromDate)){
                                retrievedObject[filterItems[i]._property] = "After: " + fromDate;
                              }
                             
                            }
                            else if(!Ext.isEmpty(toDate) && !Ext.isEmpty(fromDate) && dataIndexToDate == dataIndexFromDate ){
                              retrievedObject[filterItems[i]._property] ="Between: " + fromDate+"-"+toDate;
                            }
                            else if(!Ext.isEmpty(toDate) && !Ext.isEmpty(fromDate) && dataIndexToDate != dataIndexFromDate){
                              retrievedObject[dataIndexToDate] = "Before: " + toDate;
                              retrievedObject[dataIndexFromDate] = "After: " + fromDate;
                            }
                            fromDate = undefined;
                            toDate = undefined;
                 
                    }
                    else if(filterItems[i].comparison == "eq" || filterItems[i]._operator == "eq"){
                      if (isMMDDYYYYFormat(filterItems[i]._value) === false) {
                        const currentDate = new Date();
                        filterItems[i]._value = currentDate.toLocaleDateString();
                      }
                      retrievedObject[filterItems[i]._property] = "On: " + filterItems[i]._value;
                    } else {
                        retrievedObject[filterItems[i]._property] = filterItems[i]._value;
                    }
                }
                else if(!Ext.isEmpty(filterItems[i]._property) && !Ext.isEmpty(filterItems[i]._value) && filterItems[i].type != "date") {
                  if(Ext.isArray(filterItems[i]._value) && filterItems[i]._value.length>1 && filterItems[i]._value[1] != ""){
                    // retrievedObject[filterItems[i]._property] = filterItems[i]._value[1];
                    if(filterItems[i]._value[0] == "=" || filterItems[i]._value[0] == "eq"){
                      filterItems[i].comparison = "eq";
                      retrievedObject[filterItems[i]._property] = "EQ: " + filterItems[i]._value[1];
                    }
                    else if(filterItems[i]._value[0] == ">=" || filterItems[i]._value[0] == "geq"){
                      filterItems[i].comparison = "geq";
                      retrievedObject[filterItems[i]._property] = "GEQ: " + filterItems[i]._value[1];
                    }
                    else if(filterItems[i]._value[0] == ">" || filterItems[i]._value[0] == "gt"){
                      filterItems[i].comparison = "gt";
                      retrievedObject[filterItems[i]._property] = "GT: " + filterItems[i]._value[1];
                    }
                    else if(filterItems[i]._value[0] == "<=" || filterItems[i]._value[0] == "leq"){
                      filterItems[i].comparison = "leq";
                      retrievedObject[filterItems[i]._property] = "LEQ: " + filterItems[i]._value[1];
                    }
                    else if(filterItems[i]._value[0] == "<" || filterItems[i]._value[0] == "lt"){
                      filterItems[i].comparison = "lt";
                      retrievedObject[filterItems[i]._property] = "LT: " + filterItems[i]._value[1];
                    }
                    else if(filterItems[i]._value[0] == "!=" || filterItems[i]._value[0] == "neq"){
                      filterItems[i].comparison = "neq";
                      retrievedObject[filterItems[i]._property] = "NEQ: " + filterItems[i]._value[1];
                    }
                  }
                  else if(!Ext.isArray(filterItems[i]._value) && filterItems[i].type == "number"){
                    // retrievedObject[filterItems[i]._property] = filterItems[i]._value[1];
                    if (typeof filterItems[i]._value === "number") {
                      filterItems[i]._value = filterItems[i]._value.toString();
                    }
                    if(filterItems[i].comparison == "eq" || filterItems[i]._operator == "eq"){
                      retrievedObject[filterItems[i]._property] = "EQ: " + filterItems[i]._value;
                    }
                    else if(filterItems[i].comparison == "geq" || filterItems[i]._operator == "geq"){
                      retrievedObject[filterItems[i]._property] = "GEQ: " + filterItems[i]._value;
                    }
                    else if(filterItems[i].comparison == "gt" || filterItems[i]._operator == "gt"){
                      retrievedObject[filterItems[i]._property] = "GT: " + filterItems[i]._value;
                    }
                    else if(filterItems[i].comparison == "leq" || filterItems[i]._operator == "leq"){
                      retrievedObject[filterItems[i]._property] = "LEQ: " + filterItems[i]._value;
                    }
                    else if(filterItems[i].comparison == "lt" || filterItems[i]._operator == "lt"){
                      retrievedObject[filterItems[i]._property] = "LT: " + filterItems[i]._value;
                    }
                    else if(filterItems[i].comparison == "neq" || filterItems[i]._operator == "neq"){
                      retrievedObject[filterItems[i]._property] = "NEQ: " + filterItems[i]._value;
                    }
                  }
                  else if(!Ext.isArray(filterItems[i]._value)){
                    retrievedObject[filterItems[i]._property] = filterItems[i]._value;
                  }
                  
              }
              }
            }
          }
          // filterItems = this.store.filters.items;
          
        }
        
          var retrievedObject2 = retrievedObject
          var panel = document.getElementById(this.id+"_header-title");
          var dataIndexArray = [];
       
          dataIndexArray = this.blockObj.grid.columns;
          if(panel && panel.childNodes.length>1){
            var prevFilterBubbleCont = panel.getElementsByClassName("filterBubbleContainer");
            //    console.log(prevFilterBubbleCont)
            if (prevFilterBubbleCont[0] && prevFilterBubbleCont[0].parentNode) {
                prevFilterBubbleCont[0].parentNode.removeChild(prevFilterBubbleCont[0])
            }
          }
          var filterBubbleCont = document.createElement('div')
          filterBubbleCont.classList.add('filterBubbleContainer')
          filterBubbleCont.setAttribute("id", "filterBubbleRow");
          filterBubbleCont.style = 'padding: 10px';

          for (let i = 0; i < dataIndexArray.length; i++) {
              var title = dataIndexArray[i].text;
              var value = null;
              if (!Ext.isEmpty(retrievedObject2)) {
                  value = retrievedObject2[dataIndexArray[i].dataIndex];
              }
              var filterBubbleClose = document.createElement('button')
              filterBubbleClose.classList.add('filterBubbleClose')
              filterBubbleClose.dataIndex = dataIndexArray[i].dataIndex;
              filterBubbleClose.innerHTML = "x"

              if (!Ext.isEmpty(value) && !Ext.isEmpty(panel)) {
                  panel.appendChild(filterBubbleCont);
                  // panel.getEl.classList.add\

                  // this.getHeader().setHeight(100);
                  var filterBubble = document.createElement('span')
                  filterBubble.classList.add('filterBubble')
                  filterBubble.className = 'filterBubble';
                  if(typeof value.getMonth === 'function'){
                    value = value.toLocaleDateString();
                  }
                  filterBubble.innerHTML = title + ": " + value
                  filterBubble.appendChild(filterBubbleClose)

                  if (Ext.isEmpty(filterBubbleCont)) {
                      filterBubbleCont.appendChild(filterBubble)
                  } else {
                      filterBubbleCont.appendChild(filterBubble)
                      filterBubbleCont.style = "display:table-row;"
                  }
              }


              filterBubbleClose.addEventListener('click', (e) => {
                if(e.currentTarget.parentNode){
                  e.currentTarget.parentNode.style.display = 'none';
                }
                  var filterStrIndex = e.srcElement.dataIndex;
                  // currentBubbleIndex = this.blockObj.grid.columns.findIndex((entry)=>entry.dataIndex==filterStrIndex);
                  this.store.removeFilter(filterStrIndex)
                  this.store.applyFilters();              
                  retrievedObject2[filterStrIndex] = "";
                  this.store.clearFilter();
                  Object.keys(retrievedObject2).forEach(key => {
                    let storedComp;
                    let storedType;
                    if (retrievedObject2[key].includes("On:")) {
                      storedComp = "eq";
                      storedType = "date";
                      retrievedObject2[key] = retrievedObject2[key].replace(/On:/g, "").replace(/\s+/g, '');
                    }
                    else if (retrievedObject2[key].includes("Before:")) {
                      storedComp = "lt";
                      storedType = "date";
                      retrievedObject2[key] = retrievedObject2[key].replace(/Before:/g, "").replace(/\s+/g, '');
                    }
                    else if (retrievedObject2[key].includes("After:")) {
                      storedComp= "gt";
                      storedType = "date";
                      retrievedObject2[key] = retrievedObject2[key].replace(/After:/g, "").replace(/\s+/g, '');
                    }
                    else if (retrievedObject2[key].includes("Between:")) {
                      storedComp= "gtlt";
                      storedType = "date";
                      retrievedObject2[key] = retrievedObject2[key].replace(/Between:/g, "").replace(/\s+/g, '');
                    }
                    else if (retrievedObject2[key].includes("GT:")) {
                      storedComp= "gt";
                      storedType = "number";
                      retrievedObject2[key] = retrievedObject2[key].replace(/GT:/g, "").replace(/\s+/g, '');
                    }
                    else if (retrievedObject2[key].includes("LT:")) {
                      storedComp= "lt";
                      storedType = "number";
                      retrievedObject2[key] = retrievedObject2[key].replace(/LT:/g, "").replace(/\s+/g, '');
                    }
                    else if (retrievedObject2[key].includes("NEQ:")) {
                      storedComp= "neq";
                      storedType = "number";
                      retrievedObject2[key] = retrievedObject2[key].replace(/NEQ:/g, "").replace(/\s+/g, '');
                    }
                    else if (retrievedObject2[key].includes("LEQ:")) {
                      storedComp= "leq";
                      storedType = "number";
                      retrievedObject2[key] = retrievedObject2[key].replace(/LEQ:/g, "").replace(/\s+/g, '');
                    }
                    else if (retrievedObject2[key].includes("GEQ:")) {
                      storedComp= "geq";
                      storedType = "number";
                      retrievedObject2[key] = retrievedObject2[key].replace(/GEQ:/g, "").replace(/\s+/g, '');
                    }
                    else if (retrievedObject2[key].includes("EQ:")) {
                      storedComp= "eq";
                      storedType = "number";
                      retrievedObject2[key] = retrievedObject2[key].replace(/EQ:/g, "").replace(/\s+/g, '');
                    }
                    if(storedComp=="gtlt"){
                      var dateArray = retrievedObject2[key].split('-');
                      var startDate = dateArray[0];
                      var endDate = dateArray[1];
                      var filter = {
                          id: key,
                          property: key,
                          value: startDate
                      };
                      filter.comparison = "gt";
                      filter.type = "date";
                      // this.store.addFilter(filter);
                      var filter2 = {
                        id: key,
                        property: key,
                        value: endDate
                      };
                      filter2.comparison = "lt";
                      filter2.type = "date";
                      this.store.addFilter(filter,filter2);
                    }
                    else{
                      var filter = {
                          id: key,
                          property: key,
                          value: retrievedObject2[key]
                      };
                    
                      filter.anyMatch = true;
                      filter.disableOnEmpty = true;
                      if (storedComp == "eq" && storedType== "date") {
                        filter.comparison = "eq";
                      filter.type = "date";
                      }
                      else if (storedComp == "lt" && storedType== "date") {
                        filter.comparison = "lt";
                      filter.type = "date";
                      }
                      else if (storedComp == "gt" && storedType== "date") {
                        filter.comparison = "gt";
                      filter.type = "date";
                      }
                      else if (storedComp == "eq" && storedType== "number") {
                        filter.comparison = "eq";
                      filter.type = "number";
                      }
                      else if (storedComp == "gt" && storedType== "number") {
                        filter.comparison = "gt";
                      filter.type = "number";
                      }
                      else if (storedComp == "lt" && storedType== "number") {
                        filter.comparison = "lt";
                      filter.type = "number";
                      }
                      else if (storedComp == "neq" && storedType== "number") {
                        filter.comparison = "neq";
                      filter.type = "number";
                      }
                      else if (storedComp == "leq" && storedType== "number") {
                        filter.comparison = "leq";
                      filter.type = "number";
                      }
                      else if (storedComp == "geq" && storedType== "number") {
                        filter.comparison = "geq";
                      filter.type = "number";
                      }
                      else{
                        filter.comparison = "like";
                        filter.type = "string";
                      }
                      
                      this.store.addFilter(filter);
                    }

                  });

              })
          }
          var clearAllBubble = document.createElement('span')
          clearAllBubble.classList.add('clearAllBubble')
          clearAllBubble.innerHTML = "Clear All Filters"
          filterBubbleCont.appendChild(clearAllBubble)
          let osviewidclearAllBubble = 'clearAllBubble' ;
          clearAllBubble.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+osviewidclearAllBubble)

          clearAllBubble.addEventListener('click', (e) => {
              e.currentTarget.parentNode.style.display = 'none'
              panel.removeChild(filterBubbleCont);
              this.store.clearFilter();
              /*updated*/
              var gridFilterBv, gridFilterBvField;
              this.filters.autoReload = false;
              this.filters.clearColumnHeadings();
              var cols = this.columnManager.getColumns();
              for (var i = 0; i < cols.length; i++) {
                  if (cols[i].filter) {
                      if (cols[i].filter.filter._value) {
                          cols[i].filter.filter.setValue();
                      }
                  }
              }
      
              this.getStore().load({
                  params: {
                      'listAction': '99',
                      'multiSortString': ''
      
                  }
              });
      
              this.filters.autoReload = true;
          
          })
      } else {
          this.store.clearFilter();
  
      }
  },
  applyParBlockTitle: function() {
      var me = this;

      if (!Ext.isEmpty(me.parBlock.title)) {

          me.parBlock.title =
              me.parBlock.title +
              ' ' + '<span class="totalRowsCalc">' + me.blockObj.grid.totalRows + '</span>'
          // me.parBlock.blockObj.blockLevelButtons[0];
          g_OsLogger.debug("Applying the title for grid", this, {
              methodName: 'applyParBlockTitle',
              objectId: me.blockObj.objectId,
              id: me.blockObj.id,
              label: me.blockObj.label,
              title: me.parBlock.title
          });

      }
      this.setTitle(me.parBlock.title);


  },
  _createToolBar: function() {
      var gridStore = this.getStore()
      var totalRowsCalc = this.blockObj.grid.totalRows;
      var currRow = this.blockObj.grid.endRow;
      var me = this,
          tbarItems = [],
          hasPaginationBtns = Ext.isEmpty(me.blockObj.listNavFirst) == false;
      var pageCount = Math.ceil(totalRowsCalc / gridStore.pageSize);
      var currRowCalc = Math.ceil(currRow / gridStore.pageSize);
      if (currRow == totalRowsCalc) {
          currRowCalc = pageCount;
      }
   
      var pgBtnImmutableStaticIdPrefix = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
          (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]) +
          VIEWCONSTANTS.UNDERSCORE + this.blockObj.immutableStaticIdPrefix + VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.BLOCK_ID +
          VIEWCONSTANTS.UNDERSCORE + this.blockObj.id;

      // Pagination buttons if grid is datamart and blockObj has listNavFirst
      if (hasPaginationBtns === true && me.blockObj.datamart === true) {
          tbarItems.push({
              xtype: 'tbfill'
          });

          //   if(currRowCalc > 1){
          tbarItems.push({
              xtype: 'button',
              cls: 'x-one-many-block-first-toolbar-btn',
              text: '&lt;&lt;' + Localize.processLocalStr('first'),
              itemId: 'first',
              reorderable: false,
              immutableStaticIdPrefix: me.blockObj.immutableStaticIdPrefix,
              auxViewName: me.blockObj[VIEWCONSTANTS.OS_VIEW_NAME],
              listeners: {
                  afterrender: function() {
                      var immutableStaticId = pgBtnImmutableStaticIdPrefix + "_btn_first";
                      var logObj = {
                          methodName: 'Dragon.view.One_Many_Block.afterrender',
                          osViewId: immutableStaticId
                      };
                      APPUTILS.addOsViewIdToDom(immutableStaticId, this.btnInnerEl.dom.id, logObj, this.btnInnerEl.dom, me.blockObj[VIEWCONSTANTS.OS_VIEW_NAME]);
                      if ((currRowCalc == pageCount && pageCount =="1") || currRowCalc == "1" || totalRowsCalc=="0" ) {
                          // this.show();
                          this.addCls('pageDisabled');
                          
                      } else {
                  
                          // this.hide();
                          this.removeCls('pageDisabled');
                      }
                  }
              }
          });
          tbarItems.push({
              xtype: 'button',
              cls: 'x-one-many-block-prev-toolbar-btn',
              text: '&lt;' + Localize.processLocalStr('prev'),
              itemId: 'prev',
              reorderable: false,
              immutableStaticIdPrefix: me.blockObj.immutableStaticIdPrefix,
              auxViewName: me.blockObj[VIEWCONSTANTS.OS_VIEW_NAME],
              listeners: {
                  afterrender: function() {
                      var immutableStaticId = pgBtnImmutableStaticIdPrefix + "_btn_prev";
                      var logObj = {
                          methodName: 'Dragon.view.One_Many_Block.afterrender',
                          osViewId: immutableStaticId
                      };
                      APPUTILS.addOsViewIdToDom(immutableStaticId, this.btnInnerEl.dom.id, logObj, this.btnInnerEl.dom, me.blockObj[VIEWCONSTANTS.OS_VIEW_NAME]);
                      // if (currRowCalc > 1 || totalRowsCalc == 1) {
                        if ((currRowCalc == pageCount && pageCount =="1") || currRowCalc == "1" || totalRowsCalc=="0" ) {
                          // this.show();
                          this.addCls('pageDisabled');
                      } else {
                          // this.hide();
                          this.removeCls('pageDisabled');
                      }
                  }
              }
          });
          // }
          tbarItems.push({
              xtype: 'label',
              text: currRowCalc,
              cls: 'currentRowNum' + "_" + me.blockObj.id,
              listeners: {
                  afterrender: function() {
                      if (currRowCalc < 1 || totalRowsCalc == 0) {
                          this.hide();
                      } else {
                          this.show();
                      }
                  }
              }
          });
          tbarItems.push({
              xtype: 'label',
              text: 'of',
              cls: 'newpagination',
              listeners: {
                  afterrender: function() {
                      if (currRowCalc < 1 || totalRowsCalc == 0) {
                          this.hide();
                      } else {
                          this.show();
                      }
                  }
              }
          });
          tbarItems.push({
              xtype: 'label',
              text: pageCount,
              cls: 'totalRowNum' + "_" + me.blockObj.id,
              listeners: {
                  afterrender: function() {
                      if (currRowCalc < 1 || totalRowsCalc == 0) {
                          this.hide();
                          // this.removeCls('pageDisabled');
                      } else {
                          this.show();
                          // this.addCls('pageDisabled');
                      }
                  }
              }
          });
          // if(pageCount != currRowCalc){ 
          tbarItems.push({
              xtype: 'button',
              cls: 'x-one-many-block-next-toolbar-btn',
              text: Localize.processLocalStr('next') + '&gt;',
              itemId: 'next',
              reorderable: false,
              auxViewName: me.blockObj[VIEWCONSTANTS.OS_VIEW_NAME],
              immutableStaticIdPrefix: me.blockObj.immutableStaticIdPrefix,
              listeners: {
                  afterrender: function() {
                      var immutableStaticId = pgBtnImmutableStaticIdPrefix + "_btn_next";
                      var logObj = {
                          methodName: 'Dragon.view.One_Many_Block.afterrender',
                          osViewId: immutableStaticId
                      };
                      APPUTILS.addOsViewIdToDom(immutableStaticId, this.btnInnerEl.dom.id, logObj, this.btnInnerEl.dom, me.blockObj[VIEWCONSTANTS.OS_VIEW_NAME]);
                      if (currRow == totalRowsCalc) {
                          // this.hide();
                          this.addCls('pageDisabled');
                      } else {
                          // this.show();
                          this.removeCls('pageDisabled');
                      }
                  }
              }
          });
          tbarItems.push({
              xtype: 'button',
              reorderable: false,
              cls: 'x-one-many-block-last-toolbar-btn',
              text: Localize.processLocalStr('Last ') + '&gt;&gt;',
              itemId: 'last',
              immutableStaticIdPrefix: me.blockObj.immutableStaticIdPrefix,
              auxViewName: me.blockObj[VIEWCONSTANTS.OS_VIEW_NAME],
              listeners: {
                  afterrender: function() {
                      var immutableStaticId = pgBtnImmutableStaticIdPrefix + "_btn_last";
                      var logObj = {
                          methodName: 'Dragon.view.One_Many_Block.afterrender',
                          osViewId: immutableStaticId
                      };
                      APPUTILS.addOsViewIdToDom(immutableStaticId, this.btnInnerEl.dom.id, logObj, this.btnInnerEl.dom, me.blockObj[VIEWCONSTANTS.OS_VIEW_NAME]);
                      if (currRow == totalRowsCalc) {
                          // this.hide();
                          this.addCls('pageDisabled');
                      } else {
                          // this.show();
                          this.removeCls('pageDisabled');
                      }
                  }
              }
          });

          // }

          g_OsLogger.debug("Pagination buttons added on grid toolbar", this, {
              methodName: '_createToolBar',
              isDatamart: true,
              objectId: me.blockObj.objectId,
              id: me.blockObj.id,
              label: me.blockObj.label
          });
      }

      // Filter operational buttons if grid is datamart	
      if (me.blockObj.datamart === true) {
          tbarItems.push({
              xtype: 'tbspacer'
          });
          tbarItems.push({
              xtype: 'tbspacer',
              itemId: 'clearSortSpacer',
              hidden: true
          });
          me.reorderer = Ext.create('Dragon.ux.GridMultiSortReorderer');
          me.droppable = Ext.create('Dragon.ux.GridMultiSorter');

          g_OsLogger.debug("Clear sort, save, filter list, clear filter buttons added on grid toolbar", this, {
              methodName: '_createToolBar',
              isDatamart: true,
              objectId: me.blockObj.objectId,
              id: me.blockObj.id,
              label: me.blockObj.label
          });
          // Export To Excel button if blockObj has listExportToExcel config	
          if (Ext.isEmpty(me.blockObj.listExportToExcel) == false) {
              // tbarItems.push({ xtype: 'tbseparator' });	
              var dataIndexArr = [],
                  cellBvIdArr = [],
                  colParamArr = [],
                  cellFesArr = [],
                  cols = me.blockObj.grid.columns;
              for (var cIdx in cols) {
                  if (!Ext.isEmpty(cols[cIdx].dataIndex)) {
                      dataIndexArr.push(cols[cIdx].dataIndex);
                      cellBvIdArr.push(cols[cIdx].cellBvId);
                      cellFesArr.push(cols[cIdx].fes);
                      colParamArr.push({
                          t: cols[cIdx].text,
                          d: cols[cIdx].dataIndex
                      });
                  }
              }

              g_OsLogger.debug("Export button added on grid toolbar", this, {
                  methodName: '_createToolBar',
                  isDatamart: true,
                  objectId: me.blockObj.objectId,
                  id: me.blockObj.id,
                  label: me.blockObj.label
              });
          }
      }
      /**
       * Creating table view toolbar with reorderer and droppable plugins If grid is datamart 
       * Other wise create normal toolbar with items
       */
      if (tbarItems.length > 0) {
          var dockedItems = null;
          if (me.blockObj.showListControls == 1) {
              if (Ext.isEmpty(me.reorderer)) {
                  dockedItems = [{
                      xtype: "toolbar",
                      dock: "top",
                      items: tbarItems,
                      cls: 'x-one-many-block-toolbar',

                  }];
              } else {
                  dockedItems = [{
                      xtype: "toolbar",
                      dock: "top",
                      items: tbarItems,
                      plugins: [me.reorderer, me.droppable],
                      cls: 'x-one-many-block-toolbar',

                  }];
              }
          } else if (me.blockObj.showListControls == 2) {
              if (Ext.isEmpty(me.reorderer)) {
                  dockedItems = [{
                      xtype: "toolbar",
                      dock: "bottom",
                      items: tbarItems,
                      cls: 'x-one-many-block-toolbar',

                  }];
              } else {
                  dockedItems = [{
                      xtype: "toolbar",
                      dock: "bottom",
                      items: tbarItems,
                      plugins: [me.reorderer, me.droppable],
                      cls: 'x-one-many-block-toolbar'
                  }];
              }
          } else if (me.blockObj.showListControls == 3) {
              if (Ext.isEmpty(me.reorderer)) {
                  dockedItems = [{
                      xtype: "toolbar",
                      dock: "bottom",
                      items: tbarItems,
                      cls: 'x-one-many-block-toolbar'
                  }, {
                      xtype: "toolbar",
                      dock: "top",
                      items: tbarItems,
                      cls: 'x-one-many-block-toolbar'
                  }];
              } else {
                  dockedItems = [{
                      xtype: "toolbar",
                      dock: "bottom",
                      items: tbarItems,
                      plugins: [me.reorderer, me.droppable],
                      cls: 'x-one-many-block-toolbar'
                  }, {
                      xtype: "toolbar",
                      dock: "top",
                      items: tbarItems,
                      plugins: [me.reorderer, me.droppable],
                      cls: 'x-one-many-block-toolbar'
                  }];
              }
          }

          me.dockedItems = dockedItems;

          g_OsLogger.info("Created toolbar for the grid", this, {
              methodName: '_createToolBar',
              objectId: me.blockObj.objectId
          });
      }
  },
  /* To remove the radio buttons from the grid when there are Edit or Delete Icon*/
  _setupSelectionModel: function() {
      var me = this,
          grid = me.blockObj.grid,
          skipRadioButton = false,
          lastColumn = me.blockObj.grid.columns.slice(-1)[0],
          rowLevelButtons = lastColumn.rowButtons;

      if (!Ext.isEmpty(rowLevelButtons)) {
          for (let i = 0; i < rowLevelButtons.length; i++) {
              var uiStyle = Dragon.view.common.Functions.getUiMixin(rowLevelButtons[i].uiStyle)
              if (uiStyle === "EditGridIcon" || uiStyle === "DeleteGridIcon") {
                  skipRadioButton = true;
                  break;
              }
          }

          if (skipRadioButton == true) {
              if (Ext.isEmpty(grid.selection) && grid.selection === 'single') {
                  me.selModel = Ext.create('Ext.selection.RowModel', {
                      enableKeyNav: false,
                      hidden: true
                  })
              }

          }
      } else {
          if (Ext.isEmpty(grid.selection)) /* in none defined in MD, use default RowModel and disable enableKeyNav*/ {
              me.selModel = Ext.create('Ext.selection.RowModel', {
                  enableKeyNav: false
              });
              g_OsLogger.info("Setting 'RowModel' as selection model of a grid", this, {
                  methodName: '_setupSelectionModel',
                  selectionModel: grid.selection,
                  id: me.blockObj.id,
                  objectId: me.blockObj.objectId
              });
          } else if (grid.selection === 'single') {
              me.selModel = Ext.create('Dragon.ux.selection.RadioboxModel', {
                  myGrid: me,
                  enableKeyNav: false
              });
              if(document.getElementsByClassName('os-page-footer')[0].children[0].children[0].hasChildNodes() == false){
                me.selModel = Ext.create('Ext.selection.RowModel', {
                  enableKeyNav: false,
                  hidden: true,
                  myGrid: me
              })
              }
              g_OsLogger.info("Setting 'RadioboxModel' as selection model of a grid", this, {
                  methodName: '_setupSelectionModel',
                  selectionModel: grid.selection,
                  id: me.blockObj.id,
                  objectId: me.blockObj.objectId
              });
          } else if (grid.selection === 'multi') {
              me.selModel = Ext.create('Dragon.ux.selection.CheckboxModel', {
                  myGrid: me,
                  enableKeyNav: false
              });
              g_OsLogger.info("Setting 'CheckboxModel' as selection model of a grid", this, {
                  methodName: '_setupSelectionModel',
                  selectionModel: grid.selection,
                  id: me.blockObj.id,
                  objectId: me.blockObj.objectId
              });
          }
      }
      // }
  }
});