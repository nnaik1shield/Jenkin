Ext.define('Dragon.overrides.view.Messages', {
    override: 'Dragon.view.Messages',
	/**
	 * @method initComponent
	 * Initializes a component.
	 */
	 tpl:['<ul id="os-messages">' + 
	 '<li id="ui-rule-status-id" class="ui-rule-status ui-rule-diplay-msg" osviewid ="ui-rule-status-id" style="display:none">Executing UI Rule...</li>' + 
	 '<tpl for=".">' + 
		 '<li class="mode{mode}">' + 
			 '<span osviewid ="mode_{mode}_msg_{#}">{content}</span>' + 
			 '<a href= "#"  class="closeMessage"></a>' +
		 '</li>' + 
		'</tpl>' + 
	'</ul>',
	],
	
    initComponent: function() 
    {
		g_OsLogger.info("Messages component is initialized",this,{methodName:"initComponent"});
		var me = this;
		var msgContainer = Ext.getCmp(me.id);
		if(msgContainer){
			msgContainer.destroy();
		}
		var localDesktop = me.oneShieldDesktop;
		if(me && me.oneShieldDesktop.messageList.messages){
			if(me && me.oneShieldDesktop.messageList.messages[0].content != undefined){
				me.addCls('showToast')
					setTimeout(() => {
						if( !Ext.isEmpty(localDesktop.messageList) && !Ext.isEmpty(localDesktop.messageList.messages) && (!Ext.isEmpty(me))){
							if(!Ext.isEmpty(me.el) && me.el.dom.classList.contains('showToast')){
								me.removeCls('showToast')
							}
						}
				}, 8000);
			}
		}
		this.mon(Ext.getBody(), 'click', function(el, e) {
			// this.el.dom.classList.remove('showToast');
			e.parentElement.style.display ="none";
			e.parentElement.classList.add("hide");
		}, me, {
			delegate: '.closeMessage'
		});
		// this.mon(Ext.getBody(), 'mouseover', function(el, e) {
		// 	this.el.dom.classList.add('showToast');
		// }, me, {
		// 	delegate: '.showToast'
		// });	
		me.callParent(arguments);
		
    },
	
});
