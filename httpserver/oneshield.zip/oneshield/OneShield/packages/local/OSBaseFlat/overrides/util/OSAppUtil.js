/**
 * @class 'Dragon.util.OSAppUtils'
 * A class to handle app utilities
 */
Ext.define('Dragon.overrides.util.OSAppUtil', {
    override: 'Dragon.util.OSAppUtil',
    
    /**
     * Create HTML template for empty block message having view id
     * @method getEmptyBlockMsgHtml
     * @param blockObj block object
     * @Returns html string
     */
    getEmptyBlockMsgHtml: function(blockObj)
    {
    	var osAuxViewName = blockObj[VIEWCONSTANTS.OS_VIEW_NAME];
    	
    	var osViewId = blockObj.id + VIEWCONSTANTS.UNDERSCORE + 'EMPTY_MSG';
    	var html = '<div class="grid-data-empty"><div data-icon="/" class="empty-grid-icon"></div><div class="empty-grid-headline">There are no items to show</div></div>';
    	
    	if(!Ext.isEmpty(osAuxViewName)) {
    		if(GFlags.osViewIdAuxMode && GFlags.osViewIdAuxMode == Dragon.ViewConstants.OS_AUX_MODE_APPEND) {
    			osViewId = osViewId + VIEWCONSTANTS.UNDERSCORE + osAuxViewName;
    			html = '<div class="grid-data-empty"><div data-icon="/" class="empty-grid-icon"></div><div class="empty-grid-headline">There are no items to show</div></div>';
    		}
    		else {
    			html = '<div class="grid-data-empty"><div data-icon="/" class="empty-grid-icon"></div><div class="empty-grid-headline">There are no items to show</div></div>';
    		}
    	}
    	else {
    		html = '<div class="grid-data-empty"><div data-icon="/" class="empty-grid-icon"></div><div class="empty-grid-headline">There are no items to show</div></div>';
    	}
    	
    	return html;
    }
    
    
});
