Ext.namespace('Ext.theme.is')['OSBaseFlat'] = true;
Ext.theme.name = 'OSBaseFlat';