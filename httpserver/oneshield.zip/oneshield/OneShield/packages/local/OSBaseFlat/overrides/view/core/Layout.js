/**
 * @class Dragon.overrides.view.core.Layout
 * @override Dragon.view.core.Layout
 * Overriding the behavior of Layout class
 */
 Ext.define('Dragon.overrides.view.core.Layout', {
    override: 'Dragon.view.core.Layout',

    initComponent: function () {

        this.callParent(arguments);
    },
    

    /**
     *  @method doLayout will be called from renderBlocks()
     * this logic does below things
     * 1. Identify docked blocks in from first row first column and last row first column and the
     *  blocks as docked items to the layout with docked top and bottom respectively
     * 2. If given block blockResponsive is not null then call the doLayout of the block
     *      to adjust it self if possible
     * 3. Prepare zPattern items, If any row of the layout's width is greater than the screen Width then move them to the next row
     *    considering the nonParticpating blocks 
     * 4. From zPattern items Identify the row with max no of columns and set the columns to layout
     * 5. If resposnive Table then based on the screenWidth fix the colspan for the blocks based on 
     *      the block with and the screenWidth
     * 6. Empty blocks are handled by checking with Ext.isEmpty()
     * 7. If Page level responsive is COLUMN responsive then 
     *    a) Hidden blocks(Visibility: false or Empty block metadata) are removed.
     *    b) Maximum height of block in row is set as block height for all blocks in that row.
     * 8. Removing pace holders. Added in previous do layout.
     **/
    doLayout: function () {
        var me = this;
        var screenWidth = this.getScreenWidth();
        var zPatternItems = [];
        var rowWiseBlocks = [];
        var totalNoOfRows = 0;
        var layoutRowItems = this.getLayoutRowItems();
       
        g_OsLogger.info("doLayout() method called for do view responsive", me, {
            methodName: 'doLayout'
        });
        if (layoutRowItems) {
            totalNoOfRows = layoutRowItems.totalNoOfRows;
            rowWiseBlocks = layoutRowItems.rowWiseBlocks;
        } else {
            g_OsLogger.debug("Got empty layout items.", me, {
                methodName: 'doLayout'
            });
            return null;
        }
        if (this.responsive === VIEWCONSTANTS.NOT_RESPONSIVE) {
            g_OsLogger.debug("Layout is not responsive", this, {
                methodName: 'doLayout'
            });
            var currentRow = [];
            for (var blkRowIndex = 0; blkRowIndex < totalNoOfRows; blkRowIndex++) {
                var blocksObj = rowWiseBlocks[blkRowIndex];
                // if row is empty, then there is nothing to do
                if (!Ext.isEmpty(blocksObj)) {
                    for (var blockIndex = 0; blockIndex < blocksObj.length; blockIndex++) {
                        var blockItem = blocksObj[blockIndex];
                        // if the block is empty then nothing to do
                        if (!Ext.isEmpty(blockItem)) {
                            var presentBlock = blockItem;
                            g_OsLogger.debug("block is not docked", this, {
                                methodName: 'doLayout',
                                blockId: blockItem.id
                            });
                            /** prepare a currentRow array containing a given row blocks */
                            currentRow.push(blockItem);
                            g_OsLogger.info("Responsive is false from metadata.", me, {
                                methodName: 'doLayout'
                            });
                            /** origWidth is custom propery attached to the block, which is the copy of the width 
                             * that a blcok should occupy irrespective of the page size.
                             */
                            if (!blockItem.origWidth) {
                                g_OsLogger.debug("Calculated width for the block", this, {
                                    methodName: 'doLayout',
                                    blockId: blockItem.id,
                                    calculatedWidth: blockItem.calculatedWidth
                                });
                                blockItem.origWidth = blockItem.calculatedWidth;
                            }

                            // Block responsive behavior when minimised or re-maximise the screen or browser. 
                            // Block is non - responsive in case of grid
                            if (presentBlock) {
                                if ((presentBlock.blockResponsive != VIEWCONSTANTS.NOT_RESPONSIVE) &&
                                    (!Ext.isEmpty(presentBlock.blockObj)) &&
                                    (presentBlock.blockObj.gridMode == false)
                                ) {
                                    g_OsLogger.debug("Block is respnsive calling doLayout of the block", this, {
                                        methodName: 'doLayout',
                                        blockId: blockItem.id
                                    });
                                    presentBlock.doLayout();
                                }
                            }
                        }
                    }
                }
            }
        }
        if (this.responsive == VIEWCONSTANTS.TABLE_RESPONSIVE) {
            var maxBlockLimit = 0;
            var noOfColumns = 1;
            var lastNonParticipatingIndex = 0;
            me.maxNumberOfColumns = 0;
            g_OsLogger.debug("The layout's responsive type:" + this.responsive, this, {
                methodName: 'doLayout'
            });
            if(this.justification > 0){
                this.applyLayoutJustification();
            }
            for (var blkRowIndex = 0; blkRowIndex < totalNoOfRows; blkRowIndex++) {
                var rowWidth = 0;
                var blocksObj = rowWiseBlocks[blkRowIndex];
                var minColumnCount = 0;
                var currentRow = [];
                var actualBlock = undefined;
                var isHiddenBlock = false;
                // if row is empty, then there is nothing to do
                if (!Ext.isEmpty(blocksObj)) {
                    var isRowCrossedScreenSize = false;
                    for (var blockIndex = 0; blockIndex < blocksObj.length; blockIndex++) {
                        var blockItem = blocksObj[blockIndex];
                        if (!Ext.isEmpty(blockItem)) {
                            actualBlock = blockItem.down();
                            isHiddenBlock = actualBlock.getHidden();
                            /** 
                             * if the block is hidden state now , register show event to call doLayout when
                             * the block is visible again
                             */
                            if (isHiddenBlock) {
                                g_OsLogger.debug("Block is hidden, register show event", this, {
                                    methodName: 'doLayout',
                                    blockId: blockItem.id
                                });
                                actualBlock.on("show", me.doLayout, me);
                            }
                            /** 
                             * origWidth is custom propery attached to the block, which is the copy of the width 
                             * that a blcok should occupy irrespective of the page size.
                             */
                            if (!blockItem.origWidth) {
                                blockItem.origWidth = blockItem.calculatedWidth;
                            }
                            /**
                             * Call doLayout of the block to adjust it self with respect to the screensize
                             * if the screen is less than block width
                             * Skip the below logic if the block is grid.
                             */
                            var isBlockWidthIsGreaterThanScreenWidth = (blockItem.origWidth > screenWidth);
                            var isBlockHasDoLayoutMethod = Ext.isFunction(actualBlock.doLayout);
                            var isBlockIsGrid = !Ext.isEmpty(actualBlock.blockObj) && (actualBlock.blockObj.gridMode == true);

                            if ((isBlockHasDoLayoutMethod && 
                                !isBlockIsGrid  ) || (actualBlock.resetWidth)
                            ) {
                                actualBlock.resetWidth = false;
                                
                                try {
                                    actualBlock.doLayout();
                                } catch (e) {
                                    g_OsLogger.error('Error while hiding block lavel responsive: ' + e.message, this, {
                                        methodName: 'doLayout',
                                        msg: e.message
                                    });
                                    throw e;
                                }
                                g_OsLogger.debug("call doLayout of the block as blockwidth is greater than screenwidth", this, {
                                    methodName: 'doLayout',
                                    blockId: blockItem.id,
                                    blockWidth: blockItem.origWidth,
                                    screenWidth: screenWidth
                                });
                            }
                            /**
                             * fix the colspan of the each block to 1 and push them to the currentRow blocks
                             */
                            blockItem.colspan = 1;
                            currentRow.push(blockItem);
                            /** accumulate the width of the each block to calculate the rowWidth */
                            if (!isHiddenBlock) {
                                g_OsLogger.debug("calculate rowWidth with the sum of block width", this, {
                                    methodName: 'doLayout',
                                    blockId: blockItem.id,
                                    currentRowWidth: rowWidth,
                                    blockWidth: blockItem.origWidth
                                });
                                rowWidth = rowWidth + parseInt(blockItem.origWidth);
                            }
                            /**  
                             * increase the columnCount for a row when rowWidth is less than screenWidth
                             * and making sure that it is not incremented unnecessarily with verifying the 
                             * current blocks docked and hidden state
                             */
                            if (rowWidth <= screenWidth && !isHiddenBlock) {
                                minColumnCount++;
                                g_OsLogger.debug("Check no.of columns fit in screen.", me, {
                                    methodName: 'doLayout',
                                    columnCount: minColumnCount
                                });
                            }
                            /**  
                             * Indicate rowCrossed the screen size by setting isRowCrossedScreenSize to true 
                             * when rowWidth is greater than screenWidth
                             */
                            if (rowWidth > screenWidth && !isHiddenBlock) {
                                isRowCrossedScreenSize = true;
                                g_OsLogger.debug("row crossed the screen size", this, {
                                    methodName: 'doLayout',
                                    blockId: blockItem.id,
                                    currentRowWidth: rowWidth,
                                    screenWidth: screenWidth
                                });
                            }
                        }
                    } // END OF BLOCKS IN A ROW LOOP

                    /** when rowCrossed the screensize then identify the nonParticipating blocks max position
                     * in a row and assign to variable maxBlockLimit
                     */
                    if (isRowCrossedScreenSize) {
                        var nonParticipateItemsValues = Ext.pluck(blocksObj, 'nonParticipatingResponsive');
                        lastNonParticipatingIndex = nonParticipateItemsValues.lastIndexOf(true);
                        if (lastNonParticipatingIndex >= maxBlockLimit) {
                            maxBlockLimit = lastNonParticipatingIndex + 1;
                        }
                        g_OsLogger.debug("Last non participating index is identfied", this, {
                            methodName: 'doLayout',
                            lastNonParticipatingIndex: lastNonParticipatingIndex
                        });
                    }
                } else {
                    g_OsLogger.debug("BlockRow is empty", this, {
                        methodName: 'doLayout',
                        rowIndex: blkRowIndex
                    });
                }
                /** cancat all the rows to the zPatternItems which will be items array for layout container */
                zPatternItems = zPatternItems.concat(currentRow);
                /**
                 * identify no of columns to have according to the screenWidth and rowWidth with out
                 * with out considering the non participating blocks. for the first row when minColumncount
                 * is zero then make it to 1 as table should have atleast one column
                 */
                if (blkRowIndex == 0) {
                    if (minColumnCount === 0) {
                        minColumnCount = 1;
                    }
                    noOfColumns = minColumnCount;
                } else if (minColumnCount > noOfColumns) {
                    noOfColumns = minColumnCount;
                }
                g_OsLogger.debug("column count till this row is identified as ", this, {
                    methodName: 'doLayout',
                    rowIndex: blkRowIndex,
                    columnCount: noOfColumns
                });
            } // END OF ROWS IN A PAGE LOOP

            /** 
             * identify final no of columns for the table as the maximum value of 
             * nonparticpatig index and no of column identified based on screenWidth and rowWidth
             */
            me.maxNumberOfColumns = Math.max(maxBlockLimit, noOfColumns);
            /**
             * maxBlockLImit will be zero when there are no nonparticipating blocks in the layout\
             * in this case colspan should be fixed for each column based on the available width
             */
            var responsiveBlocks = APPUTILS.configureColSpan.call(me, zPatternItems, screenWidth, true);
            /**
             * add dummy blocks to the layout to fill maintain the block positions in the row
             * specifically this happens when there are non participating blocks in the layout
             */
            me.removeAll(false);
            me.layout.columns = me.maxNumberOfColumns;
            me.add(responsiveBlocks);
            g_OsLogger.debug("Updated table layout items.", me, {
                methodName: 'doLayout'
            });
        }
        // var newUIExpandedBlock= document.getElementsByClassName('x-panel-NewUIExpandedBlock');
        // if(newUIExpandedBlock.length>0){
        //     var newUIExpanded= newUIExpandedBlock[0].parentElement.closest('#framework-bodyWrap');
        //     newUIExpanded.classList.add('newUIExpanded'); 
        // }
        // else if(newUIExpandedBlock.length==0){
        //     document.getElementById('framework-bodyWrap').classList.remove('newUIExpanded'); 
        // }

      
        /********************Toast Notifications *********************/
        var showToastIcon = document.getElementsByClassName('currentStepBlock');
        var notificationBell = document.createElement('div');
        notificationBell.classList.add('notificationBell');
        notificationBell.setAttribute('data-qtip',"Show Notifications");
        notificationBell.innerHTML = "";
        if(showToastIcon.length>0){
            var hasToast = document.getElementById('os-messages');
            showToastIcon[0].appendChild(notificationBell);
            if(hasToast.children.length>1){
            notificationBell.classList.add('hasNotification');
            notificationBell.addEventListener('click', (e) => {
                let hasToast = document.getElementById('os-messages');
                e.preventDefault();  
                    if( hasToast.childNodes[1].classList.value == "mode1" || hasToast.childNodes[1].classList.value == "mode2" || hasToast.childNodes[1].classList.value == "mode3" ||
                    hasToast.childNodes[1].classList.value == "mode1 hide" ||hasToast.childNodes[1].classList.value == "mode2 hide" || hasToast.childNodes[1].classList.value == "mode3 hide"){
                        
                        document.getElementById('os-messages').parentElement.classList.add('showToast');
                        var hasToast2 = document.getElementById('os-messages');
                        var hasToastChildren = hasToast2.children;
                        if(hasToastChildren.length>0){
                            for(let i=0; i<hasToastChildren.length; i++){
                                hasToast2.childNodes[i].style.display ="block !important";
                                hasToast2.childNodes[i].classList.remove('hide');
                            }
                        }
                        else{
                            for(let j=0; j<hasToastChildren.length; j++){
                                // hasToast.childNodes[j].style.display ="none";
                                hasToast2.childNodes[j].classList.add('hide');
                            }
                        }
                        
                    }
                    else{
                        document.getElementById('os-messages').parentElement.classList.remove('showToast');
                    }
                    e.stopPropagation(); 
            });
            }
                else{
                    notificationBell.classList.remove('hasNotification');
                }
        }
        /*****************************************/
    
        if(this.el.dom.getElementsByClassName("x-form-item-ProfileView").length>0){
            var profileBtn = this.el.dom.getElementsByClassName("x-form-item-ProfileView");
            var profileView = this.el.dom.getElementsByClassName("x-form-display-field-ProfileUsername");
            var profileViewWindow = this.el.dom.getElementsByClassName("x-panel-ProfileViewWindow");
                if( profileView[0] ){
                var profileViewText = profileView[0].innerHTML;
                profileBtn[0].setAttribute('data-qtip', profileViewText);
                }
                profileBtn[0].addEventListener('click', ()=> {
                    profileViewWindow[0].classList.toggle("showProfileViewWindow");
                    profileViewWindow[0].parentNode.classList.toggle('profileMask');
                });
                // profileViewWindow[0].parentNode.classList.add('profileMask');
                window.addEventListener('click', function(e){  
                    if(profileBtn.length>0) {
                    if (profileBtn[0].contains(e.target)){
                      // Clicked in box
                      profileViewWindow[0].classList.add("showProfileViewWindow");
                      profileViewWindow[0].parentNode.classList.add('profileMask');
                    } else{
                      // Clicked outside the box
                      profileViewWindow[0].classList.remove("showProfileViewWindow");
                      profileViewWindow[0].parentNode.classList.remove('profileMask');
                    }
                }
                  });
        }
        var tabFloatingButtonCont = document.getElementById('tabFloatingButtonCont');
        var osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
        (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]);
        var DraftNote=  document.getElementsByClassName('x-btn-DraftNote-small');
        if(tabFloatingButtonCont){
            var floatingIcon = document.createElement('div')
            floatingIcon.classList.add('tabFloatingButtonCont-icon')
            floatingIcon.setAttribute('data-qtip',"Quick Actions");
            let tabFloatingButtonCont_icon = 'tabFloatingButtonCont_icon' ;
            floatingIcon.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+tabFloatingButtonCont_icon)
            var existingFloatingIcon = document.getElementsByClassName('tabFloatingButtonCont-icon');
            var tabFloatingButtonCont = document.getElementById('tabFloatingButtonCont-innerCt');
            if(DraftNote.length>0){
                DraftNote[0].parentElement.classList.add('DraftNoteElemCont');
                tabFloatingButtonCont.classList.add('hasDraftIcon');
            }
            if(existingFloatingIcon.length==0){
                tabFloatingButtonCont.appendChild(floatingIcon);
               
            }
            window.addEventListener('click', function(e){  
                if(document.getElementById('tabFloatingButtonCont-innerCt')) {
                    if (document.getElementById('tabFloatingButtonCont-innerCt').contains(e.target)){
                        floatingIcon.classList.add("open");
                        tabFloatingButtonCont.classList.add("open");
                        if(DraftNote.length>0){
                            DraftNote[0].parentElement.classList.add("open")
                        }
                    } else{
                        floatingIcon.classList.remove("open");
                        tabFloatingButtonCont.classList.remove("open");
                        if(DraftNote.length>0){
                            DraftNote[0].parentElement.classList.remove("open")
                        }
                    }
                }
              });
            floatingIcon.addEventListener('click', (e) => {
                if(floatingIcon.classList.contains("open")){
                    floatingIcon.classList.remove("open");
                    tabFloatingButtonCont.classList.remove("open");
                    if(DraftNote.length>0){
                        DraftNote[0].parentElement.classList.remove("open")
                    }
                   
                }
                else{
                    floatingIcon.classList.add("open");
                    tabFloatingButtonCont.classList.add("open");
                    if(DraftNote.length>0){
                        DraftNote[0].parentElement.classList.add("open")
                    }
                }
                e.stopPropagation();
            });
           let ele = document.querySelectorAll('[osviewid="currentStep"]');
            if (ele[0].innerHTML.includes('537514') ||
            ele[0].innerHTML.includes('609846') ||
            ele[0].innerHTML.includes('2703848') ||
            ele[0].innerHTML.includes('323415') ||
            ele[0].innerHTML.includes('1111946') ||
            ele[0].innerHTML.includes('1114146')
            ) {
                document.getElementById('framework').classList.add('treeFieldWidth');
              }
        }
        if(DraftNote.length>0){
            if(!tabFloatingButtonCont){
            var hbox2 = Ext.create('Ext.panel.Panel', {
                type: 'vbox',
                renderTo  : Ext.getBody(),
                pack: 'end ',
                align: 'stretch',
                id:'tabFloatingButtonCont',
                border: false,
            });
            var floatingIcon = document.createElement('div')
            floatingIcon.classList.add('tabFloatingButtonCont-icon')
            floatingIcon.setAttribute('data-qtip',"Quick Actions");
            let tabFloatingButtonCont_icon = 'tabFloatingButtonCont_icon' ;
            floatingIcon.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+tabFloatingButtonCont_icon)
            var existingFloatingIcon = document.getElementsByClassName('tabFloatingButtonCont-icon');
            var tabFloatingButtonCont = document.getElementById('tabFloatingButtonCont-innerCt');
            hbox2.add(DraftNote[0]);
            tabFloatingButtonCont.appendChild(floatingIcon);
            DraftNote[0].parentElement.classList.add('DraftNoteElemCont');
            tabFloatingButtonCont.classList.add('hasDraftIcon');

            window.addEventListener('click', function(e){  
                if(document.getElementById('tabFloatingButtonCont-innerCt')) {
                    if (document.getElementById('tabFloatingButtonCont-innerCt').contains(e.target)){
                        floatingIcon.classList.add("open");
                        tabFloatingButtonCont.classList.add("open");
                        if(DraftNote.length>0){
                            DraftNote[0].parentElement.classList.add("open")
                        }
                    } else{
                        floatingIcon.classList.remove("open");
                        tabFloatingButtonCont.classList.remove("open");
                        if(DraftNote.length>0){
                            DraftNote[0].parentElement.classList.remove("open")
                        }
                    }
                }
              });
            floatingIcon.addEventListener('click', (e) => {
                if(floatingIcon.classList.contains("open")){
                    floatingIcon.classList.remove("open");
                    tabFloatingButtonCont.classList.remove("open");
                    if(DraftNote.length>0){
                        DraftNote[0].parentElement.classList.remove("open")
                    }
                   
                }
                else{
                    floatingIcon.classList.add("open");
                    tabFloatingButtonCont.classList.add("open");
                    if(DraftNote.length>0){
                        DraftNote[0].parentElement.classList.add("open")
                    }
                }
                e.stopPropagation();
            });
            }
        }
          let workflowIndicator = document.getElementsByClassName("os-workflow-indicator-node");
              if(workflowIndicator.length>0){
                for(let i=0; i<workflowIndicator.length; i++){
                    if(workflowIndicator[i].childNodes[0].classList.contains("current")){
                        workflowIndicator[i].classList.add("current");
                    }
                }
              }

        me.callSnapToGrid();
        me.addNewUiBlockClass();
        me.updateLayout();
    },

/* To add a class to the Block Panel after the height of block is calculated*/
    addNewUiBlockClass: function ()  {
        var me = this;
		var layoutBlocks;
        
		if(me.items && me.items.items){
			layoutBlocks = me.items.items;
		}
		if(!Ext.isEmpty(layoutBlocks) && Ext.isArray(layoutBlocks)){
			var layoutBlocksLength = layoutBlocks.length;
        for (var index1 = 0; index1 < layoutBlocksLength; index1++) {
            var layoutBlock1 = layoutBlocks[index1];

            /**** set height for the analytics view block */
            var blockPanel1 = layoutBlock1.down();
            if (!Ext.isEmpty(blockPanel1) &&
							Ext.isFunction(blockPanel1.getHeightOnContent) &&
							blockPanel1.isVisible() &&
							blockPanel1.blockObj 
					) {
            var blkContentHeight1 = blockPanel1.getHeightOnContent();
                    }
            var AnalyticsView= layoutBlock1.el.dom.getElementsByClassName('x-panel-AnalyticsView ')
            var tdElement1 = layoutBlock1.el.up('td');
            if(tdElement1 && AnalyticsView.length>0){
                blkContentHeight1 = tdElement1.getHeight() - 140;
                blockPanel1.setHeight(blkContentHeight1);
                layoutBlock1.setHeight(blkContentHeight1);
            }
           /********************* */

            if (!Ext.isEmpty(blockPanel1) &
            blockPanel1.isVisible() &&
            blockPanel1.blockObj
                )
            {
               
                    if (layoutBlock1.el) {
                        layoutBlock1.el.addCls("newUiBlockWrapperContainer");
                        if(layoutBlock1.el.getFirstChild().dom.classList.contains('onemanyblock')){
                            layoutBlock1.el.addCls("newUiOneManyBlockWrapperContainer");
                        }
                        else{
                            if (layoutBlock1.el.dom.hasAttribute('style')) {
                                // Get the value of the style attribute
                                var styleValue = layoutBlock1.el.getAttribute('style');
                            
                                // Check if the style attribute contains a height property
                                if (styleValue.includes('height')) {
                                    var pageLayoutSubBlock = layoutBlock1.el.getFirstChild().dom.getElementsByClassName('page-layout-sub-block');
                                    if(pageLayoutSubBlock.length>0){
                                        layoutBlock1.el.addCls("newUiOneManyBlockWrapperContainer");
                                    }
                                    else{
                                        layoutBlock1.el.addCls("newUiOneOneBlockWrapperContainer");
                                    }
                                    
                                } 
                                
                            }
                        }
                       
                        if(layoutBlock1.el.dom.getElementsByClassName("x-panel-header-title").length>0){
                        var headerTitle = layoutBlock1.el.dom.getElementsByClassName("x-panel-header-title");
                            if( headerTitle[0].childNodes[0] && headerTitle[0].childNodes[0].childNodes[0] ){
                            var headerTitleText = headerTitle[0].childNodes[0].childNodes[0].innerHTML;
                            headerTitle[0].setAttribute('data-qtip', headerTitleText);
                            }
                        }

                    }
            }
        }
    }
    },
      /**
     * Call the getLayoutRowItems() method to get the layout row blocks
     * Loop the call items and call the applySnapToGrid() method for each block
     */
       callSnapToGrid: function () {
		var me = this;
		var layoutBlocks;
		if(me.items && me.items.items){
			layoutBlocks = me.items.items;
		}
		if(!Ext.isEmpty(layoutBlocks) && Ext.isArray(layoutBlocks)){
			var layoutBlocksLength = layoutBlocks.length;
			for (var index = 0; index < layoutBlocksLength; index++) {
				var layoutBlock = layoutBlocks[index];
				if (!Ext.isEmpty(layoutBlock) && Ext.isFunction(layoutBlock.down)) {
					var blockPanel = layoutBlock.down();
					if (!Ext.isEmpty(blockPanel) &&
							Ext.isFunction(blockPanel.getHeightOnContent) &&
							blockPanel.isVisible() &&
							blockPanel.blockObj &&
							blockPanel.blockObj.snapToFit
					) {
                        me.processResponsiveSnapToGrid();
					}
				}
			}
		}
	},
});
