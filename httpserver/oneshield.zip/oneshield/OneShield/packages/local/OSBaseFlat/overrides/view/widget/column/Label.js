/**
 * @class Dragon.view.widget.column.Label
 * @extends Ext.grid.column.Column {@link #Ext.grid.Panel}
 * Base class for creating and rendering a grid http hyper link column. 
 */
Ext.define('Dragon.overrides.view.widget.column.Label', {
    override: 'Dragon.view.widget.column.Label',
    /**
     * @method
     * @private
     * Function is a life cycle hook method
     * Here we can provide custom configuration depending on column level MD
     */
    initComponent: function () {
        var me = this;
            // if (!Ext.isEmpty(metaData.value) &&
            //     !Ext.isEmpty(metaData.column.ldt)) {
            //         if(metaData.column.ldt == Dragon.ViewConstants.LDT_MONETARY){
            //             val = Dragon.view.common.Functions.removeSpacesFromString(val);
            //         }
            //     }
        me.callParent(arguments);
    
    },
    /**
     * @method renderer
     * Renderer method for transform the value and show in cell of column
     * @param val
     * @param metaData
     * @param record
     * @param rowIndex
     * @param colIndex
     * @param gridStore
     * @param view
     * @return {string}
     */
    renderer: function (val, metaData, record, rowIndex, colIndex, gridStore, view) {
        var me = this;
        
        var grid = this.ownerGrid;
        var accurateColIndex = Dragon.view.common.GridFunctions.getColumnIndex(grid, colIndex);
        g_OsLogger.info("Text column renderer has been called, it will transform the appearance,value of data", {
            methodName: 'renderer',
            colIndex: accurateColIndex,
            rowIndex: rowIndex
        });
        if (!Ext.isEmpty(val) &&
        !Ext.isEmpty(metaData.column.ldt)) {
            if(metaData.column.ldt == Dragon.ViewConstants.LDT_MONETARY){
                val = Dragon.view.common.Functions.removeSpacesFromString(val);
            }
        }
        var column = metaData.column;
        var editorCell = grid.getEditorCellByColumnAndRecord(column, record, grid);
        var renderResult = val;
        if (!Ext.isEmpty(column) && column.mandatory) {
            column.markHeaderMandatory(column);
        }
        
        var selectedEnumCode;
        
        // Handling of lookups when configured as label or in RO block
        if (editorCell != null && !Ext.isEmpty(editorCell.lookups) && editorCell.lookups.length > 0) {
            //Find corresponding list display value in cellEditor lookups
            if (val != null && val.length > 0) {
                var valArr = val.split(',');
                var resArr = [];
                for (var valInd = 0; valInd < valArr.length; valInd++) {
                    for (var i = 0; i < editorCell.lookups.length; i++) {
                        var currItem = editorCell.lookups[i];

                        if (currItem.code == valArr[valInd].trim()) {
                        	selectedEnumCode = currItem.code;
                            resArr.push(currItem.displayValue);
                        }
                    }
                }

                if (resArr.length > 0) {
                    renderResult = resArr.join(',');
                }
            } else if (val == null || (val != null && val.length == 0)) {
                var comboLookups = editorCell.lookups;
                for (var lkupInd in comboLookups) {
                    if (Ext.Number.from(comboLookups[lkupInd].code, 1) == 0 &&
                        Ext.isEmpty(editorCell.value)) {
                        var postDefaultValue = Dragon.util.OSFormUtils.getBvElement('DEFAULT_DROPDOWN_FLAG');

                        if (postDefaultValue && postDefaultValue.getValue().toUpperCase() === 'T') {
                            Dragon.view.common.Functions.addNameFieldLookupListValue(editorCell.varName);
                        }
                        selectedEnumCode = comboLookups[lkupInd].code;
                        renderResult = comboLookups[lkupInd].displayValue;
                        break;
                    }
                }
            }
        }
        if (Ext.isEmpty(editorCell) == false) /* check case for empty editable grid*/ {
            if (editorCell.visible == false) {
                renderResult = '';
            }
            if (column.editable) {
                column.setMetaDataClsByEditorCellAndValue(
                    metaData,
                    editorCell,
                    val,
                    record,
                    rowIndex,
                    accurateColIndex,
                    grid
                );
            }
        } else if (column.editable) {
            metaData.tdCls = 'gridCellEditable';
        }

        if (Ext.isObject(val)) {
            if (val.hasOwnProperty('code') &&
                val.hasOwnProperty('displayValue')) {
                renderResult = val['displayValue'];
            }
        }
        
        var immutableStaticId = APPUTILS.getImmutableStaticId(record.data.immutableStaticIdPrefix, grid.blockObj.id, column.dataIndex, undefined);
        var logObj = {
                methodName: 'Dragon.view.widget.column.Label.renderer',
                osViewId: immutableStaticId
            };
		if (!Ext.isEmpty(editorCell)) {
			if (Ext.isEmpty(metaData.style) && !Ext.isEmpty(editorCell.fieldUiStyle)) {
				metaData.style = APPUTILS.getUiStyleForGridEditorCell(metaData, "fieldUiStyle", editorCell);
			}
			if (Ext.isEmpty(metaData.tdStyle) && !Ext.isEmpty(editorCell.uiStyle)) {
				metaData.tdStyle = APPUTILS.getUiStyleForGridEditorCell(metaData, "cellUiStyle", editorCell);
			}
		}
        APPUTILS.addOsViewIdToDom(immutableStaticId, column.id, logObj, metaData, record.data[VIEWCONSTANTS.OS_VIEW_NAME]);
        
        var domId = column.id + '_' + rowIndex + '_' + colIndex;
        metaData.cellInnerAttr = metaData.cellInnerAttr + ' grid-mkt-id=' + '"' + domId + '"';
        
        if (column.marketingTag) {
        	//Added this code for the case where val is the displayValue. Didn't touched the code above to avoid any impact
        	if (editorCell != null && !Ext.isEmpty(editorCell.lookups) && editorCell.lookups.length > 0 && Ext.isEmpty(selectedEnumCode)) {
        		for (var i = 0; i < editorCell.lookups.length; i++) {
                    if (editorCell.lookups[i].displayValue == val) {
                    	selectedEnumCode = currItem.code;
                    }
                }
        	}
        	APPUTILS.addUpdateMarketingTagMap(column.marketingTag, domId, column.text, renderResult, selectedEnumCode);
        }
        
        // Apply field indicator configuration if column has iconPath
        if (!Ext.isEmpty(column) &&
            !Ext.isEmpty(column.config) &&
            column.config.iconPath!= undefined
        ) { // In case - iconPath configuration is provided from metadata but value is empty
            var emptyIconFolderPath;
            if(Ext.isEmpty(column.config.iconPath)){
                emptyIconFolderPath = VIEWCONSTANTS.FES_IMAGE_DEFAULT_FOLDER;
                // relative path for empty iconPath value
            }
            return '<img class="OneMfieldindicator" src="'+
                APPUTILS.getImagePath(column.config.iconPath, emptyIconFolderPath) +
                '"/><div style="display:inline-block;">' +
                Dragon.view.common.Functions.getHtmlEncodedLabelValueWithNewLine(renderResult) +
                '</div>';
        }
        
        if (Ext.isEmpty(renderResult) || (selectedEnumCode && selectedEnumCode == 0)) {
        	if(column && !Ext.isEmpty(column.defaultValue)){
        		renderResult = column.defaultValue;
        	}
        }
        
        return Dragon.view.common.Functions.getHtmlEncodedLabelValueWithNewLine(renderResult);
    },

});