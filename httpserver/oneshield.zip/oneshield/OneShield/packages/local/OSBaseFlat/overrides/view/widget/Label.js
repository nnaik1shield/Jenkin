/**
 * @class Dragon.view.widget.Label
 * @extends Dragon.view.widget.Display
 * This class is responsible for rendering the label field
 */
Ext.define('Dragon.overrides.view.widget.Label', {
    override: 'Dragon.view.widget.Label',
    /**
     * @method initComponent
     * Function intializes a component.
     */
    initComponent: function () {
        this.beforeInitComponent();
        this.parentObject = (Ext.isEmpty(this.paramsObj)) ? this.paramsObj : this.paramsObj.OsCellObj;
        var me = this,
            paramsObj = me.paramsObj,
            cellObj = me.parentObject;
     
        if (!Ext.isEmpty(cellObj) &&
            !Ext.isEmpty(cellObj.value)) {

                if(cellObj.ldt == Dragon.ViewConstants.LDT_MONETARY){
                    cellObj.value = Dragon.view.common.Functions.removeSpacesFromString(cellObj.value);
                }
            }
		

        me.callParent(arguments);
    }
    });
