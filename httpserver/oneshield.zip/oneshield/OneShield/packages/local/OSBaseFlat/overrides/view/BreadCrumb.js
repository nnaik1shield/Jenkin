Ext.define('Dragon.overrides.view.BreadCrumb', {
	override: 'Dragon.view.BreadCrumb',

	initComponent: function()
	{
		if (this.blockObj) {
			this.id = 'os-bread-crumb-bar-block';
		} else {
			this.id = 'os-bread-crumb-bar';
		}
		this.callParent(arguments);
	},
	
	/**
	 * @method repaintBreadCrumb
	 * This function is responsible for creating a breadcrumb.
	 * @param oneShieldDesktop
	 */
	repaint: function (oneShieldDesktop) {
		this.removeAll();

		var vPageSubTitle = oneShieldDesktop.pageSubTitle;

		if (APPUTILS.isNullField(vPageSubTitle) == false) {
			g_OsLogger.info("Creates bread crumb",this,{methodName:'repaintBreadCrumb', pageSubTitle: vPageSubTitle});
			if (vPageSubTitle.trail && vPageSubTitle.trail.steps ) {
				/* To remove home from the breadcrumb*/
					vPageSubTitle.trail.steps.shift();
					this.addSteps(vPageSubTitle.trail.steps);
			}
			else{
				console.log(vPageSubTitle)
			}

			var cssClass = 'currentStep';
			if (this.blockObj) {
				cssClass = 'currentStepBlock';
			}
			
			this.add({
				xtype: 'label',
				html: '<div ' + GFlags.os_immutable_static_id_name + '="currentStep">' + Ext.String.htmlEncode(vPageSubTitle.pageName) + '</div>',
				cls: cssClass
			});

			this.addTreeButtons(oneShieldDesktop);

			this.setVisible(true);
		} else {
			this.setVisible(false);
			g_OsLogger.error("No items in the bread crumb",this,{methodName:'repaintBreadCrumb'});
		}
	},
   
});