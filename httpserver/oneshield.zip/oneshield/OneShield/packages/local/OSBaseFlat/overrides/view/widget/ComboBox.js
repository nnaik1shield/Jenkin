
Ext.define('Dragon.overrides.view.widget.ComboBox', {
    override: 'Dragon.view.widget.ComboBox',
    
    /**
     * @method initComponent
     * Function intializes a  component.
     */
    initComponent: function () {

        var me = this;
        me.callParent(arguments);
    },
    listeners: {
        afterrender: function (combo) {   
            let comboBox = Ext.getCmp(combo.getId());
            // Get the tooltip element (if it exists)
            if(comboBox){
                if(comboBox.locToolTip){
                    comboBox.locToolTip.destroy();
                }
                
            }
            if(combo.rawValue != "-Select-" || combo.rawValue != "- Select -"){
                combo.inputEl.dom.setAttribute("data-qtip", combo.rawValue);
            }
            else{
                if(combo.OsCellObj.hasOwnProperty('mouseoverMesg')){
                    if(combo.OsCellObj.mouseoverMesg.hasOwnProperty('content')){
                        combo.inputEl.dom.setAttribute("data-qtip", combo.OsCellObj.mouseoverMesg.content);
                    }    
                }
                else{
                    combo.inputEl.dom.setAttribute("data-qtip", "");
                }
                
            }
           
            
        },
        render: function(combo){
            // Get the selected value
            let comboBox = Ext.getCmp(combo.getId());
            // Get the tooltip element (if it exists)
            if(comboBox.locToolTip){
                comboBox.locToolTip.destroy();
            }
               var labelEl = combo.labelEl;

            if (labelEl) {
                if(combo.OsCellObj.hasOwnProperty('mouseoverMesg')){
                    if(combo.OsCellObj.mouseoverMesg.hasOwnProperty('content')){
                        Ext.create('Ext.tip.ToolTip', {
                            target: labelEl,
                            html: combo.OsCellObj.mouseoverMesg.content,
                        });
                    }    
                }
                else{
                    Ext.create('Ext.tip.ToolTip', {
                        target: labelEl,
                        html: '',
                    });
                }
            }
            
        },
        change: function(combo, newValue, oldValue, eOpts) {
            if(combo.rawValue != "-Select-" || combo.rawValue != "- Select -"){
                combo.inputEl.dom.setAttribute("data-qtip", combo.rawValue);
            }
            else{
                if(combo.OsCellObj.hasOwnProperty('mouseoverMesg')){
                    if(combo.OsCellObj.mouseoverMesg.hasOwnProperty('content')){
                        combo.inputEl.dom.setAttribute("data-qtip", combo.OsCellObj.mouseoverMesg.content);
                    }    
                }
                else{
                    combo.inputEl.dom.setAttribute("data-qtip", "");
                }
            }
        }
    }
   
});
