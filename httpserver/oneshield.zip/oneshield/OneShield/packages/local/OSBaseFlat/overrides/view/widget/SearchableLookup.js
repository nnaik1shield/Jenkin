
Ext.define('Dragon.overrides.view.widget.SearchableLookup', {
    override: 'Dragon.view.widget.SearchableLookup',

    /**
     * @method initComponent
     * Function intializes a  component.
     */
    initComponent: function () {
        
        this.callParent(arguments);
    },
    listeners: {
    	blur: function(field, e, eOpts) {
    		if (field) {
    			if(!Ext.isObject(field))
    			{
    				this.configureEmptyNonEmptyStyleOnContainerCell(Ext.isEmpty(field));
    			}
    			else
    			{
    				this.configureEmptyNonEmptyStyleOnContainerCell(Ext.isEmpty(field.value) || "0" === field.value);	
    			}
    			
    		}
        }, 
        afterrender: function(field, eOpts) {
        	if (field) {
        		if(!Ext.isObject(field))
    			{
        			this.configureEmptyNonEmptyStyleOnContainerCell(Ext.isEmpty(field));
    			}
    			else
    			{
    				this.configureEmptyNonEmptyStyleOnContainerCell(Ext.isEmpty(field.value) || "0" === field.value);
    			}
                let comboBox = Ext.getCmp(field.getId());
                // Get the tooltip element (if it exists)
                if(comboBox){
                    if(comboBox.locToolTip){
                        comboBox.locToolTip.destroy();
                    }
                }	
                if(field.rawValue != "-Select-" || field.rawValue != "- Select -"){
                    field.inputEl.dom.setAttribute("data-qtip", field.rawValue);
                }
                else{
                    if(field.OsCellObj.hasOwnProperty('mouseoverMesg')){
                        if(field.OsCellObj.mouseoverMesg.hasOwnProperty('content')){
                            field.inputEl.dom.setAttribute("data-qtip", field.OsCellObj.mouseoverMesg.content);
                        }    
                    }
                    else{
                        field.inputEl.dom.setAttribute("data-qtip", "");
                    }
                }
        	}
        },
        render: function(field){
            // Get the selected value
            let comboBox = Ext.getCmp(field.getId());
            // Get the tooltip element (if it exists)
            if(comboBox.locToolTip){
                comboBox.locToolTip.destroy();
            }
               var labelEl = field.labelEl;

            if (labelEl) {
                if(field.OsCellObj.hasOwnProperty('mouseoverMesg')){
                    if(field.OsCellObj.mouseoverMesg.hasOwnProperty('content')){
                        Ext.create('Ext.tip.ToolTip', {
                            target: labelEl,
                            html: field.OsCellObj.mouseoverMesg.content,
                        });
                    }
                }
                else{
                    Ext.create('Ext.tip.ToolTip', {
                        target: labelEl,
                        html: "",
                    });
                }
            }
            
        },
        change: function(field, newValue, oldValue, eOpts) {
        	if (field) {
        		if(!Ext.isObject(field))
    			{
        			this.configureEmptyNonEmptyStyleOnContainerCell(Ext.isEmpty(field));
    			}
    			else
    			{
    				this.configureEmptyNonEmptyStyleOnContainerCell(Ext.isEmpty(field.value) || "0" === field.value);
    			}
                if(field.rawValue != "-Select-" || field.rawValue != "- Select -"){
                    field.inputEl.dom.setAttribute("data-qtip", field.rawValue);
                }
                else{
                    if(field.OsCellObj.hasOwnProperty('mouseoverMesg')){
                        if(field.OsCellObj.mouseoverMesg.hasOwnProperty('content')){
                            field.inputEl.dom.setAttribute("data-qtip", field.OsCellObj.mouseoverMesg.content);
                        }    
                    }
                    else{
                        field.inputEl.dom.setAttribute("data-qtip", "");
                    }
                }
        	}
        }
    },
   
});