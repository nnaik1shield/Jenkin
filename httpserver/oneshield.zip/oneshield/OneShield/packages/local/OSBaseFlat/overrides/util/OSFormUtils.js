/**
 * @class 'Dragon.util.OSFormUtils'
 * A class to handle form utilities
 */
Ext.define('Dragon.overrides.util.OSFormUtils', {
    override: 'Dragon.util.OSFormUtils',
   
    displayUiMessages: function (msgArr, append, isServerMesg) {
        var me = this,
            messageList = [],
            serverMesgs,
            messageAreaView = Ext.getCmp(APPUTILS.lastMessageArea),
            messageAreaBlock = Ext.getCmp(APPUTILS.messageBlockComponentId);
        if(msgArr.length==0||msgArr.length>0){
            var messageArry= document.getElementsByClassName("os_messages_div")
			var mesaageArrLength = messageArry.length;
            messageArry[mesaageArrLength-1].classList.add('showToast')
            setTimeout(() => {
                messageArry[mesaageArrLength-1].classList.remove('showToast')
            }, 8000);
        }
        var messageComponents = [messageAreaView, messageAreaBlock];
        
        for (var i=0; i<messageComponents.length; i++) {
        	if (!Ext.isEmpty(messageComponents[i])) {
        		g_OsLogger.info("displayUiMessages() is called.", this, { methodName: 'displayUiMessages', isServerMesg: isServerMesg, append: append });
        		messageList = [];
        		if (append === false) {
        			messageComponents[i].update([]); /* passing true remove silently without firing any events */
        		} else /* place validation messages under the messages came from server */ {
        			serverMesgs = messageComponents[i].getOsServerMesgs();
        			
        			if (Ext.isArray(serverMesgs)) {
        				messageList = me._mergeMessageArray(messageList, serverMesgs);
        			}
        		}
        		
        		if (Ext.isArray(msgArr)) {
        			Ext.each(msgArr, function (msrArrObj, msrArrIdx, msrArrObjArray) {
        				
        				var msg = {};
        				
        				if (Ext.isObject(msrArrObj)) {
        					msg.content = msrArrObj.message;
        					msg.mode = msrArrObj.mode;
        				} else {
        					msg.content = msrArrObj;
        					msg.mode = Dragon.ViewConstants.UI_MESSAGE_MODE_ERROR;
        				}
        				
        				if (me._indexOfMesgArray(messageList, msg) < 0) {
        					messageList.push(msg);
        					
        					if (isServerMesg === true) {
        						messageComponents[i].addAjaxRuleMesg(msg.content, msg.mode);
        					}
        				}
        			});
        			
        		} else if (Ext.isObject(msgArr)) {
        			if (me._indexOfMesgArray(messageList, { content: msgArr.message, mode: msgArr.mode }) < 0) {
        				messageList.push({ content: msgArr.message, mode: msgArr.mode });
        				
        				if (isServerMesg === true) {
        					messageComponents[i].addAjaxRuleMesg(msgArr.message, msgArr.mode);
        				}
        			}
        		} else {
        			if (me._indexOfMesgArray(messageList, { content: msgArr.message, mode: Dragon.ViewConstants.UI_MESSAGE_MODE_ERROR }) < 0) {
        				messageList.push({ content: msgArr.message, mode: Dragon.ViewConstants.UI_MESSAGE_MODE_ERROR });
        				
        				if (isServerMesg === true) {
        					messageComponents[i].addAjaxRuleMesg(msgArr.message, Dragon.ViewConstants.UI_MESSAGE_MODE_ERROR);
        				}
        			}
        		}
        		
        		messageComponents[i].update(messageList);
        	} else {
        		g_OsLogger.debug("Message area view not available", this, { methodName: 'displayUiMessages', isServerMesg: isServerMesg, append: append });
        	}
        }
    },
	  /**
     * @method  submitRowLevelAction
     * Submits action to workflow for the selected grid row; This sets the grid's list object id as the current object for workflow.
     * @param actionSourceId
     * @param actionSourceTypeId
     * @param transactionName
     * @param validateFlag
     * @param confirmMsg
     * @param listObjectId
     * @param listElementObjectId
     */
	   submitRowLevelAction: function (actionSourceId, actionSourceTypeId, transactionName, validateFlag, confirmMsg, listObjectId, listElementObjectId, actionLoadMaskDefinition) {
        g_OsLogger.info('submitRowLevelAction() got called, it sets the grid list object id as the current object for workflow.', this, { methodName: 'submitRowLevelAction', actionSourceId: actionSourceId, transactionName: transactionName, listObjectId: listObjectId });
        var me = this;
        if (!Ext.isEmpty(confirmMsg) && confirmMsg != "") {
            g_OsLogger.info(' Show confirm message.', this, { methodName: 'submitRowLevelAction', actionSourceId: actionSourceId, transactionName: transactionName, listObjectId: listObjectId });
            Ext.Msg.show({
                title: '',
                msg: confirmMsg,
                buttons: Ext.Msg.YESNO,
                closable: true,
                icon: Ext.Msg.QUESTION,
                fn: function (buttonId) {
                    if (!Ext.isEmpty(buttonId) && buttonId === 'yes') {
                        g_OsLogger.info(' User selected OK button on confirm box', this, { methodName: 'submitRowLevelAction' });
                        me._submitRowLevelActionInternal(actionSourceId, actionSourceTypeId, transactionName, validateFlag, listObjectId, listElementObjectId, actionLoadMaskDefinition);
                    }
                }
            }).center();
        } else {
            g_OsLogger.info(' Call _submitRowLevelActionInternal() method if confirmMsg is not available.', this, { methodName: 'submitRowLevelAction' });
            me._submitRowLevelActionInternal(actionSourceId, actionSourceTypeId, transactionName, validateFlag, listObjectId, listElementObjectId, actionLoadMaskDefinition);
        }
    },

});
