Ext.define('Dragon.overrides.view.rules.RulesEngine', {
    override: 'Dragon.view.rules.RulesEngine',
    init: function () {
        var me = this;
        me.callParent(arguments);
    },
    processBlockDisplayRule: function (targetField, labelId, isDisplay, ajaxBlockDisplay) {
        g_OsLogger.info("Function processes block display rule", this, {
            methodName: 'processBlockDisplayRule',
            id: labelId,
            isDisplay: isDisplay
        });
        var me = this,
            counter = 0,
            blockId = null,
            startIndex = 0,
            endIndex = 0,
            cellId = '',
            labelId = '',
            bvId = '',
            currObj,
            updateBlockLayout = false,
            blockCellsArray = new Array(),

            targetCellArray = new Array(),

            LoopBlockRuleArray = new Array(),

            dispRuleFldsInBlk = null,

            formObj = APPUTILS.getMainForm();

        while (targetField.indexOf('~') != '-1') {
            endIndex = targetField.indexOf('~');

            if (counter == 0) {
                blockId = targetField.substring(startIndex, endIndex);
            } else {
                bvId = targetField.substring(startIndex, endIndex);
                blockCellsArray[counter - 1] = bvId;

            }
            targetField = targetField.substring(targetField.indexOf('~') + 1);

            counter++;
        }

        if (counter == 0) {
            blockId = targetField.substring(startIndex);
        } else {
            bvId = targetField.substring(startIndex);
            blockCellsArray[counter - 1] = bvId;
        }

        var blockObj = Ext.getCmp("blk_" + blockId);

        if (Ext.isEmpty(blockObj) == false) {
            blockObj.setVisible(isDisplay);
            if(!Ext.isEmpty(blockObj.oneShieldDesktop.messageList)){
                if(!Ext.isEmpty(blockObj.oneShieldDesktop.messageList.messages)){
                    if(blockObj.oneShieldDesktop.messageList.messages.length>0){
                        document.getElementsByClassName('os_messages_div')[0].classList.add('showToast');
                        document.getElementsByClassName('os_messages_div')[0].parentElement.classList.add('noHeight');
                    }
                // else{
                //     document.getElementsByClassName('os_messages_div')[0].classList.remove('showToast');
                //     document.getElementsByClassName('os_messages_div')[0].parentElement.classList.add('noHeight');
                // }
                }
            }
        } else {
            blockObj = Ext.getCmp(blockId);

            if (Ext.isEmpty(blockObj) == false) {
                blockObj.setVisible(isDisplay);
                if(Ext.isEmpty(blockObj.oneShieldDesktop.messageList)){
                    if(blockObj.oneShieldDesktop.messageList.messages.length>0){
                        document.getElementsByClassName('os_messages_div')[0].classList.add('showToast');
                        document.getElementsByClassName('os_messages_div')[0].parentElement.classList.add('noHeight');
                    }
                    else{
                        document.getElementsByClassName('os_messages_div')[0].classList.remove('showToast');
                        document.getElementsByClassName('os_messages_div')[0].parentElement.classList.add('noHeight');
                    }
                }
            }
        }
        
        if (blockObj && blockObj.isVisible() && blockObj.initialConfig && blockObj.initialConfig.blockObj && 
        	blockObj.initialConfig.blockObj.uiStyle) {
        	var uiInlineStyle = Dragon.view.common.Functions.getUiExcludingMixin(blockObj.initialConfig.blockObj.uiStyle);
            if (!Ext.isEmpty(uiInlineStyle)) {
            	var xContainer = blockObj.el.up('.x-container');
            	if (!Ext.isEmpty(xContainer)) {
            		xContainer.dom.style = uiInlineStyle;
            	}
            }
        }

        if (ajaxBlockDisplay) // Ajax block display rule, find cells and iterate
        {
            var formFields = APPUTILS.getMainForm().getFields();

            var lookupVar = [];
            if (blockObj && blockObj.blockObj && blockObj.blockObj.subBlocks) {
            	for (var i = 0; i < blockObj.blockObj.subBlocks.length; i++) {
            		var blockLookupId = blockObj.blockObj.subBlocks[i].objectId;
            		lookupVar.push(blockLookupId + "_" + blockObj.blockObj.id);
            	}
            } else {
            	lookupVar.push(blockId);
            }
            
            for (var i = 0; i < lookupVar.length; i++) {
            	formFields.eachKey(function (key, item) {
            		if (key && lookupVar[i] && key.indexOf(lookupVar[i]) != -1 && item
            				&& !Ext.isEmpty(item.OsCellObj)) {
            			currObj = item;
            			
            			cellId = currObj.OsCellObj.varName;
            			labelId = 'Label_' + currObj.OsCellObj.objectId + '_' + currObj.OsCellObj.bvId;
            			if (currObj) {
            				/* 
            				 * For each cells passed in this block display instruction, 
            				 * 1. first apply the current display status for each cell 
            				 * 2. run the client side rules which each of this cell could affect/trigger (this cell being part of a condition) 
            				 * 2. run the client side rules which each of this cell could be affected (this cell being target of a condition)
            				 * */
            				me.processDisplayRule(cellId, labelId, currObj.isVisible(), !isDisplay);
            				me.processRuleforField(currObj, !isDisplay, true);
            				me.processRuleforTargetField(currObj, !isDisplay);
            				if (!updateBlockLayout) {
            					//Update Block layout if cell statuses change
            					updateBlockLayout = true;
            				}
            			}
            		}
            	});
            }
        }
        else {  //Client side block display rules, else part to be removed when deprecating client side rules
            if (blockCellsArray != null) {
                for (var cct = 0; cct < blockCellsArray.length; cct++) {
                    bvId = blockCellsArray[cct];

                    cellId = Dragon.ViewConstants.BV_PREF + bvId;
                    labelId = 'Label_' + bvId;

                    currObj = formObj.findField(cellId);

                    if (currObj) {
						/* 
						 * For each cells passed in this block display instruction, 
						 * 1. first apply the current display status for each cell 
						 * 2. run the client side rules which each of this cell could affect/trigger (this cell being part of a condition) 
						 * 2. run the client side rules which each of this cell could be affected (this cell being target of a condition)
						 * */
                        me.processDisplayRule(cellId, labelId, isDisplay, !isDisplay);
                        me.processRuleforField(currObj, !isDisplay, true);
                        me.processRuleforTargetField(currObj, !isDisplay);
                        if (!updateBlockLayout) {
                            //Update Block layout if cell statuses change
                            updateBlockLayout = true;
                        }
                    }
                }
            }
        }
        if (Ext.isEmpty(blockObj) == false && updateBlockLayout) {
            blockObj.updateLayout();
            g_OsLogger.debug("blockObj is present and updateBlockLayout is true then call updateLayout( )", this, {
                methodName: 'processBlockDisplayRule'
            });
        }
    }
  
});