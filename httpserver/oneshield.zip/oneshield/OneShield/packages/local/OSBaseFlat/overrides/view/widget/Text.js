/**
 * @class Dragon.view.widget.Text
 * @extends Ext.form.field.Text
 * A class to create text field with required features
 */
Ext.define('Dragon.overrides.view.widget.Text', {
    override: 'Dragon.view.widget.Text',

    /**
     * @method initComponent
     * Function initializes an text field component.
     */
    initComponent: function () {
        g_OsLogger.info("Text component is initialised", this, {
            methodName: 'initComponent'
        });
        this.parentObject = (Ext.isEmpty(this.paramsObj)) ? this.paramsObj : this.paramsObj.OsCellObj;
        var me = this,
        cellObj = this.commonConfigObj.cellObj;
        if(cellObj){
                var uiStyle = Dragon.view.common.Functions.getUiMixin(cellObj.uiStyle);
                if (uiStyle === "DashboardSearchText") {
                    cellObj.readOnly = false;
                }
            }

        me.callParent(arguments);
    }
    
});
