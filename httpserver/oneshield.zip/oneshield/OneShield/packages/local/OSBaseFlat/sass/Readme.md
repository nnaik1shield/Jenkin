# OSBaseFlat/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    OSBaseFlat/sass/etc
    OSBaseFlat/sass/src
    OSBaseFlat/sass/var
