Ext.define('Dragon.BaseNewUI.view.NewFilterModal', {
    extend: 'Ext.form.Panel',
    alias: 'widget.newfiltermodal',
    width: 500,
    height: 500,
    title: 'New Filter',
    floating: true,
    closable: true,
    drggable: true,
    resizable: true,
    scrollable: true,
    fullscreen: true,
    remoteFilter: true,
    config:{
        modalFilterId : null,
        parGrid :null,
        parGridMetadata : null
    },
    
    listeners: {
        afterrender: function(window) {
          var closeButton = window.down('tool[type=close]');
          if (closeButton) {
            closeButton.getEl().set({'osviewid': 'PAI'+window.id+'_'+closeButton.type+'_'+'newFilterModal'});
          }
        }
      },
    //id: "filterModalWindow_" + modalFilterId,
    modal: true,
    maskOnDisable: false,
    cls: 'NewFilterModal',
    initComponent : function()
    {
        var me = this,
        parGridMetadata = me.parGrid.blockObj.grid,
        columns = me.parGrid.columns,
        columnsMd = parGridMetadata.columns,
        filtersMd = parGridMetadata.filters,
        currFilterObj = null,
        retrievedObject = localStorage.getItem('oneManyNewFilter'), 
        retrievedObject2 = JSON.parse(retrievedObject),
        textFields = 'textfield',
        textValue = '',

        dataIndex  = null,
        fieldLabel = null;
        this.setId('filterModalWindow_' + this.modalFilterId);
        
        this.callParent(arguments);
       
        for( let filterInd = 0; filterInd < filtersMd.length; filterInd++ )
        {
            currFilterObj = filtersMd[filterInd];
            dataIndex = currFilterObj.dataIndex;
            textValue = '';
            if (!Ext.isEmpty(retrievedObject2)) {
                textValue = retrievedObject2[dataIndex];
            }
            fieldLabel = columnsMd[filterInd].text;
            if(!Ext.isEmpty(fieldLabel))
            {
                if( currFilterObj.type === 'date')
                {   
                    this.addRow(fieldLabel, dataIndex, textValue, 'combobox', "date");
                    this.addRow(' ', dataIndex, textValue, 'datefield');
                    this.addRow(' ', dataIndex, textValue, 'datefield');
                }   
                else if( currFilterObj.type === 'number')
                {   
                    this.addRow(fieldLabel, dataIndex, textValue, 'combobox', "numeric");
                    this.addRow(fieldLabel, dataIndex, textValue, 'textfield');
                }             
                else
                {
                    this.addRow(fieldLabel, dataIndex, textValue, 'textfield');
                }
            }
        }
       retrievedObject2 = null;
      
    },
   
    addRow: function (rowLabel, dIndex, textValue, fieldType, objectType) {
        var dates = Ext.create('Ext.data.Store', {
            fields: ['text', 'value'],
            data : [
                {"text":"On", "value":"On"},
                {"text":"Before", "value":"Before"},
                {"text":"After", "value":"After"},
                 {"text":"Between", "value":"Between"}
            ]
        });
        var numbers = Ext.create('Ext.data.Store', {
            fields: ['text', 'value'],
            data : [
                {"text":"=", "value":"eq"},
                {"text":">=", "value":"geq"},
                {"text":">", "value":"gt"},
                {"text":"<=", "value":"leq"},
                {"text":"<", "value":"lt"},
                {"text":"!=", "value":"neq"}
            ],
        });
    
     if(fieldType == "combobox" && objectType == "date"){
            this.add({
                xtype: 'fieldcontainer',
                fieldLabel: rowLabel,
                osviewid:'',
                labelWidth: 130,
                layout: 'hbox',
                items: [
                    {
                    xtype: fieldType,
                    dataIndex: dIndex,
                    itemId: 'type',
                    name: dIndex,
                    /*combobox  no harm adding this for other text fields*/
                    queryMode: 'local',
                    displayField: 'text',
                    valueField: 'value',
                    editable:false,
                    store: dates,
                    value: textValue,
                    placeholder: '-Choose Operator-',
                    /** */
                    format:'m/d/Y',/* no harm adding this for other text fields */
                    triggers: {
                        clearText: {
                            cls: 'clear-text-trigger-icon',
                            handler: function () {
                                this.setValue('On');
                            }
                        }
                    },
                    listeners: {
                        afterrender: function(textField) {
                            this.setValue('On'); 
                            if ( textField.inputEl) {
                                let osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                                (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+VIEWCONSTANTS.UNDERSCORE+textField.ownerCt.container.id+VIEWCONSTANTS.UNDERSCORE) ;
                                textField.inputEl.dom.setAttribute('osviewid',osviewid+textField.xtype+VIEWCONSTANTS.UNDERSCORE+textField.dataIndex);
                            }  
                            if ( textField.triggerEl.elements.length>1) {
                                let osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                                (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+VIEWCONSTANTS.UNDERSCORE+textField.ownerCt.container.id+VIEWCONSTANTS.UNDERSCORE) ;
                                textField.triggerEl.elements[0].dom.setAttribute('osviewid',osviewid+textField.xtype+'combotrigger'+VIEWCONSTANTS.UNDERSCORE+textField.dataIndex);
                            }  
                          },
                        load: function (textField) {
    
                            if (textField.getValue()) {
                                textField.setHideTrigger(false);
                                // textField.cls('osnonempty')
                                this.addCls('disableTrigger')
                            }
                        },
                        // change: function (textField) {
                     
                        // }
                        change: function(textField, newValue, oldValue, eOpts) {
                            if (textField.getValue()) {
                                textField.setHideTrigger(false);
                                this.addCls('disableTrigger')
                            } else {
                                textField.setValue('');
                                textField.setHideTrigger(false);
                            }
                            var comboParent = textField.el.dom.parentElement.closest('.x-form-fieldcontainer');
                            if(newValue == 'Between'){
                                comboParent.nextSibling.nextSibling.style.display = "table";
                                comboParent.nextSibling.classList.add('fromDate');
                                comboParent.nextSibling.getElementsByTagName('input')[0].placeholder ="From";
                                comboParent.nextSibling.nextSibling.getElementsByTagName('input')[0].placeholder ="To";
                                comboParent.nextSibling.nextSibling.classList.add('toDate');
                            }
                            else {
                                comboParent.nextSibling.nextSibling.style.display = "none";
                                comboParent.nextSibling.classList.remove('fromDate');
                                comboParent.nextSibling.nextSibling.classList.remove('toDate');
                                comboParent.nextSibling.getElementsByTagName('input')[0].placeholder ="";
                                comboParent.nextSibling.nextSibling.getElementsByTagName('input')[0].placeholder ="";
                               
                            }
        
                            // this.up().down(`#${oldValue}-label`).setVisible(false);
                            
                            // * Or like this:
                            //  this.up('form').down('#'+ 'newValue' + '-label').setVisible(true);
                            //  this.up('form').down('#'+ 'oldValue' + '-label').setVisible(false);
                            
                        }
                    }
    
                }],
                clearIcon: false,
                listeners : {
                    afterrender: function(fieldcontainer) {
                        if ( fieldcontainer.labelEl) {
                            var osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                            (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0])+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+
                            VIEWCONSTANTS.UNDERSCORE+fieldcontainer.ownerCt.id+VIEWCONSTANTS.UNDERSCORE+fieldcontainer.xtype ;
                            fieldcontainer.labelEl.dom.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+fieldcontainer.initialConfig.items[0].dataIndex);
                        }
                        if ( fieldcontainer.child().triggerEl.elements.length>1) {
                            var osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                            (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0])+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+
                            VIEWCONSTANTS.UNDERSCORE+fieldcontainer.ownerCt.id+VIEWCONSTANTS.UNDERSCORE+fieldcontainer.xtype ;
                            fieldcontainer.child().triggerEl.elements[1].dom.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+'combocleartrigger'+VIEWCONSTANTS.UNDERSCORE+fieldcontainer.initialConfig.items[0].dataIndex);                        
                        }
                    }   
                }
            });
        }
    else if(fieldType == "combobox" && objectType =="numeric"){
            this.add({
                xtype: 'fieldcontainer',
                fieldLabel: rowLabel,
                osviewid:'',
                labelWidth: 130,
                layout: 'hbox',
                items: [
                    {
                    xtype: fieldType,
                    dataIndex: dIndex,
                    itemId: 'type',
                    name: dIndex,
                    /*combobox  no harm adding this for other text fields*/
                    queryMode: 'local',
                    displayField: 'text',
                    valueField: 'value',
                    editable:false,
                    store: numbers,
                    value: textValue,
                    placeholder: '-Choose Operator-',
                    /** */
                    format:'m/d/Y',/* no harm adding this for other text fields */
                    triggers: {
                        clearText: {
                            cls: 'clear-text-trigger-icon',
                            handler: function () {
                                this.setValue('=');
                            }
                        }
                    },
                    listeners: {
                        afterrender: function(textField) {
                            this.setValue('='); 
                            if ( textField.inputEl) {
                                let osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                                (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+VIEWCONSTANTS.UNDERSCORE+textField.ownerCt.container.id+VIEWCONSTANTS.UNDERSCORE) ;
                                textField.inputEl.dom.setAttribute('osviewid',osviewid+textField.xtype+VIEWCONSTANTS.UNDERSCORE+textField.dataIndex);
                            }  
                            if ( textField.triggerEl.elements.length>1) {
                                let osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                                (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+VIEWCONSTANTS.UNDERSCORE+textField.ownerCt.container.id+VIEWCONSTANTS.UNDERSCORE) ;
                                textField.triggerEl.elements[0].dom.setAttribute('osviewid',osviewid+textField.xtype+'combotrigger'+VIEWCONSTANTS.UNDERSCORE+textField.dataIndex);
                            }  
                          },
                        load: function (textField) {
    
                            if (textField.getValue()) {
                                textField.setHideTrigger(false);
                                // textField.cls('osnonempty')
                                this.addCls('disableTrigger')
                            }
                        },
                        // change: function (textField) {
                     
                        // }
                        change: function(textField, newValue, oldValue, eOpts) {
                            if (textField.getValue()) {
                                textField.setHideTrigger(false);
                                this.addCls('disableTrigger')
                            } else {
                                textField.setValue('');
                                textField.setHideTrigger(false);
                            }
                            
                        }
                    }
    
                }],
                clearIcon: false,
                listeners : {
                    afterrender: function(fieldcontainer) {
                        if ( fieldcontainer.labelEl) {
                            var osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                            (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0])+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+
                            VIEWCONSTANTS.UNDERSCORE+fieldcontainer.ownerCt.id+VIEWCONSTANTS.UNDERSCORE+fieldcontainer.xtype ;
                            fieldcontainer.labelEl.dom.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+fieldcontainer.initialConfig.items[0].dataIndex);
                        }
                        if ( fieldcontainer.child().triggerEl.elements.length>1) {
                            var osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                            (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0])+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+
                            VIEWCONSTANTS.UNDERSCORE+fieldcontainer.ownerCt.id+VIEWCONSTANTS.UNDERSCORE+fieldcontainer.xtype ;
                            fieldcontainer.child().triggerEl.elements[1].dom.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+'combocleartrigger'+VIEWCONSTANTS.UNDERSCORE+fieldcontainer.initialConfig.items[0].dataIndex);                        
                        }
                    }   
                }
            });
        }
       else if(fieldType == "datefield"){
            this.add({
                xtype: 'fieldcontainer',
                fieldLabel: rowLabel,
                fieldCls:'newfilterdatepickerLabel',
                labelWidth: 130,
                layout: 'hbox',
                items: [{
                    xtype: fieldType,
                    dataIndex: dIndex,
                    name: dIndex,
                    /** */
                    format:'m/d/Y',/* no harm adding this for other text fields */
                    triggers: {
                        clearText: {
                            cls: 'clear-text-trigger-icon',
                            handler: function () {
                                this.setValue('');
                            }
                        }
                    },
                    listeners: {
                        afterrender: function(textField) {
                            if ( textField.inputEl) {
                                let osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                                (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+VIEWCONSTANTS.UNDERSCORE+textField.ownerCt.container.id+VIEWCONSTANTS.UNDERSCORE) ;
                                textField.inputEl.dom.setAttribute('osviewid',osviewid+textField.xtype+VIEWCONSTANTS.UNDERSCORE+textField.dataIndex);
                            }
                            if ( textField.triggerEl.elements.length>1) {
                                let osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                                (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+VIEWCONSTANTS.UNDERSCORE+textField.ownerCt.container.id+VIEWCONSTANTS.UNDERSCORE) ;
                                textField.triggerEl.elements[0].dom.setAttribute('osviewid',osviewid+textField.xtype+'datetrigger'+VIEWCONSTANTS.UNDERSCORE+textField.dataIndex);
                            } 
                        },
                        load: function (textField) {
    
                            if (textField.getValue()) {
                                textField.setHideTrigger(false);
                                textField.cls('osnonempty')
                            }
                        },
                        change: function (textField) {
                            if (textField.getValue()) {
                                textField.setHideTrigger(false);
                            } else {
                                textField.setValue('');
                                textField.setHideTrigger(false);
                            }
                        }
                    }
    
                }],
                listeners : {
                    afterrender: function(fieldcontainer) {
                        this.addCls('newfilterdatepickerLabel');  
                        if ( fieldcontainer.child().triggerEl.elements.length>1) {
                            var osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                            (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0])+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+
                            VIEWCONSTANTS.UNDERSCORE+fieldcontainer.ownerCt.id+VIEWCONSTANTS.UNDERSCORE+fieldcontainer.xtype ;
                            fieldcontainer.child().triggerEl.elements[1].dom.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+'datecleartrigger'+VIEWCONSTANTS.UNDERSCORE+fieldcontainer.initialConfig.items[0].dataIndex);                        
                        }
                    }   
                    
                },
                clearIcon: true,
            });
        }
        else{
            this.add({
                xtype: 'fieldcontainer',
                fieldLabel: rowLabel,
                labelWidth: 130,
                layout: 'hbox',
                items: [{
                    xtype: fieldType,
                    dataIndex: dIndex,
                    name: dIndex,
                    /** */
                    format:'m/d/Y',/* no harm adding this for other text fields */
                    triggers: {
                        clearText: {
                            cls: 'clear-text-trigger-icon',
                            handler: function () {
                                this.setValue('');
                            }
                        }
                    },
                    listeners: {
                        afterrender: function(textField) {
                            if ( textField.inputEl) {
                                let osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                                (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+VIEWCONSTANTS.UNDERSCORE+textField.ownerCt.container.id+VIEWCONSTANTS.UNDERSCORE) ;
                                 textField.inputEl.dom.setAttribute('osviewid',osviewid+textField.xtype+VIEWCONSTANTS.UNDERSCORE+textField.dataIndex);
                           }
                            if ( textField.triggerEl.elements.length>0) {
                                let osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                                (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+VIEWCONSTANTS.UNDERSCORE+textField.ownerCt.container.id+VIEWCONSTANTS.UNDERSCORE) ;
                                textField.triggerEl.elements[0].dom.setAttribute('osviewid',osviewid+textField.xtype+'trigger'+VIEWCONSTANTS.UNDERSCORE+textField.dataIndex);
                            } 
                        },
                        load: function (textField) {
    
                            if (textField.getValue()) {
                                textField.setHideTrigger(false);
                                textField.cls('osnonempty')
                            }
                        },
                        change: function (textField) {
                            if (textField.getValue()) {
                                textField.setHideTrigger(false);
                            } else {
                                textField.setValue('');
                                textField.setHideTrigger(false);
                            }
                        }
                    }
    
                }],
                clearIcon: true,
                listeners: {
                    afterrender: function(fieldcontainer) {
                        if ( fieldcontainer.labelEl) {
                            var osviewid = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE +
                            (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0])+VIEWCONSTANTS.UNDERSCORE+VIEWCONSTANTS.BLOCK_ID+
                            VIEWCONSTANTS.UNDERSCORE+fieldcontainer.ownerCt.id+VIEWCONSTANTS.UNDERSCORE+fieldcontainer.xtype ;
                            fieldcontainer.labelEl.dom.setAttribute('osviewid',osviewid+VIEWCONSTANTS.UNDERSCORE+fieldcontainer.initialConfig.items[0].dataIndex);                        }
                    }
                }
            });
        }
      

    },
    buttons: [
        {
            text: 'Apply and Save Filter',
            itemId: 'saveFilter',
            cls: 'secondaryBtn',
          //  id: "blk_" + me.modalFilterId,
          handler: function () {
            var parPanel = this.up('form'),
                parForm = parPanel.getForm(),
                store = parPanel.getParGrid().getStore(),
                filteredIndexes =  this.up('form').getValues();
                currSavedFilter = "oneManyNewFilter";
        

            Object.keys(filteredIndexes).forEach(key => {
                var filter = null;
                var filter2 = null;
                if (parForm.findField(key).xtype == 'combobox' && parForm.findField(key).value == 'On') 
                {
                    filter =
                        {
                            id: key,
                            property: key,
                            value: filteredIndexes[key][1]
                        };
                    filter.comparison = "eq";
                    filter.type = "date";
                    filter.dateFormat = 'm/d/Y';
                    filter.value = filteredIndexes[key][1];
                    filter.anyMatch = false;
                } 
                else if (parForm.findField(key).xtype == 'combobox' && parForm.findField(key).value == 'After') 
                {
                    filter =
                        {
                            id: key,
                            property: key,
                            value: filteredIndexes[key][1]
                        };
                    filter.comparison = "gt";
                    filter.type = "date";
                    filter.dateFormat = 'm/d/Y';
                    filter.value = filteredIndexes[key][1];
                    filter.anyMatch = false;
                } 
               else if (parForm.findField(key).xtype == 'combobox' && parForm.findField(key).value == 'Before') 
                {
                    filter =
                        {
                            id: key,
                            property: key,
                            value: filteredIndexes[key][1]
                        };
                    filter.comparison = "lt";
                    filter.type = "date";
                    filter.dateFormat = 'm/d/Y';
                    filter.value = filteredIndexes[key][1];
                    filter.anyMatch = false;
                } 
                else if (parForm.findField(key).xtype == 'combobox' && parForm.findField(key).value == 'Between') 
                {
                   
                    filter =
                    {
                        id: key,
                        property: key,
                        value: filteredIndexes[key][1]
                    };
                    filter.comparison = "gt";
                    filter.type = "date";
                    filter.dateFormat = 'm/d/Y';
                    filter.value = filteredIndexes[key][1];
                    filter.anyMatch = false;

                    filter2 =
                        {
                            id: key,
                            property: key,
                            value: filteredIndexes[key][2]
                        };
                    filter2.comparison = "lt";
                    filter2.type = "date";
                    filter2.dateFormat = 'm/d/Y';
                    filter2.value = filteredIndexes[key][2];
                    filter2.anyMatch = false;
                    // localStorage.setItem("oneManyNewFilter2", JSON.stringify(filter));

                } 
                else 
                {
                    filter = {
                        id: key,
                        property: key,
                        value: filteredIndexes[key]
                    };
                    filter.comparison = "like";
                    filter.type = "string";
                    filter.anyMatch = true;
                }
                filter.disableOnEmpty = true;
                if(parForm.findField(key).value == 'Between'){
                    // filter = [filter,filter2];
                    store.addFilter(filter,filter2);
                }
                else{
                    store.addFilter(filter);
                }
                localStorage.setItem("oneManyNewFilter", JSON.stringify(filteredIndexes));
            });
            
        },
        listeners: {
            afterrender: function() {
                
                var pgBtnImmutableStaticIdPrefix = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE + 
                (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]) + VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.BLOCK_ID + 
                VIEWCONSTANTS.UNDERSCORE + this.ownerCt.ownerCt.parGrid.id;
                var immutableStaticId = pgBtnImmutableStaticIdPrefix + "_btn_applyandsave_filter";
                var logObj = {
                    methodName: 'Dragon.view.One_Many_Block.afterrender',
                    osViewId: immutableStaticId
                };
                APPUTILS.addOsViewIdToDom(immutableStaticId, this.btnInnerEl.dom.id, logObj, this.btnInnerEl.dom, this.ownerCt.ownerCt.parGrid.blockObj[VIEWCONSTANTS.OS_VIEW_NAME]);
            }
        }

        },
        {
            text: 'Apply Filters',
            handler: function () 
            {
                var parPanel = this.up('form'),
                    parForm = parPanel.getForm(),
                    store = parPanel.getParGrid().getStore(),
                    filteredIndexes =  this.up('form').getValues();
                    currSavedFilter = "oneManyNewFilter";
            

                Object.keys(filteredIndexes).forEach(key => {
                    var filter = null;
                    var filter2 = null;

                    if (parForm.findField(key).xtype == 'combobox' && parForm.findField(key).value == 'On') 
                    {
                        filter =
                            {
                                id: key,
                                property: key,
                                value: filteredIndexes[key][1]
                            };
                        filter.comparison = "eq";
                        filter.type = "date";
                        filter.dateFormat = 'm/d/Y';
                        filter.value = filteredIndexes[key][1];
                        filter.anyMatch = false;
                    } 
                    else if (parForm.findField(key).xtype == 'combobox' && parForm.findField(key).value == 'Before') 
                    {
                        filter =
                            {
                                id: key,
                                property: key,
                                value: filteredIndexes[key][1]
                            };
                        filter.comparison = "lt";
                        filter.type = "date";
                        filter.dateFormat = 'm/d/Y';
                        filter.value = filteredIndexes[key][1];
                        filter.anyMatch = false;
                    } 
                    else if (parForm.findField(key).xtype == 'combobox' && parForm.findField(key).value == 'After') 
                    {
                        filter =
                            {
                                id: key,
                                property: key,
                                value: filteredIndexes[key][1]
                            };
                        filter.comparison = "gt";
                        filter.type = "date";
                        filter.dateFormat = 'm/d/Y';
                        filter.value = filteredIndexes[key][1];
                        filter.anyMatch = false;
                    } 
                    else if (parForm.findField(key).xtype == 'combobox' && parForm.findField(key).value == 'Between') 
                {
                   
                    filter =
                    {
                        id: key,
                        property: key,
                        value: filteredIndexes[key][1]
                    };
                    filter.comparison = "gt";
                    filter.type = "date";
                    filter.dateFormat = 'm/d/Y';
                    filter.value = filteredIndexes[key][1];
                    filter.anyMatch = false;

                    filter2 =
                        {
                            id: key,
                            property: key,
                            value: filteredIndexes[key][2]
                        };
                    filter2.comparison = "lt";
                    filter2.type = "date";
                    filter2.dateFormat = 'm/d/Y';
                    filter2.value = filteredIndexes[key][2];
                    filter2.anyMatch = false;
                    // localStorage.setItem("oneManyNewFilter2", JSON.stringify(filter));

                } 
                    else 
                    {
                        filter = {
                            id: key,
                            property: key,
                            value: filteredIndexes[key]
                        };
                        filter.comparison = "like";
                        filter.type = "string";
                        filter.anyMatch = true;
                    }
                    filter.disableOnEmpty = true;
                    if(parForm.findField(key).value == 'Between'){
                        // filter = [filter,filter2];
                        store.addFilter(filter,filter2); 
                    }
                    else{
                        store.addFilter(filter);
                    }
                });
               
                localStorage.setItem("oneManyNewFilter", JSON.stringify(filteredIndexes));
                
                parPanel.hide();
            },
            listeners: {
                afterrender: function() {
                    
                    var pgBtnImmutableStaticIdPrefix = VIEWCONSTANTS.PAGE_ACTION_ID + VIEWCONSTANTS.UNDERSCORE + 
                    (Ext.isEmpty(Runtime.getWorkflowContext()) ? "null" : Runtime.getWorkflowContext().split(",")[0]) + VIEWCONSTANTS.UNDERSCORE + VIEWCONSTANTS.BLOCK_ID + 
                    VIEWCONSTANTS.UNDERSCORE + this.ownerCt.ownerCt.parGrid.id;
                    var immutableStaticId = pgBtnImmutableStaticIdPrefix + "_btn_apply_filter";
                    var logObj = {
                        methodName: 'Dragon.view.One_Many_Block.afterrender',
                        osViewId: immutableStaticId
                    };
                    APPUTILS.addOsViewIdToDom(immutableStaticId, this.btnInnerEl.dom.id, logObj, this.btnInnerEl.dom, this.ownerCt.ownerCt.parGrid.blockObj[VIEWCONSTANTS.OS_VIEW_NAME]);
                }
            }
        }
    ]

});