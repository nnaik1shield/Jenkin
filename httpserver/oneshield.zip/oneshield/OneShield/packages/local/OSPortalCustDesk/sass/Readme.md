# OSCustomerPortal/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    OSCustomerPortal/sass/etc
    OSCustomerPortal/sass/src
    OSCustomerPortal/sass/var
