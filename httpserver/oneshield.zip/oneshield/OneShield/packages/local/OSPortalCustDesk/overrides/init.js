Ext.namespace('Ext.theme.is')['OSPortalCustDesk'] = true;
Ext.theme.name = 'OSPortalCustDesk';