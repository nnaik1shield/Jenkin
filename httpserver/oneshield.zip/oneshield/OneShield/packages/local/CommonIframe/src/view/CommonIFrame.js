/**
 * @class Dragon.view.CommonIFrame
 * @extends Ext.panel.Panel
 * Block load an URL in an Iframe
 */
Ext.define('Dragon.view.CommonIFrame', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.CommonIFrame',
    mixins: ['Dragon.view.BlocksMixin'],
    requires:['Ext.ux.IFrame'],
    config: {
        blockObj: {}
    },
    /**
     * @method initComponent
     * This function is responsible for creating the component based on the type received from the backend.
     */
    initComponent: function() {
        
    	var me = this;
    	
    	//create an array of items which need to be pushed into this block
        var blkItemsArray = [];
        
       
        // this block must have only one cell and value of cell must be the URL of website that needs to be loaded in the Iframe
         
		 var url;
        
        
        if(this.blockObj && this.blockObj.cellRows && this.blockObj.cellRows.length > 0 && this.blockObj.cellRows[0].cells && this.blockObj.cellRows[0].cells.length > 0)
        {
			this.blockObj.cellRows[0].cells.forEach(cell => {
				if(cell.fes != Dragon.ViewConstants.FEST_PLACEHOLDER && !Ext.isEmpty(this.blockObj.cellRows[0].cells[0].value))
				{
					url = this.blockObj.cellRows[0].cells[0].value;
					return false;
				}
			});
        }
		
		if(url == undefined)
        {
        	console.error("URL is not provided, please configure a cell having URL as bv-value");
        }
        
        // create an IFrame item
        var iframeItem = new Ext.ux.IFrame({
            src: url,
            style: me.blockObj.uiStyle,
            height: '100%',
            width: '100%',
            resizable:true
        });
        
        blkItemsArray.push(iframeItem);
        
        this.items = blkItemsArray;
        this.callParent(arguments);
    }
});
