# CommonIframe/sass/src

This folder contains SASS sources that mimic the component-class hierarchy. These files
are gathered in to a build of the CSS based on classes that are used by the build.
